 'use strict'

const fs = require('fs');

let events = []
let environment = []
let environment_hd = []
let materials = {}
let customEvents = []
let pointDefinitions = {}


/**
 *  my own utils, because i'm lazy and like to abstract things away
 */
function deepMerge(...objects) {
    const isObject = obj => obj && typeof obj === 'object'

    return objects.reduce((prev, obj) => {
        Object.keys(obj).forEach(key => {
            const pVal = prev[key]
            const oVal = obj[key]

            if (Array.isArray(pVal) && Array.isArray(oVal)) {
                prev[key] = pVal.concat(...oVal)
            } else if (isObject(pVal) && isObject(oVal)) {
                prev[key] = deepMerge(pVal, oVal)
            } else {
                prev[key] = oVal
            }
        })

        return prev
    }, {})
}

function range(start, end, step) {
    step = step || 1
    let result = []

    for (let i = start; i <= end; i += step) {
        result.push(i)
    }

    return result
}

// randomisation
function r(v) {
    return v + Math.random() - 0.5
}


/**
 *  environment
 */

// remove unnecessary stuff
environment.push({"id": "BigSmokePS", "lookupMethod": "Contains", "active": false})
environment.push({"id": "Tree", "lookupMethod": "Contains", "active": false})
environment.push({"id": "Castle", "lookupMethod": "Contains", "active": false})
environment.push({"id": "Crow", "lookupMethod": "Contains", "active": false})
environment.push({"id": "Bats", "lookupMethod": "Contains", "active": false})
environment.push({"id": "ZombieHand", "lookupMethod": "Contains", "active": false})
// the fences are 4 spear like objects in a ground stone, maybe useful for something
environment.push({"id": "Fence", "lookupMethod": "Contains", "active": false})
// full crucifix, crucifix outline and an actual grave
environment.push({"id": "Grave", "lookupMethod": "Contains", "active": false})
// a lot of tomb stones, maybe useful to build something
environment.push({"id": "TombStone", "lookupMethod": "Contains", "active": false})
// all the rectangular stones on the ground, 1-91
environment.push({"id": "GroundStone", "lookupMethod": "Contains", "active": false})
// this is a little shiny light from inside the castle gate, maybe usable for something else?
environment.push({"id": "GateLight", "lookupMethod": "Contains", "active": false})
// a shiny glow below the rotating lasers
environment.push({"id": "NeonTubeC", "lookupMethod": "EndsWith", "active": false})

// the Moon, just get rid of it for now, maybe reuse it for something else later
environment.push({"id": "Moon", "lookupMethod": "EndsWith", "active": false})

// the lights left and right of the runway
// NeonTubeR and NeonTubeL
environment.push({"id": "NeonTubeR", "lookupMethod": "EndsWith", "active": false})
//environment.push({"id": "NeonTubeL", "lookupMethod": "EndsWith", "active": false})
// do not bind any other lights to type 0, because it needs to be an vanilla
// light event without IDs attached to it, to illuminate geometry objects
environment.push({
    "id": "NeonTubeL", "lookupMethod": "EndsWith",
    "position": [0, -2, 0], "scale": [5, 0.001, 1], "rotation": [90, 90, 0],
    "components": {"ILightWithId": {"type": 0}},
})

// lower the fog so it don't affect nodes or other game elements
// Ground is some kind of plane below the fog, to make it better visible, i guess
const fog_Y = -3
environment.push({
    "id": "[0]Environment",
    "lookupMethod": "EndsWith",
    "track": "wobbleorange",
    "components": {"BloomFogEnvironment": {"startY": fog_Y, "height": 1/*, "attenuation": 0.1, "offset": 0*/}}
}, {
    "id": "Ground",
    "lookupMethod": "EndsWith",
    "position": [0, fog_Y, 0]
})

// the hint lasers for the piano sounds
const piano_lasers = [
    // position, rotation (-x = top to the front, +z = top to the left)
    // a Z-rotation of 0 is vertical
    [[-1, 9, 80], [-15, 0, -55]], // /
    [[10, 3, 92], [-35, 0, 40]], // \
    [[3, 8, 86], [-20, 0, 60]], // \
    [[-14, 8, 94], [-70, 0, -75]], // -
    [[12, 6, 90], [-40, 0, 70]], // -
    [[0, 10, 94], [-55, 0, 80]], // -
    [[-13, 0, 87], [-40, 0, -20]], // |
    [[4, 2, 83], [-25, 0, 15]], // |
    [[6, 0, 78], [-15, 0, 5]], // |
    [[-6, 0, 78], [-15, 0, -5]], // |

]
for (let i = 0; i < piano_lasers.length; i++) {
    environment.push({
        "id": "NeonTubeL",
        "lookupMethod": "EndsWith",
        "duplicate": 1,
        "active": true,
        "position": piano_lasers[i][0],
        "rotation": piano_lasers[i][1],
        "scale": [25, 1, 25],
        "components": {
            "ILightWithId": {"type": 4, "lightID": 100 + i},
            "TubeBloomPrePassLight": {"bloomFogIntensityMultiplier": 23, "colorAlphaMultiplier": 0.9}
        },
    })
}

// the surrounding laser pillars for bit drum hits
const drum_lasers = [
    // position, scale, bloom, alpha
    [[-60, 0, 30], [25, 0.02, 25], 3.1, 0.8],
    [[60, 0, 30], [25, 0.02, 25], 3.1, 0.8],
    [[-60, 0, 55], [30, 0.02, 30], 3.2, 0.9],
    [[60, 0, 55], [30, 0.02, 30], 3.2, 0.9],
    [[-62, 0, 80], [35, 0.02, 35], 3.3, 1],
    [[62, 0, 80], [35, 0.02, 35], 3.3, 1],
    [[-61, 0, 105], [40, 0.02, 45], 3.4, 1.1],
    [[61, 0, 105], [40, 0.02, 45], 3.4, 1.1],
    [[-58, 0, 130], [45, 0.02, 55], 3.5, 1.2],
    [[58, 0, 130], [45, 0.02, 55], 3.5, 1.2],
    [[-51, 0, 150], [55, 0.02, 70], 3.6, 1.3],
    [[51, 0, 150], [55, 0.02, 70], 3.6, 1.3],
    [[-42, 0, 170], [60, 0.02, 70], 3.7, 1.4],
    [[42, 0, 170], [60, 0.02, 70], 3.7, 1.4],
    [[-30, 0, 180], [65, 0.02, 75], 3.8, 1.45],
    [[30, 0, 180], [65, 0.02, 75], 3.8, 1.45],
    [[-18, 0, 190], [70, 0.02, 75], 3.9, 1.5],
    [[18, 0, 190], [70, 0.02, 75], 3.9, 1.5],
]
const drum_height = 6
for (let i = 0; i < drum_lasers.length; i++) {
    function add_drum(y, h, light_id, position, scale, bloom, alpha) {
        environment.push({
            "id": "NeonTubeL",
            "lookupMethod": "EndsWith",
            "duplicate": 1,
            "active": true,
            "position": [position[0], y, position[2]],
            "rotation": [0, 0, 0],
            "scale": [scale[0], scale[1] * h, scale[2]],
            "components": {
                "ILightWithId": {"type": 4, "lightID": light_id},
                "TubeBloomPrePassLight": {
                    "bloomFogIntensityMultiplier": bloom,
                    "colorAlphaMultiplier": alpha,
                }
            },
        })
    }
    // ids:
    //  xx0 = left up, xx1 = left down, xx2 = right up, xx3 = right down
    //  *xx is the y-th element (200=surface, 900=the top)
    //  *00-*03 = the 1st light from front, *04-*07 is the 2nd from front, etc. up to *32-*35
    for (let j = 0; j < drum_height; j++) {
        let y = (j * 20) + 10 + parseInt(i / 2) * 2 * j
        let h = parseInt(i / 2) / 10 + 1
        add_drum(y, h, 200 + j * 100 + i * 2, ...drum_lasers[i])
        add_drum(-y, h, 200 + j * 100 + i * 2 + 1, ...drum_lasers[i])
    }
}

// the top laser backlights: GlowLineL
for (let i = 6; i <= 9; i++) {
    environment.push({
        "id": "GlowLineL (" + i + ")",
        "lookupMethod": "EndsWith",
        "active": false,
    })
}

const top_lasers = [
    // position, scale, rotation, alpha
    [[-59, 20, 100], [70, 5, 1], [105, 0, 0], 1.3],
    [[-31, 30, 100], [60, 5, 1], [99, 0, 0], 1.2],
    [[0, 35, 100], [50, 5, 1], [93, 0, 0], 1.1],
    [[31, 30, 100], [60, 5, 1], [99, 0, 0], 1.2],
    [[59, 20, 100], [70, 5, 1], [105, 0, 0], 1.3],
]
for (let i = 0; i < top_lasers.length; i++) {
    environment.push({
        "id": "GlowLineL (7)",
        "lookupMethod": "EndsWith",
        "duplicate": 1,
        "active": true,
        "position": top_lasers[i][0],
        "scale": top_lasers[i][1],
        "rotation": top_lasers[i][2],
        "components": {
            "ILightWithId": {"type": 1, "lightID": 400 + i},
            "TubeBloomPrePassLight": {"bloomFogIntensityMultiplier": 23, "colorAlphaMultiplier": top_lasers[i][3]}
        },
    })
}

// the rotatable lasers: RotatingLasersPair
environment.push({
    "id": "RotatingLasersPair\\ \\(\\d+\\)$",
    "lookupMethod": "Regex",
    "scale": [0.75, 2, 1],
    "components": {
        "TubeBloomPrePassLight": {"bloomFogIntensityMultiplier": 8, "colorAlphaMultiplier": 1.1}
    },
})
const rotating_lasers = [
    [-90, 0, 73],
    [-60, 0, 73],
    [-30, 0, 73],
    [0, 0, 73],
]
// vertical lasers who can rotated down to the player
for (let i = 0; i < rotating_lasers.length; i++) {
    environment.push({
        "id": "RotatingLasersPair\\ \\(\\d+\\)$",
        "lookupMethod": "Regex",
        "duplicate": 1,
        "active": true,
        "position": rotating_lasers[i],
        "rotation": [0, 90, 0],
        "scale": [0, 4, 1],
        "track": "drum_laser_" + i,
    })
}
// horizontal lasers who can swipe between left and right
for (let i = 0; i < rotating_lasers.length; i++) {
    environment.push({
        "id": "RotatingLasersPair\\ \\(\\d+\\)$",
        "lookupMethod": "Regex",
        "duplicate": 1,
        "active": true,
        "position": [rotating_lasers[i][0] + 45, rotating_lasers[i][1] - 22, rotating_lasers[i][2] + 2],
        "rotation": [0, 0, 0],
        "scale": [0, 6, 0.5],
        "track": "drum_swipe_" + i,
    })
    customEvents.push({
        "b": 0,
        "t": "AnimateTrack",
        "d": {
            "track": "drum_swipe_" + i,
            "rotation": [-81, 0, 0],
        }
    })
}

// artificial player platform, because spooky env does not have one
environment.push({
    "id": "GroundStone (1)",
    "lookupMethod": "EndsWith",
    "duplicate": 1,
    "active": true,
    "position": [0, -0.5, 0],
    //"scale": [6.25, 8, 4],
    "scale": [7.25, 9, 4],
    "rotation": [-90, 0, 0],
})


// build the ground with the runway, to be animated later
/*
const ground_x = range(0.5, 29.5)
const ground_z = range(0, 72.5, 2.5)
const ground_scale = [1.2, 6, 1.2]
*/
const ground_scale = [1.5, 11, 1]
const ground_rows = 21
let ground_x = []
let ground_z = []

for (let i = 0; i < ground_rows; i++) {
    ground_x.push(0.55 + i + i * i / 20 + i / 10)
}
for (let i = 0; i < ground_rows; i++) {
    ground_z.push(3 * i + i * i / 10)
}

let ground_events = new Set()

// the loop from back to forward
for (let b = 0; b < ground_z.length; b++) {
    let z = ground_z[b]

    // the loop from left to right
    for (let a = 0; a < ground_x.length; a++) {
        let x = ground_x[a]

        // skip the parts who would be inside the player platform
        if (b == 0 && a < 2) {
            continue
        }

        // use unique track names for each row that's animated together
        let track_name = "ground_row_" + Math.max(a, b)

        // the ground plates who will be the runway
        if (a <= 1 && b > 2) {
            track_name = track_name + "_runway"
        }

        function push_ground_to_each_side (x_position) {
            environment.push({
                "id": "GroundStone (1)",
                "lookupMethod": "EndsWith",
                "duplicate": 1,
                "active": true,
                "position": [x_position, -0.2, z],
                "scale": [0, 0, 0], // initial invisible, no need tp make that with events
                //"scale": ground_scale,
                "rotation": [-90, 0, 0],
                "track": track_name,
            })
        }
        push_ground_to_each_side(x)
        push_ground_to_each_side(x * -1)

        // remember which tracks we have
        ground_events.add(track_name)
    }

    // the lights between the ground plates
    environment.push({
        "id": "NeonTubeC",
        "lookupMethod": "EndsWith",
        "duplicate": 1,
        "active": true,
        "position": [0, -0.4, z - 1.75],
        "scale": [1, 0.15, 1],
        "components": {
            "ILightWithId": {"type": 1, "lightID": 100 + b},
            "TubeBloomPrePassLight": {"bloomFogIntensityMultiplier": 15}
        },
    })
    if (b > 0) {
        // skip the middle one inside the runway
        function push_light_to_each_side(light_id, x_position) {
            environment.push({
                "id": "NeonTubeC",
                "lookupMethod": "EndsWith",
                "duplicate": 1,
                "active": true,
                "position": [x_position, -0.4, 73.5],
                "scale": [1, 0.15, 1],
                "rotation": [90, 0, 0],
                "components": {
                    "ILightWithId": {"type": 1, "lightID": light_id},
                    "TubeBloomPrePassLight": {"bloomFogIntensityMultiplier": 15}
                },
            })
        }
        push_light_to_each_side(200 + b, ground_x[b] - 0.7)
        push_light_to_each_side(300 + b, -ground_x[b] + 0.7)
    }
}

/*
forest: tree ID, track name, position, rotation

Tree1 (1): small tree, big base
Tree2: high left branch
Tree3: bend-over tree
Tree5: 3D tree
*/

const forest = [
    ["Tree5"    , "tree3", [-6, -4, 8.5], [0, 0, 0]],
    ["Tree5"    , "tree5", [7, -2.5, 14], [0, -75, 0]],
    ["Tree5"    , "tree7", [-7, -1, 19], [0, 120, 0]],
    ["Tree2"    , "tree8", [20, -6.5, 22.5], [0, 240, 30]],
    ["Tree1 (1)", "tree9", [-16, -5, 25], [0, 180, 45]],
    ["Tree3"    , "tree10", [4, -5, 27.5], [0, 180, 60]],
    ["Tree2"    , "tree11", [-23, -3, 30], [0, 180, -20]],
    ["Tree1 (1)", "tree12", [27, -3.5, 32.5], [0, 180, 10]],
    ["Tree3"    , "tree13", [-11, -3.5, 35], [0, 180, 25]],
    ["Tree2"    , "tree14", [16, -1.5, 37.5], [0, 180, -5]],
    ["Tree1 (1)", "tree15", [-18, -1, 40], [0, 180, 0]],
    ["Tree3"    , "tree16", [42, -1.5, 42.5], [0, 180, -5]],
    ["Tree2"    , "tree17", [-11, -2, 45], [0, 180, 55]],
    ["Tree1 (1)", "tree18", [8, -5, 47.5], [0, 180, 45]],
    ["Tree3"    , "tree19", [-34, -3.5, 50], [0, 180, 65]],
    ["Tree2"    , "tree20", [7, -2.5, 52.5], [0, 180, 10]],
    ["Tree1 (1)", "tree21", [-39, -2.5, 55], [0, 180, 30]],
    ["Tree3"    , "tree22", [40, -5, 57.5], [0, 180, 45]],
    ["Tree2"    , "tree23", [-37, -1.5, 60], [0, 180, 15]],
    ["Tree1 (1)", "tree24", [39, -3, 62.5], [0, 180, -20]],
    ["Tree3"    , "tree25", [-7, -1.5, 65], [0, 180, -10]],
    ["Tree2"    , "tree26", [46, -1.5, 67.5], [0, 180, 20]],
]
let forest_events = new Set()

for (let i = 0; i < forest.length; i++) {
    environment.push({
        "id": forest[i][0],
        "lookupMethod": "EndsWith",
        "duplicate": 1,
        "active": true,
        "track": forest[i][1],
        "position": forest[i][2],
        "rotation": forest[i][3],
        "scale": [0, 0, 0], // initial invisible, no need to make that with events
    })

    forest_events.add(forest[i][1])
}

/*
industrial buildings: track name: element ID, position, rotation, scale

[13]Grave and [73]Grave: † border
Grave0: full †
Grave1: a small grave stone

[12]Fence and Fence (24): 4 pickets with plank
[28]Fence: 4 low pickets
Fence (1): 4 high pickets

TombStone (5): low stone
TombStone (4): high stone
*/

const industry = {
    "industry3": [  // the tombstone front left
        [false, "Grave1", [-5, -1.3, 8.5], [-90, 135, 0], [3, 2, 3.5]],
        [false, "Fence (1)", [-5.3, -1.3, 6.1], [-90, -5, 0], [2, 1, 1]],
        [false, "Fence (1)", [-4.1, -1.3, 6.5], [-90, -210, 0], [2, 1, 1]],
        [false, "Fence (1)", [-3.3, -1.3, 7.5], [-90, -60, 0], [2, 1, 1]],
        [false, "Fence (1)", [-2.9, -1.3, 8.8], [-90, -80, 0], [2, 1, 1]],
    ],
    "industry5": [  // little mining tower front right
        [false, "TombStone (4)", [7, 2, 14], [180, 45, 5], [0.2, 6, 1]],
        [false, "TombStone (4)", [6, 2, 13], [180, 45, 9], [0.2, 6, 1]],
        [false, "TombStone (4)", [8, 2, 13], [180, 45, -9], [0.2, 6, 1]],
        [false, "TombStone (4)", [7, 2, 12], [180, 45, -5], [0.2, 6, 1]],
        [false, "TombStone (4)", [7.5, 2.55, 13.5], [-90, 45, 0], [2.7, 0.1, 0.7]],
        [false, "TombStone (4)", [6.55, 2.55, 13.45], [-90, -45, 0], [2.7, 0.1, 0.7]],
        [false, "TombStone (4)", [7.45, 2.55, 12.55], [-90, -45, 0], [2.7, 0.1, 0.7]],
        [false, "TombStone (4)", [6.5, 2.55, 12.5], [-90, 45, 0], [2.7, 0.1, 0.7]],
        [false, "TombStone (4)", [7.25, 1.9, 13.75], [180, 45, -23], [0.1, 7, 0.5]],
        [false, "TombStone (4)", [6.2, 1.9, 13.2], [165, 50, 7], [0.1, 7, 0.5]],
        [false, "TombStone (4)", [7.75, 1.9, 12.75], [195, 40, -4], [0.1, 7, 0.5]],
        [false, "TombStone (4)", [6.75, 1.9, 12.25], [180, 45, 23], [0.1, 7, 0.5]],
        [false, "TombStone (4)", [6.91, 3.05, 13], [180, 0, 60], [0.2, 1.4, 1]], // roof
        [false, "TombStone (4)", [7.09, 3.05, 13], [180, 0, -60], [0.2, 1.4, 1]], // roof
        [false, "TombStone (4)", [7, 2.7, 13], [180, 45, 0], [0.05, 3.6, 0.2]], // rope
        [false, "TombStone (4)", [6.98, 0.2, 13], [180, 45, 30], [0.05, 0.45, 0.2]], // rope
        [false, "TombStone (4)", [7.02, 0.2, 13], [180, 45, -30], [0.05, 0.45, 0.2]], // rope
        [false, "GroundStone (1)", [7, 0, 13], [90, 45, 0], [0.5, 1, 3]], // bucket
    ],
    "industry7": [  // old factory front left
        [false, "TombStone (4)", [-5, -1.3, 20.5], [0, -18, 0], [0.5, 4, 1]],
        [false, "TombStone (4)", [-6.5, -1, 20], [0, -18, 0], [0.5, 5, 1]],
        [false, "TombStone (4)", [-8, -1, 19.5], [0, -18, 0], [0.5, 5, 1]],
        [false, "TombStone (4)", [-9.5, -1.3, 19], [0, -18, 0], [0.5, 4, 1]],
        [false, "TombStone (4)", [-5.9, 0.2, 20.2], [0, -18, 180], [4, 4, 1]],
        [false, "TombStone (4)", [-7.25, 0.25, 19.8], [0, -18, 0], [3, 2.5, 1]],
        [false, "TombStone (4)", [-8.6, 0.2, 19.3], [0, -18, 180], [4, 4, 1]],
        [false, "TombStone (4)", [-5.8, 1.1, 20.25], [0, -18, 155], [3.5, 2, 1]],
        [false, "TombStone (4)", [-6.9, 2.1, 19.9], [0, -18, 155], [2, 1, 1]],
        [false, "TombStone (4)", [-7.1, 2.7, 19.85], [0, -18, 155], [0.88, 1, 1]],
        [false, "TombStone (4)", [-7.25, 2.5, 19.8], [0, -18, 180], [1.4, 1, 1]],
        [false, "TombStone (4)", [-7.4, 2.7, 19.75], [0, -18, -155], [0.88, 1, 1]],
        [false, "TombStone (4)", [-7.6, 2.1, 19.65], [0, -18, -155], [2, 1, 1]],
        [false, "TombStone (4)", [-8.8, 1.1, 19.25], [0, -18, -155], [3.5, 2, 1]],
    ],
    "industry8": [  // chemical tanks front right
        [false, "TombStone (4)", [23, -1, 21.55], [0, 30, 0], [2.5, 7, 1]],
        [false, "TombStone (4)", [20.5, -2, 23], [0, 30, 0], [5, 4, 1]],
        [false, "TombStone (4)", [23, 4.4, 21.55], [180, 30, 0], [0.3, 1, 1]],
        [false, "TombStone (4)", [22.55, 4.45, 21.9], [-90, 30, 0], [2.55, 0.25, 1.5]],
        [false, "TombStone (4)", [22.05, 2.35, 22.2], [0, -60, 90], [8.7, 0.25, 1.1]],
        [false, "TombStone (4)", [21.95, 0.26, 22.15], [180, 30, 90], [0.4, 1, 1]],
        [false, "TombStone (4)", [19.36, -0.51, 23.66], [180, 30, 90], [0.4, 0.7, 1]],
        [false, "TombStone (4)", [19, -0.72, 23.87], [0, 30, 0], [0.4, 0.4, 1]],
        [false, "TombStone (4)", [19.15, -0.4, 23.8], [0, 30, 0], [0.15, 0.3, 0.5]],
        [false, "TombStone (4)", [19.15, -0.23, 23.8], [-90, 30, 0], [0.75, 0.1, 0.5]],
    ],
    "industry9": [  // water tower left
        [false, "TombStone (4)", [-13.1, 2, 24], [180, -27, 15], [0.15, 6, 1]],
        [false, "TombStone (4)", [-11.9, 2, 24.6], [180, -27, -10], [0.15, 6, 1]],
        [false, "TombStone (4)", [-12.5, 2, 23.5], [180, -27, 10], [0.15, 6, 1]],
        [false, "TombStone (4)", [-11.3, 2, 24.1], [180, -27, -15], [0.15, 6, 1]],
        [false, "TombStone (5)", [-12.2, 2.6, 24], [0, -27, 0], [3, 1.9, 8]],
        [false, "TombStone (5)", [-12.2, 3.0, 24], [180, -27, 0], [3, 1.2, 8]],
        [false, "TombStone (4)", [-11.9, 1.82, 23.8], [-90, -27, 0], [3.0, 0.05, 0.5]],
        [false, "TombStone (4)", [-12.5, 1.68, 24.3], [-90, -27, 0], [3.1, 0.05, 0.5]],
        [false, "TombStone (4)", [-12.85, 1.75, 23.7], [-45, 25, 15], [1.7, 0.05, 0.5]],
        [false, "TombStone (4)", [-11.55, 1.75, 24.4], [-45, 30, 15], [1.7, 0.05, 0.5]],
        [false, "TombStone (4)", [-11.85, 0.83, 23.8], [-90, -27, 0], [3.7, 0.05, 0.5]],
        [false, "TombStone (4)", [-12.55, 0.67, 24.3], [-90, -27, 0], [3.8, 0.05, 0.5]],
        [false, "TombStone (4)", [-13.05, 0.75, 23.6], [-45, 20, 15], [1.8, 0.05, 0.5]],
        [false, "TombStone (4)", [-11.35, 0.75, 24.5], [-45, 25, 15], [1.8, 0.05, 0.5]],
        [false, "TombStone (4)", [-11.8, -0.16, 23.85], [-90, -27, 0], [4.7, 0.05, 0.5]],
        [false, "TombStone (4)", [-12.6, -0.34, 24.25], [-90, -27, 0], [4.8, 0.05, 0.5]],
        [false, "TombStone (4)", [-13.2, -0.25, 23.5], [-45, 15, 15], [1.85, 0.05, 0.5]],
        [false, "TombStone (4)", [-11.2, -0.26, 24.6], [-45, 20, 17], [1.85, 0.05, 0.5]],
    ],
    "industry10": [  // low factory with windows richt
        [false, "TombStone (4)", [10.41, 1.71, 27.55], [180, 21.5, 0], [15.17, 1, 1]],
        [false, "TombStone (4)", [10.41, 0.72, 27.55], [0, 21.5, 0], [15.17, 1, 1]],
        [false, "TombStone (4)", [7.06, 0.7, 28.87], [180, 21.5, 0], [0.75, 4, 1]],
        [false, "TombStone (4)", [8.31, 0.7, 28.37], [180, 21.5, 0], [1.5, 4, 1]],
        [false, "TombStone (4)", [9.71, 0.7, 27.82], [180, 21.5, 0], [1.5, 4, 1]],
        [false, "TombStone (4)", [11.11, 0.7, 27.27], [180, 21.5, 0], [1.5, 4, 1]],
        [false, "TombStone (4)", [12.51, 0.7, 26.72], [180, 21.5, 0], [1.5, 4, 1]],
        [false, "TombStone (4)", [13.76, 0.7, 26.22], [180, 21.5, 0], [0.75, 4, 1]],
        [false, "TombStone (4)", [7.5, 2, 28.7], [180, 21.5, -27], [2.7, 1.3, 1]],
        [false, "TombStone (4)", [8.9, 2, 28.15], [180, 21.5, -27], [2.7, 1.3, 1]],
        [false, "TombStone (4)", [10.3, 2, 27.6], [180, 21.5, -27], [2.7, 1.3, 1]],
        [false, "TombStone (4)", [11.7, 2, 27.05], [180, 21.5, -27], [2.7, 1.3, 1]],
        [false, "TombStone (4)", [10.41, -1.03, 27.55], [180, 21.5, 0], [15.17, 2, 1]],
    ],
    "industry11": [  // Battersea Power Station left
        [false, "TombStone (4)", [-31, 3, 30], [180, -40, 0], [6, 8, 1]],
        [false, "TombStone (4)", [-31, 4.25, 30], [180, -40, 0], [5.5, 1, 1]],
        [false, "TombStone (4)", [-31, 4.75, 30], [180, -40, 0], [5, 1, 1]],
        [false, "TombStone (4)", [-31, 5.25, 30], [180, -40, 0], [3.5, 2, 1]],
        [false, "TombStone (4)", [-31, 5.5, 30], [180, -40, 0], [3, 2, 1]],
        [false, "TombStone (4)", [-31, 5.75, 30], [180, -40, 0], [2.5, 2, 1]],
        [false, "TombStone (4)", [-31.06, 11, 29.95], [180, -40, 1.5], [1.1, 10, 1]],
        [false, "TombStone (4)", [-30.94, 11, 30.05], [180, -40, -1.5], [1.1, 10, 1]],
        [false, "TombStone (4)", [-27, 3, 33.4], [180, -40, 0], [6, 8, 1]],
        [false, "TombStone (4)", [-27, 4.25, 33.4], [180, -40, 0], [5.5, 1, 1]],
        [false, "TombStone (4)", [-27, 4.75, 33.4], [180, -40, 0], [5, 1, 1]],
        [false, "TombStone (4)", [-27, 5.25, 33.4], [180, -40, 0], [3.5, 2, 1]],
        [false, "TombStone (4)", [-27, 5.5, 33.4], [180, -40, 0], [3, 2, 1]],
        [false, "TombStone (4)", [-27, 5.75, 33.4], [180, -40, 0], [2.5, 2, 1]],
        [false, "TombStone (4)", [-27.06, 11, 33.35], [180, -40, 1.5], [1.1, 10, 1]],
        [false, "TombStone (4)", [-26.94, 11, 33.45], [180, -40, -1.5], [1.1, 10, 1]],
        [false, "TombStone (4)", [-28.2, 2.95, 32.37], [0, -40, 90], [2.2, 5, 1]],
        [false, "TombStone (4)", [-28.2, 1.95, 32.37], [0, -40, 90], [0.9, 5, 1]],
        [false, "TombStone (4)", [-28.2, 1.3, 32.37], [0, -40, 90], [0.45, 5, 1]],
        [false, "TombStone (4)", [-28.2, 0.75, 32.37], [0, -40, 90], [0.45, 5, 1]],
        [false, "TombStone (4)", [-28.2, 0.2, 32.37], [0, -40, 90], [0.45, 5, 1]],
        [false, "TombStone (4)", [-28.2, -0.35, 32.37], [0, -40, 90], [0.45, 5, 1]],
        [false, "TombStone (4)", [-29, -0.98, 31.7], [180, -40, 0], [5, 2, 1]],
        [false, "TombStone (4)", [-28.21, 2, 32.36], [180, -40, 0], [0.6, 7, 1]],
        [false, "TombStone (4)", [-28.59, 2, 32.04], [180, -40, 0], [0.6, 7, 1]],
        [false, "TombStone (4)", [-28.89, 2, 31.79], [180, -40, 0], [0.2, 7, 1]],
        [false, "TombStone (4)", [-29.11, 2, 31.61], [180, -40, 0], [0.2, 7, 1]],
        [false, "TombStone (4)", [-29.41, 2, 31.36], [180, -40, 0], [0.6, 7, 1]],
        [false, "TombStone (4)", [-29.79, 2, 31.04], [180, -40, 0], [0.6, 7, 1]],
    ],
    "industry12": [  // horizontal tank right
        [false, "TombStone (4)", [26.2, 3.1, 32.96], [180, 30, 3], [0.6, 7, 1]],
        [false, "TombStone (4)", [27.8, 3.1, 32.04], [180, 30, -3], [0.6, 7, 1]],
        [false, "TombStone (4)", [27, 2.55, 32.5], [0, 30, -90], [4, 2.5, 1]],
        [false, "TombStone (4)", [27, 2.55, 32.5], [0, 30, 90], [4, 2.5, 1]],
        [false, "TombStone (4)", [25.55, 2.55, 33.33], [0, 30, 90], [0.2, 0.5, 1]],
        [false, "TombStone (4)", [25.3, 2.54, 33.52], [0, -60, 90], [1.3, 0.15, 0.65]],
        [false, "TombStone (4)", [27, 1.8, 32.5], [180, 30, 0], [1, 1.5, 1]],
        [false, "TombStone (4)", [27.73, 0.95, 32.07], [0, 30, 90], [1, 1.5, 1]],
        [false, "TombStone (4)", [28.08, 0.95, 31.87], [0, 30, -90], [1, 1.5, 1]],
        [false, "TombStone (4)", [28.81, 0.1, 31.44], [0, 30, 0], [1, 1.5, 1]],
        [false, "TombStone (4)", [28.81, -2, 31.44], [0, 30, 0], [1, 4, 1]],
        [false, "TombStone (4)", [26.51, 3.2, 32.77], [180, 30, 0], [0.25, 8, 1]],
        [false, "TombStone (4)", [26.77, 3.97, 32.66], [-90, 30, 0], [1.35, 0.15, 1]],
        [false, "TombStone (4)", [27, 3.9, 32.5], [180, 30, 0], [0.25, 1, 1]],
        [true, "TombStone (4)", [27, 3.25, 32.5], [0, 30, 0], [0.6, 0.6, 1]],
        [false, "TombStone (4)", [29.2, 2.62, 31.2], [180, 30, 0], [0.15, 8, 0.5]],
        [false, "TombStone (4)", [29, 3.38, 31.35], [-90, 30, 0], [1, 0.1, 0.55]],
        [false, "TombStone (4)", [28.75, 3.36, 31.47], [0, 30, 110], [0.15, 0.7, 0.5]],
        [true, "TombStone (4)", [28.1, 3.28, 31.87], [0, 30, -20], [0.5, 0.5, 1]],
        [false, "TombStone (4)", [29.4, 3.06, 31.1], [180, 30, 0], [0.15, 8, 0.5]],
        [false, "TombStone (4)", [28.9, 3.85, 31.5], [-90, 30, 0], [2.7, 0.1, 0.55]],
        [false, "TombStone (4)", [28.3, 3.8, 31.78], [0, 30, 155], [0.15, 0.5, 0.5]],
        [true, "TombStone (4)", [28.23, 3.1, 31.79], [0, 30, -65], [0.5, 0.5, 1]],
    ],
    "industry13": [  // power line pole left
        [false, "TombStone (4)", [-11, -2.9, 35], [0, 0, -5.815], [0.15, 28, 0.6]],
        [false, "TombStone (4)", [-10.25, -3, 35], [0, 0, -3.635], [0.15, 28, 0.6]],
        [false, "TombStone (4)", [-7.75, -3, 35], [0, 0, 3.635], [0.15, 28, 0.6]],
        [false, "TombStone (4)", [-7, -2.9, 35], [0, 0, 5.815], [0.15, 28, 0.6]],
        [false, "TombStone (4)", [-9, 8, 35], [0, 0, 0], [3.6, 0.1, 0.5]],
        [false, "TombStone (4)", [-9, 7, 35], [0, 0, 0], [12.2, 0.1, 0.5]],
        [false, "TombStone (4)", [-10.98, 7.5, 35], [0, 0, 25], [4.8, 0.1, 0.5]],
        [false, "TombStone (4)", [-7.02, 7.5, 35], [0, 0, -25], [4.8, 0.1, 0.5]],
        [false, "TombStone (4)", [-9, 11, 35], [0, 0, 0], [2.4, 0.1, 0.5]],
        [false, "TombStone (4)", [-9, 10, 35], [0, 0, 0], [15, 0.1, 0.5]],
        [false, "TombStone (4)", [-11.15, 10.5, 35], [0, 0, 17.5], [6.7, 0.1, 0.5]],
        [false, "TombStone (4)", [-6.85, 10.5, 35], [0, 0, -17.5], [6.7, 0.1, 0.5]],
        [false, "TombStone (4)", [-9, 14, 35], [0, 0, 0], [1.2, 0.1, 0.5]],
        [false, "TombStone (4)", [-9, 13, 35], [0, 0, 0], [9.4, 0.1, 0.5]],
        [false, "TombStone (4)", [-10.3, 13.5, 35], [0, 0, 26], [4.6, 0.1, 0.5]],
        [false, "TombStone (4)", [-7.7, 13.5, 35], [0, 0, -26], [4.6, 0.1, 0.5]],
        [false, "TombStone (4)", [-9, 15, 35], [0, 0, 0], [0.75, 0.07, 0.4]],
        [true, "TombStone (4)", [-9.03, 14.52, 35], [0, 0, 65], [2.15, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.97, 14.52, 35], [0, 0, -65], [2.15, 0.07, 0.4]],
        [false, "TombStone (4)", [-9.03, 13.52, 35], [0, 0, 56], [2.25, 0.07, 0.4]],
        [true, "TombStone (4)", [-8.97, 13.52, 35], [0, 0, -56], [2.25, 0.07, 0.4]],
        [false, "TombStone (4)", [-9.8, 13.3, 35], [0, 0, -30], [2.1, 0.07, 0.4]],
        [false, "TombStone (4)", [-10.27, 13.3, 35], [0, 0, -90], [1, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.2, 13.3, 35], [0, 0, 30], [2.1, 0.07, 0.4]],
        [false, "TombStone (4)", [-7.73, 13.3, 35], [0, 0, 90], [1, 0.07, 0.4]],
        [true, "TombStone (4)", [-9.03, 12.51, 35], [0, 0, 49], [2.6, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.97, 12.51, 35], [0, 0, -49], [2.6, 0.07, 0.4]],
        [false, "TombStone (4)", [-9, 12, 35], [0, 0, 0], [2, 0.07, 0.4]],
        [false, "TombStone (4)", [-9.03, 11.52, 35], [0, 0, 42], [2.8, 0.07, 0.4]],
        [true, "TombStone (4)", [-8.97, 11.52, 35], [0, 0, -42], [2.8, 0.07, 0.4]],
        [true, "TombStone (4)", [-9.04, 10.52, 35], [0, 0, 36], [3.1, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.96, 10.52, 35], [0, 0, -36], [3.1, 0.07, 0.4]],
        [false, "TombStone (4)", [-10.22, 10.35, 35], [0, 0, -29.5], [2.35, 0.07, 0.4]],
        [false, "TombStone (4)", [-10.76, 10.35, 35], [0, 0, -90], [1.15, 0.07, 0.4]],
        [false, "TombStone (4)", [-11.21, 10.17, 35], [0, 0, -18], [2.05, 0.07, 0.4]],
        [false, "TombStone (4)", [-11.75, 10.17, 35], [0, 0, -90], [0.7, 0.07, 0.4]],
        [false, "TombStone (4)", [-7.79, 10.35, 35], [0, 0, 29.5], [2.35, 0.07, 0.4]],
        [false, "TombStone (4)", [-7.25, 10.35, 35], [0, 0, 90], [1.15, 0.07, 0.4]],
        [false, "TombStone (4)", [-6.79, 10.17, 35], [0, 0, 18], [2.05, 0.07, 0.4]],
        [false, "TombStone (4)", [-6.25, 10.17, 35], [0, 0, 90], [0.7, 0.07, 0.4]],
        [false, "TombStone (4)", [-9.03, 9.51, 35], [0, 0, 33], [3.7, 0.07, 0.4]],
        [true, "TombStone (4)", [-8.97, 9.51, 35], [0, 0, -33], [3.7, 0.07, 0.4]],
        [false, "TombStone (4)", [-9, 9, 35], [0, 0, 0], [3.3, 0.07, 0.4]],
        [true, "TombStone (4)", [-9.03, 8.52, 35], [0, 0, 29], [3.9, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.97, 8.52, 35], [0, 0, -29], [3.9, 0.07, 0.4]],
        [false, "TombStone (4)", [-10.5, 7.3, 35], [0, 0, -26], [2.2, 0.07, 0.4]],
        [false, "TombStone (4)", [-10.98, 7.28, 35], [0, 0, -90], [1.05, 0.07, 0.4]],
        [false, "TombStone (4)", [-7.5, 7.3, 35], [0, 0, 26], [2.2, 0.07, 0.4]],
        [false, "TombStone (4)", [-7.02, 7.28, 35], [0, 0, 90], [1.05, 0.07, 0.4]],
        [false, "TombStone (4)", [-9.04, 7.52, 35], [0, 0, 26], [4.1, 0.07, 0.4]],
        [true, "TombStone (4)", [-8.96, 7.52, 35], [0, 0, -26], [4.1, 0.07, 0.4]],
        [true, "TombStone (4)", [-9.03, 6.51, 35], [0, 0, 24], [4.6, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.97, 6.51, 35], [0, 0, -24], [4.6, 0.07, 0.4]],
        [false, "TombStone (4)", [-9, 6, 35], [0, 0, 0], [4.5, 0.07, 0.4]],
        [false, "TombStone (4)", [-9.6, 5.28, 35], [0, 0, 50], [3.8, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.4, 5.28, 35], [0, 0, -50], [3.8, 0.07, 0.4]],
        [true, "TombStone (4)", [-9.85, 5.7, 35], [0, 0, -50], [1.7, 0.07, 0.4]],
        [true, "TombStone (4)", [-8.15, 5.7, 35], [0, 0, 50], [1.7, 0.07, 0.4]],
        [false, "TombStone (4)", [-9.15, 2.9, 35], [0, 0, 50], [8.7, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.85, 2.9, 35], [0, 0, -50], [8.7, 0.07, 0.4]],
        [true, "TombStone (4)", [-10, 3.53, 35], [0, 0, 50], [2.12, 0.07, 0.4]],
        [true, "TombStone (4)", [-8, 3.53, 35], [0, 0, -50], [2.12, 0.07, 0.4]],
        [false, "TombStone (4)", [-9, 3.1, 35], [0, 0, 0], [5.7, 0.07, 0.4]],
        [true, "TombStone (4)", [-10.05, 2.68, 35], [0, 0, -50], [2.2, 0.07, 0.4]],
        [true, "TombStone (4)", [-7.95, 2.68, 35], [0, 0, 50], [2.2, 0.07, 0.4]],
        [false, "TombStone (4)", [-9.15, -0.85, 35], [0, 0, 50], [10.9, 0.07, 0.4]],
        [false, "TombStone (4)", [-8.85, -0.85, 35], [0, 0, -50], [10.9, 0.07, 0.4]],
        [true, "TombStone (4)", [-10.3, -0.1, 35], [0, 0, 50], [2.7, 0.07, 0.4]],
        [true, "TombStone (4)", [-7.7, -0.1, 35], [0, 0, -50], [2.7, 0.07, 0.4]],
        [true, "TombStone (4)", [-9, -0.66, 35], [0, 0, 0], [7, 0.07, 0.4]],
        [true, "TombStone (4)", [-10.33, -1.21, 35], [0, 0, -50], [2.7, 0.07, 0.4]],
        [true, "TombStone (4)", [-7.67, -1.21, 35], [0, 0, 50], [2.7, 0.07, 0.4]],
    ],
    "industry14": [  // factory with oven right
        [false, "TombStone (4)", [21.5, -2.8, 37.5], [0, 0, 0], [4, 6, 1]],
        [false, "TombStone (4)", [21.5, 7, 37.5], [180, 0, -2], [1, 10, 1]],
        [false, "TombStone (4)", [21.5, 7, 37.5], [180, 0, 2], [1, 10, 1]],
        [false, "TombStone (4)", [19.5, -1.1, 37.5], [180, 0, 0], [4, 8, 1]],
        [true, "TombStone (4)", [18.4, 3.5, 37.5], [180, 0, 15], [8.5, 0.3, 1]],
        [true, "TombStone (4)", [18.7, 2.6, 37.5], [180, 0, -15], [6, 0.1, 1]],
        [false, "TombStone (4)", [17.7, 3.5, 37.5], [180, 0, 15], [5.6, 1, 1]],
        [false, "TombStone (4)", [17.7, 2.4, 37.5], [180, 0, 0], [5, 8, 1]],
        [false, "TombStone (4)", [15.71, 5.48, 37.5], [180, 0, 0], [3, 12, 1]],
        [false, "TombStone (4)", [15.17, 6.7, 37.5], [180, 0, -15], [2.3, 0.3, 1]],
        [false, "TombStone (4)", [16.25, 6.7, 37.5], [180, 0, 15], [2.3, 0.3, 1]],
        [true, "TombStone (4)", [17.25, 7.45, 37.5], [0, 0, 0], [0.14, 0.12, 0.5]],
        [true, "TombStone (4)", [17.25, 7.37, 37.5], [0, 0, 0], [0.33, 0.12, 0.5]],
        [true, "TombStone (4)", [17.25, 7.29, 37.5], [0, 0, 0], [0.52, 0.12, 0.5]],
        [true, "TombStone (4)", [17.25, 7.21, 37.5], [0, 0, 0], [0.71, 0.12, 0.5]],
        [true, "TombStone (4)", [17.25, 7.13, 37.5], [0, 0, 0], [0.91, 0.12, 0.5]],
        [true, "TombStone (4)", [17.25, 7.09, 37.5], [0, 0, 0], [1, 0.05, 0.5]],
        [true, "TombStone (4)", [17.11, 7.34, 37.5], [0, 0, -120], [1.1, 0.05, 0.5]],
        [true, "TombStone (4)", [17.39, 7.34, 37.5], [0, 0, 120], [1.1, 0.05, 0.5]],
        [true, "TombStone (4)", [17.35, 7, 37.5], [0, 0, 180], [0.07, 1.25, 0.2]],
        [true, "TombStone (4)", [17.15, 7, 37.5], [0, 0, 180], [0.07, 1.25, 0.2]],
        [true, "TombStone (4)", [17.25, 6.8, 37.5], [0, 0, 180], [0.7, 1.25, 1]],
        [true, "TombStone (4)", [16.62, 5.7, 37.5], [0, 0, -60], [0.7, 1.25, 1]],
        [true, "TombStone (4)", [16.1, 5.4, 37.5], [0, 0, -60], [0.7, 1.25, 1]],
        [false, "TombStone (4)", [14.52, 3.7, 37.5], [180, 0, 0], [2, 10, 1]],
        [false, "TombStone (4)", [13.03, 4.4, 37.5], [180, 0, 0], [4, 12, 1]],
        [false, "TombStone (4)", [13.04, 8.5, 37.5], [180, 0, -3], [2.2, 10, 1]],
        [false, "TombStone (4)", [13.02, 8.5, 37.5], [180, 0, 3], [2.2, 10, 1]],
        [true, "TombStone (4)", [12.04, 3.7, 37.5], [180, 0, -15], [6, 0.3, 1]],
        [true, "TombStone (4)", [12.54, 2.9, 37.5], [180, 0, 15], [6, 0.1, 1]],
    ],
    "industry15": [  // silos left
        [false, "TombStone (4)", [-19, 5, 40], [180, 0, 0], [4.5, 12, 1]],
        [false, "TombStone (4)", [-19.55, 6.5, 40], [180, 0, -26], [2.7, 1, 1]],
        [false, "TombStone (4)", [-18.45, 6.5, 40], [180, 0, 26], [2.7, 1, 1]],
        [false, "TombStone (4)", [-19, 6.8, 40], [0, 0, 0], [0.5, 1, 1]],
        [false, "TombStone (4)", [-16, 5, 40], [180, 0, 0], [4.5, 12, 1]],
        [false, "TombStone (4)", [-16.55, 6.5, 40], [180, 0, -26], [2.7, 1, 1]],
        [false, "TombStone (4)", [-15.45, 6.5, 40], [180, 0, 26], [2.7, 1, 1]],
        [false, "TombStone (4)", [-16, 6.8, 40], [0, 0, 0], [0.5, 1, 1]],
        [false, "TombStone (4)", [-13.25, 3.5, 40], [180, 0, 0], [3.5, 10, 1]],
        [false, "TombStone (4)", [-13.67, 4.75, 40], [180, 0, -26], [2.1, 1, 1]],
        [false, "TombStone (4)", [-12.83, 4.75, 40], [180, 0, 26], [2.1, 1, 1]],
        [false, "TombStone (4)", [-13.25, 4.9, 40], [0, 0, 0], [0.5, 1, 1]],
        [false, "TombStone (4)", [-11.25, 1.2, 40], [180, 0, 0], [1.75, 8, 1]],
        [false, "TombStone (4)", [-11.45, 2.15, 40], [180, 0, -26], [1.2, 1, 1]],
        [false, "TombStone (4)", [-11.05, 2.15, 40], [180, 0, 26], [1.2, 1, 1]],
        [false, "TombStone (4)", [-11.25, 2.3, 40], [0, 0, 0], [0.5, 2.5, 1]],
        [false, "TombStone (4)", [-11.25, 3.56, 40], [0, 0, 0], [0.5, 1, 1]],
        [false, "TombStone (4)", [-20.5, 6.85, 40], [0, 0, 0], [0.5, 1, 1]],
        [false, "TombStone (4)", [-20.5, 5.5, 40], [180, 0, 0], [0.5, 14, 1]],
        [false, "TombStone (4)", [-19.9, 7.45, 40], [0, 0, 90], [0.5, 1, 1]],
        [false, "TombStone (4)", [-18.2, 7.45, 40.05], [-90, 0, 0], [8, 0.2, 2]],
        [false, "TombStone (4)", [-16.55, 7.45, 40], [0, 0, -90], [0.5, 1, 1]],
        [false, "TombStone (4)", [-15.45, 7.1, 40], [0, 0, 55], [0.5, 1, 1]],
        [false, "TombStone (4)", [-13.85, 5.98, 40], [0, 0, 55], [0.5, 3.5, 1]],
        [false, "TombStone (4)", [-13.65, 5.84, 40], [0, 0, -125], [0.5, 4.25, 1]],
        [false, "TombStone (4)", [-11.74, 4.5, 40], [0, 0, -125], [0.5, 1, 1]],
        [true, "TombStone (4)", [-20.95, 6.45, 40], [180, 0, 0], [0.1, 15, 0.5]],
        [true, "TombStone (4)", [-20.43, 7.9, 40], [0, 0, -90], [0.1, 5.5, 0.5]],
        [true, "TombStone (4)", [-20.43, 7, 40], [0, 0, -90], [0.1, 5.5, 0.5]],
        [true, "TombStone (4)", [-15.13, 7.9, 40], [0, 0, 90], [0.1, 5.5, 0.5]],
        [true, "TombStone (4)", [-15.13, 7, 40], [0, 0, 90], [0.1, 5.5, 0.5]],
        [true, "TombStone (4)", [-20.35, 6.1, 40], [0, 0, -90], [0.1, 6, 0.5]],
        [true, "TombStone (4)", [-20.35, 5.2, 40], [0, 0, -90], [0.1, 6, 0.5]],
        [true, "TombStone (4)", [-12.65, 6.1, 40], [0, 0, 90], [0.1, 6, 0.5]],
        [true, "TombStone (4)", [-12.65, 5.2, 40], [0, 0, 90], [0.1, 6, 0.5]],
        [true, "TombStone (4)", [-20.75, 4.3, 40], [0, 0, -90], [0.1, 2, 0.5]],
        [true, "TombStone (4)", [-20.05, 3.4, 40], [0, 0, -90], [0.1, 9, 0.5]],
        [true, "TombStone (4)", [-20.05, 2.5, 40], [0, 0, -90], [0.1, 9, 0.5]],
        [true, "TombStone (4)", [-11.55, 3.4, 40], [0, 0, 90], [0.1, 9, 0.5]],
        [true, "TombStone (4)", [-11.55, 2.5, 40], [0, 0, 90], [0.1, 9, 0.5]],
        [true, "TombStone (4)", [-20.75, 1.6, 40], [0, 0, -90], [0.1, 2, 0.5]],
        [true, "TombStone (4)", [-20.75, 0.7, 40], [0, 0, -90], [0.1, 2, 0.5]],
        [true, "TombStone (4)", [-20.75, -0.2, 40], [0, 0, -90], [0.1, 2, 0.5]],
        [true, "TombStone (4)", [-10.69, 2.95, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-11.87, 2.95, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-14.5, 2.95, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-17.5, 2.95, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-12.07, 5.65, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-12.88, 5.65, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-13.69, 5.65, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-14.5, 5.65, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-17.5, 5.65, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-14.6, 7.45, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-15.41, 7.45, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-16.22, 7.45, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-17.03, 7.45, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-17.84, 7.45, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-18.65, 7.45, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-19.46, 7.45, 40], [0, -90, 90], [1.9, 0.05, 0.4]],
        [true, "TombStone (4)", [-20.27, 7, 40], [0, -90, 90], [3.7, 0.05, 0.4]],
    ],
    "industry16": [  // high chemical tower right
        [false, "TombStone (4)", [36.5, 13, 45], [180, 0, 0], [1.3, 26, 1]],
        [false, "TombStone (4)", [40.5, 10.75, 45], [0, 0, -90], [0.6, 4, 0.4]],
        [false, "TombStone (4)", [40.3, 10.75, 45], [0, 0, 90], [0.6, 4, 0.4]],
        [false, "TombStone (4)", [38.1, 10.75, 45], [0, 0, 90], [0.6, 1.2, 0.4]],
        [false, "TombStone (4)", [37.35, 10, 45], [0, 0, 0], [0.6, 1.2, 0.4]],
        [false, "TombStone (4)", [37.35, 9.6, 45], [0, 0, 0], [0.6, 1.2, 0.4]],
        [false, "TombStone (4)", [37.35, 9.5, 45], [0, 0, 180], [0.6, 1.2, 0.4]],
        [false, "TombStone (4)", [36.6, 8.75, 45], [0, 0, -90], [0.6, 1.2, 0.4]],
        [false, "TombStone (4)", [42.05, 7.9, 45], [0, 0, 90], [0.5, 7, 1]],
        [false, "TombStone (4)", [38.05, 7.9, 45], [0, 0, 90], [0.5, 2.5, 1]],
        [false, "TombStone (4)", [36.57, 7.25, 45], [0, 0, -90], [0.4, 1.05, 0.4]],
        [false, "TombStone (4)", [37.93, 5.75, 45], [0, 0, 90], [0.4, 1.05, 0.4]],
        [false, "TombStone (4)", [37.25, 6.57, 45], [0, 0, 0], [0.4, 1.05, 0.4]],
        [false, "TombStone (4)", [37.25, 6.43, 45], [0, 0, 180], [0.4, 1.05, 0.4]],
        [false, "TombStone (4)", [38.5, 7, 45], [0, 0, 0], [3, 3, 1]],
        [false, "TombStone (4)", [38.5, 6, 45], [180, 0, 0], [3, 15, 1]],
        [false, "TombStone (4)", [38.5, 9, 45], [0, 0, 0], [1, 1.75, 1]],
        [false, "TombStone (4)", [39.55, 10.05, 45], [0, 0, 90], [1, 1.75, 1]],
        [false, "TombStone (4)", [42.05, 10.05, 45], [0, 0, 90], [1, 5, 1]],
        [false, "TombStone (4)", [42.05, 5.15, 45], [0, 0, 90], [1, 6, 1]],
        [false, "TombStone (4)", [42.36, 2.31, 45], [0, 0, 90], [1.2, 2, 1]],
        [false, "TombStone (4)", [41.2, 1.15, 45], [0, 0, 0], [1.2, 2, 1]],
        [false, "TombStone (4)", [41.2, 1.15, 45], [0, 0, 180], [1.2, 5, 1]],
        [true, "TombStone (4)", [42.61, 7, 45], [0, 0, 90], [0.25, 0.5, 0.2]],
        [true, "TombStone (4)", [42.29, 6.68, 45], [0, 0, 0], [0.25, 0.5, 0.2]],
        [true, "TombStone (4)", [42.29, 5.18, 45], [0, 0, 180], [0.25, 15, 0.2]],
        [false, "TombStone (5)", [44, 12.6, 45], [0, 0, 0], [1.4, 2, 1]],
        [false, "TombStone (5)", [44.76, 14.44, 45], [0, 0, 135], [1.4, 2, 1]],
        [false, "TombStone (5)", [44.16, 13.84, 45], [0, 0, -45], [1.4, 2, 1]],
        [false, "TombStone (5)", [45.98, 14.59, 45], [0, 0, 90], [1.4, 2, 1]],
        [false, "TombStone (5)", [45.14, 14.59, 45], [0, 0, -90], [1.4, 2, 1]],
        [false, "TombStone (5)", [46.96, 13.84, 45], [0, 0, 45], [1.4, 2, 1]],
        [false, "TombStone (5)", [46.37, 14.43, 45], [0, 0, -135], [1.4, 2, 1]],
        [false, "TombStone (5)", [47.13, 12.6, 45], [0, 0, 0], [1.4, 2, 1]],
        [false, "TombStone (5)", [47.13, 10.5, 45], [0, 0, 180], [1.4, 24, 1]],
        [false, "TombStone (4)", [44, 9, 45], [0, 0, 0], [6, 6, 1]],
        [false, "TombStone (4)", [44, -2, 45], [0, 0, 0], [6, 20, 1]],
        [true, "TombStone (4)", [44, 12.4, 45], [-90, 0, 0], [10, 0.05, 0.3]],
        [true, "TombStone (4)", [44, 12, 45], [-90, 0, 0], [10, 0.05, 0.3]],
        [true, "TombStone (4)", [44, 11.6, 45], [-90, 0, 0], [10, 0.1, 0.8]],
        [true, "TombStone (4)", [41.51, 12, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [41.75, 12, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [42.1, 12, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [45.9, 12, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [46.25, 12, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [46.49, 12, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [44, 9.4, 45], [-90, 0, 0], [10, 0.05, 0.3]],
        [true, "TombStone (4)", [44, 9, 45], [-90, 0, 0], [10, 0.05, 0.3]],
        [true, "TombStone (4)", [44, 8.6, 45], [-90, 0, 0], [10, 0.1, 0.8]],
        [true, "TombStone (4)", [41.51, 9, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [41.75, 9, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [42.1, 9, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [45.9, 9, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [46.25, 9, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [46.49, 9, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [44, 6.4, 45], [-90, 0, 0], [10, 0.05, 0.3]],
        [true, "TombStone (4)", [44, 6, 45], [-90, 0, 0], [10, 0.05, 0.3]],
        [true, "TombStone (4)", [44, 5.6, 45], [-90, 0, 0], [10, 0.1, 0.8]],
        [true, "TombStone (4)", [41.51, 6, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [41.75, 6, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [42.1, 6, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [45.9, 6, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [46.25, 6, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [46.49, 6, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [44, 3.6, 45], [-90, 0, 0], [10, 0.05, 0.3]],
        [true, "TombStone (4)", [44, 3.2, 45], [-90, 0, 0], [10, 0.05, 0.3]],
        [true, "TombStone (4)", [44, 2.8, 45], [-90, 0, 0], [10, 0.1, 0.8]],
        [true, "TombStone (4)", [41.51, 3.2, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [41.75, 3.2, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [42.1, 3.2, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [45.9, 3.2, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [46.25, 3.2, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
        [true, "TombStone (4)", [46.49, 3.2, 45], [0, -90, 90], [1.65, 0.05, 0.2]],
    ],
    "industry17": [  // power plant with transformer left of the center
        [false, "TombStone (4)", [-10, -2.5, 45], [0, 0, 0], [6, 8, 1]],
        [false, "TombStone (4)", [-10, 2.75, 45], [0, 0, 0], [1.5, 2.5, 1]],
        [false, "TombStone (4)", [-8.55, 4.2, 45], [0, 0, 90], [1.5, 2.5, 1]],
        [false, "TombStone (4)", [-7.07, 4, 45], [0, 0, 180], [5, 15, 1]],
        [false, "TombStone (4)", [-7.03, 13, 45], [0, 0, 181.5], [1.5, 15, 1]],
        [false, "TombStone (4)", [-7.11, 13, 45], [0, 0, 178.5], [1.5, 15, 1]],
        [false, "TombStone (4)", [-7.07, 14.95, 45], [0, 0, 180], [0.75, 1, 1]],
        [false, "TombStone (4)", [-7.07, 8, 45], [0, 0, 180], [3, 0.3, 1]],
        [false, "TombStone (4)", [-7.07, 11, 45], [0, 0, 180], [2.65, 0.3, 1]],
        [false, "TombStone (4)", [-7.07, 14, 45], [0, 0, 180], [2.3, 0.3, 1]],
        [false, "TombStone (4)", [-4.4, -0.75, 45], [0, 0, 180], [6, 2, 0.5]],
        [false, "TombStone (4)", [-4.8, -0.3, 45], [0, 0, 180], [0.5, 1, 0.51]],
        [false, "TombStone (4)", [-3.8, -0.3, 45], [0, 0, 180], [0.5, 1, 0.5]],
        [false, "TombStone (4)", [-4.3, 0.7, 45], [-90, 0, 0], [3.5, 0.1, 16]],
        [true, "TombStone (4)", [-4.3, -0.22, 45], [0, 0, 180], [0.2, 0.4, 0.5]],
        [true, "TombStone (4)", [-4.05, -0.47, 45], [0, 0, 90], [0.2, 0.4, 0.5]],
        [true, "TombStone (4)", [-4.05, -0.47, 45], [0, 0, -90], [0.2, 1.2, 0.5]],
        [true, "TombStone (4)", [-3.07, -0.47, 45], [0, 0, 90], [0.2, 1.2, 0.5]],
        [true, "TombStone (4)", [-3.07, -0.47, 45], [0, 0, -90], [0.2, 0.4, 0.5]],
        [true, "TombStone (4)", [-2.82, -0.72, 45], [0, 0, 0], [0.2, 0.4, 0.5]],
        [true, "TombStone (4)", [-2.82, -0.72, 45], [0, 0, 180], [0.2, 2, 0.5]],
        [true, "TombStone (4)", [-4.1, -0.66, 45], [0, 90, 0], [0.2, 0.4, 0.5]],
        [true, "TombStone (4)", [-3.5, -0.66, 45], [0, 90, 0], [0.2, 0.4, 0.5]],
        [true, "TombStone (4)", [-3, -0.66, 45], [0, 90, 0], [0.2, 0.4, 0.5]],
        [true, "TombStone (4)", [-3, -0.66, 45], [90, 0, -90], [0.2, 0.4, 0.5]],
        [true, "TombStone (4)", [-3, -0.96, 45], [90, 0, -90], [0.2, 0.4, 0.5]],

        [false, "TombStone (4)", [-5.6, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-5.55, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [false, "TombStone (4)", [-5.5, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-5.45, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [false, "TombStone (4)", [-5.4, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-5.35, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [false, "TombStone (4)", [-5.3, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-5.25, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-5.2, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-3.4, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-3.35, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [false, "TombStone (4)", [-3.3, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-3.25, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [false, "TombStone (4)", [-3.2, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-3.15, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [false, "TombStone (4)", [-3.1, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [true, "TombStone (4)", [-3.05, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [false, "TombStone (4)", [-3, 0.7, 45], [-90, 0, 0], [0.05, 0.05, 12]],
        [false, "TombStone (4)", [-5.45, 1.1, 45], [0, 0, -90], [0.2, 2, 1]],
        [false, "TombStone (4)", [-5.45, 0.3, 45], [0, 0, -90], [0.2, 2, 1]],
        [false, "TombStone (4)", [-3.15, 1.1, 45], [0, 0, 90], [0.2, 2, 1]],
        [false, "TombStone (4)", [-3.15, 0.3, 45], [0, 0, 90], [0.2, 2, 1]],
        [false, "TombStone (4)", [-6.5, 3.5, 45], [0, 0, -90], [0.2, 2, 1]],
        [false, "TombStone (4)", [-6.2, 4, 45], [0, 0, -90], [0.2, 2, 1]],
        [false, "TombStone (4)", [-5.9, 4.5, 45], [0, 0, -90], [0.2, 2, 1]],
        [false, "TombStone (4)", [-5.4, 3.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.5, 3.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.6, 3.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.7, 3.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.8, 3.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.1, 4, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.2, 4, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.3, 4, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.4, 4, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.5, 4, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.6, 4, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.7, 4, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.8, 4, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-4.8, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-4.9, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.0, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.1, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.2, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.3, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.4, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.5, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.6, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.7, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-5.8, 4.5, 45], [-90, 0, 0], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-4.8, 1.1, 45], [0, 0, 0], [0.2, 2, 0.5]],
        [false, "TombStone (4)", [-4.3, 1.1, 45], [0, 0, 0], [0.2, 2, 0.5]],
        [false, "TombStone (4)", [-3.8, 1.1, 45], [0, 0, 0], [0.2, 2, 0.5]],
        [true, "TombStone (4)", [-4.8, 1.7, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-4.8, 1.8, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-4.8, 1.9, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-4.8, 2.0, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-4.8, 2.1, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-4.8, 2.2, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-4.3, 1.7, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-4.3, 1.8, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-4.3, 1.9, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-4.3, 2.0, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-4.3, 2.1, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-4.3, 2.2, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-3.8, 1.7, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-3.8, 1.8, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-3.8, 1.9, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-3.8, 2.0, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [true, "TombStone (4)", [-3.8, 2.1, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-3.8, 2.2, 45], [0, 90, -90], [0.05, 0.05, 2.5]],
        [false, "TombStone (4)", [-5.08, 3.21, 45], [-84, -90, 90], [0.1, 0.05, 4.8]],
        [false, "TombStone (4)", [-5, 2.77, 45], [-72, -90, 90], [0.1, 0.05, 2.6]],
        [false, "TombStone (4)", [-4.88, 2.55, 45], [-45, -90, 90], [0.1, 0.05, 1.8]],
        [false, "TombStone (4)", [-4.77, 3.56, 45], [-84, -90, 90], [0.1, 0.05, 7.3]],
        [false, "TombStone (4)", [-4.625, 2.9, 45], [-66, -90, 90], [0.1, 0.05, 4.1]],
        [false, "TombStone (4)", [-4.42, 2.58, 45], [-42, -90, 90], [0.1, 0.05, 2.4]],
        [false, "TombStone (4)", [-4.41, 3.9, 45], [-81, -90, 90], [0.1, 0.05, 9.8]],
        [false, "TombStone (4)", [-4.16, 2.99, 45], [-64, -90, 90], [0.1, 0.05, 5.9]],
        [false, "TombStone (4)", [-3.905, 2.57, 45], [-45, -90, 90], [0.1, 0.05, 2.3]],
    ],
    "industry18": [  // factory with crane right
        [false, "TombStone (4)", [11, 4, 45], [180, 0, 0], [6, 12, 1]],
        [false, "TombStone (4)", [7.75, 1.5, 45], [180, 0, 0], [8, 8, 1]],
        [false, "TombStone (4)", [5.2, -0.5, 45], [180, 0, 0], [2.5, 2, 1]],
        [false, "TombStone (4)", [4.8, 1.1, 45], [180, 0, 0], [0.25, 3, 1]],
        [false, "TombStone (4)", [5.1, 1.3, 45], [0, 0, -90], [0.25, 3, 1]],
        [false, "TombStone (4)", [5.1, 1.6, 45], [0, 0, -155], [3.3, 0.2, 1]],
        [true, "TombStone (4)", [5.3, -0.29, 45], [-90, 0, 0], [1.4, 0.03, 0.4]],
        [true, "TombStone (4)", [5.3, -0.15, 45], [-90, 0, 0], [1.4, 0.03, 0.4]],
        [true, "TombStone (4)", [5.01, -0.22, 45], [-90, 0, 0], [0.25, 0.03, 0.8]],
        [true, "TombStone (4)", [5.3, -0.22, 45], [-90, 0, 0], [0.25, 0.03, 0.8]],
        [true, "TombStone (4)", [5.59, -0.22, 45], [-90, 0, 0], [0.25, 0.03, 0.8]],
        [true, "TombStone (4)", [5.3, -0.05, 45], [0, 0, 0], [1, 1, 0.5]],
        [true, "TombStone (4)", [5.3, 0.65, 45], [180, 0, 0], [1, 0.08, 0.5]],
        [false, "TombStone (5)", [7.9, 3, 45], [0, 0, 180], [1, 1.5, 1]],
        [true, "TombStone (5)", [7.9, 3, 45], [0, 0, 180], [1.3, 0.2, 1]],
        [true, "TombStone (5)", [6.6, 3, 45], [0, 0, 180], [1.3, 0.2, 1]],
        [false, "TombStone (5)", [6.6, 3, 45], [0, 0, 180], [1, 1.5, 1]],
        [true, "TombStone (5)", [11.9, 5, 45], [0, 0, 0], [0.6, 1, 1]],
        [true, "TombStone (5)", [11.9, 5.1, 45], [0, 0, 0], [0.3, 2, 1]],
        [true, "TombStone (5)", [11.9, 6.5, 45], [0, 0, 180], [0.4, 0.5, 1]],
        [true, "TombStone (5)", [11.9, 6.45, 45], [0, 0, 180], [0.5, 0.3, 1]],
        [false, "TombStone (5)", [10.5, 4.2, 45], [0, 0, 0], [2, 2, 1]],
        [false, "TombStone (5)", [10.5, 4.5, 45], [0, 0, 0], [1, 2, 1]],
        [false, "TombStone (5)", [10.5, 5.3, 45], [0, 0, 0], [0.5, 5, 1]],
        [false, "TombStone (5)", [9.75, 7.7, 45], [-90, 0, 0], [8, 0.1, 1]],
        [false, "TombStone (5)", [11.3, 7.5, 45], [-90, 0, 0], [0.8, 0.1, 6.5]],
        [false, "TombStone (5)", [9.12, 8.27, 45], [-69, -90, 90], [5.9, 0.05, 0.2]],
        [false, "TombStone (5)", [11.13, 8.27, 45], [49, -90, 90], [3.3, 0.05, 0.2]],
        [false, "TombStone (5)", [8.07, 6.91, 45], [-90, 0, 0], [0.05, 0.03, 12.2]],
        [false, "TombStone (5)", [7.93, 6.91, 45], [-90, 0, 0], [0.05, 0.03, 12.2]],
        [false, "TombStone (5)", [8, 6.2, 45], [0, 0, 180], [0.6, 0.5, 0.3]],
        [true, "TombStone (5)", [8, 5.85, 45], [0, 0, 180], [0.15, 0.25, 0.2]],
        [true, "TombStone (5)", [8.015 , 5.7, 45], [0, 0, -135], [0.15, 0.25, 0.2]],
        [true, "TombStone (5)", [8.1, 5.59, 45], [0, 0, 135], [0.15, 0.25, 0.2]],
        [true, "TombStone (5)", [7.985, 5.51, 45], [0, 0, 45], [0.15, 0.25, 0.2]],
    ],
    "industry19": [  // railway depot with rails
        [false, "TombStone (4)", [-22.7, 8.5, 50], [0, 0, 180], [6.6, 22, 1]],
        [false, "TombStone (4)", [-21, 11.8, 50], [0, 0, 90], [5, 4, 1]],
        [false, "TombStone (4)", [-24.4, 11.8, 50], [0, 0, -90], [5, 4, 1]],
        [false, "TombStone (4)", [-21.7, 14, 50], [0, 0, 135], [6.45, 2, 1]],
        [false, "TombStone (4)", [-23.7, 14, 50], [0, 0, -135], [6.45, 2, 1]],
        [true, "TombStone (4)", [-21.9, 15.5, 50], [0, 0, 180], [0.3, 3, 0.2]],
        [true, "TombStone (4)", [-21.9, 15.8, 50], [0, 0, 180], [0.5, 0.5, 0.2]],
        [true, "TombStone (4)", [-21.75, 16, 50], [0, 0, 135], [0.87, 0.05, 0.2]],
        [true, "TombStone (4)", [-22.05, 16, 50], [0, 0, -135], [0.87, 0.05, 0.2]],
        [true, "TombStone (4)", [-21.9, 15.83, 50], [0, 0, 0], [1.21, 0.05, 0.2]],
        [true, "TombStone (4)", [-21.9, 15.86, 50], [0, 0, 0], [0.97, 0.09, 0.2]],
        [true, "TombStone (4)", [-21.9, 15.91, 50], [0, 0, 0], [0.73, 0.1, 0.2]],
        [true, "TombStone (4)", [-21.9, 15.96, 50], [0, 0, 0], [0.5, 0.11, 0.2]],
        [true, "TombStone (4)", [-21.9, 16.01, 50], [0, 0, 0], [0.26, 0.12, 0.2]],
        [true, "TombStone (4)", [-21.9, 16.09, 50], [0, 0, 0], [0.1, 0.05, 0.2]],
        [false, "TombStone (4)", [-27.5, 5, 50], [0, 0, 0], [13, 2, 1]],
        [false, "TombStone (4)", [-27.5, 7, 50], [0, 0, 180], [13, 2, 1]],
        [false, "TombStone (4)", [-30.1, 7.7, 50], [0, 0, -135], [4.3, 2, 1]],
        [false, "TombStone (4)", [-26.73, 8.41, 50], [0, 0, 180], [11, 2, 1]],
        [false, "TombStone (4)", [-30, 4, 50], [0, 0, 180], [1, 12, 1]],
        [false, "TombStone (4)", [-29.1, 3.8, 50], [0, 0, -90], [0.6, 11, 1]],
        [true, "TombStone (4)", [-28.5, 4.1, 50], [0, 0, 90], [0.6, 0.9, 1]],
        [true, "TombStone (4)", [-28.5, 4.1, 50], [0, 0, -90], [0.6, 0.9, 1]],
        [true, "TombStone (4)", [-28.23, 3.6, 50], [0, 0, 90], [0.6, 0.6, 1]],
        [true, "TombStone (4)", [-28.77, 3.6, 50], [0, 0, -90], [0.6, 0.6, 1]],
        [true, "TombStone (4)", [-28.28, 2.9, 50], [0, 0, 0], [0.07, 1, 0.1]],
        [true, "TombStone (4)", [-28.39, 2.9, 50], [0, 0, 0], [0.07, 1, 0.1]],
        [true, "TombStone (4)", [-28.61, 2.9, 50], [0, 0, 0], [0.07, 1, 0.1]],
        [true, "TombStone (4)", [-28.72, 2.9, 50], [0, 0, 0], [0.07, 1, 0.1]],
        [true, "TombStone (4)", [-28.5, 2.7, 50], [0, 0, 0], [1.2, 0.2, 1]],
        [true, "TombStone (4)", [-28.47, 2.57, 50], [0, 0, 60], [0.6, 0.5, 1]],
        [true, "TombStone (4)", [-28.53, 2.57, 50], [0, 0, -60], [0.6, 0.5, 1]],
        [true, "TombStone (4)", [-28.5, 2.45, 50], [0, 0, 180], [0.25, 0.45, 0.5]],
        [true, "TombStone (4)", [-28.5, 2.15, 50], [0, 0, 90], [0.2, 0.35, 0.5]],
        [true, "TombStone (4)", [-28.5, 2.15, 50], [0, 0, -90], [0.2, 0.35, 0.51]],
        [true, "TombStone (4)", [-28.71, 2.175, 50], [0, 0, 0], [0.15, 0.25, 0.5]],
        [true, "TombStone (4)", [-28.29, 2.175, 50], [0, 0, 0], [0.15, 0.25, 0.51]],
        [true, "TombStone (4)", [-26.9, 9.5, 50], [0, 0, 180], [0.3, 3, 0.2]],
        [true, "TombStone (4)", [-26.9, 9.8, 50], [0, 0, 180], [0.5, 0.5, 0.2]],
        [true, "TombStone (4)", [-26.75, 10, 50], [0, 0, 135], [0.87, 0.05, 0.2]],
        [true, "TombStone (4)", [-27.05, 10, 50], [0, 0, -135], [0.87, 0.05, 0.2]],
        [true, "TombStone (4)", [-26.9, 9.83, 50], [0, 0, 0], [1.21, 0.05, 0.2]],
        [true, "TombStone (4)", [-26.9, 9.86, 50], [0, 0, 0], [0.97, 0.09, 0.2]],
        [true, "TombStone (4)", [-26.9, 9.91, 50], [0, 0, 0], [0.73, 0.1, 0.2]],
        [true, "TombStone (4)", [-26.9, 9.96, 50], [0, 0, 0], [0.5, 0.11, 0.2]],
        [true, "TombStone (4)", [-26.9, 10.01, 50], [0, 0, 0], [0.26, 0.12, 0.2]],
        [true, "TombStone (4)", [-26.9, 10.09, 50], [0, 0, 0], [0.1, 0.05, 0.2]],
        [false, "TombStone (4)", [-14.02, -0.89, 18], [0, 66, 0], [260, 0.2, 0.5]],
        [false, "TombStone (4)", [-11.98, -0.89, 18], [0, 66, 0], [260, 0.2, 0.5]],
        [true, "TombStone (4)", [-38.81, -1.25, 76], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-37.92, -1.25, 74], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-37.03, -1.25, 72], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-36.14, -1.25, 70], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-35.25, -1.25, 68], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-34.36, -1.25, 66], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-33.47, -1.25, 64], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-32.58, -1.25, 62], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-31.69, -1.25, 60], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-30.80, -1.25, 58], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-29.91, -1.25, 56], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-29.02, -1.25, 54], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-28.13, -1.25, 52], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-27.24, -1.25, 50], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-26.35, -1.25, 48], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-25.46, -1.25, 46], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-24.57, -1.25, 44], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-23.68, -1.25, 42], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-22.79, -1.25, 40], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-21.90, -1.25, 38], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-21.01, -1.25, 36], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-20.12, -1.25, 34], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-19.23, -1.25, 32], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-18.34, -1.25, 30], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-17.45, -1.25, 28], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-16.56, -1.25, 26], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-15.67, -1.25, 24], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-14.78, -1.25, 22], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-13.89, -1.25, 20], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-13.00, -1.25, 18], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-12.11, -1.25, 16], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-11.22, -1.25, 14], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-10.33, -1.25, 12], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-9.44, -1.25, 10], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-8.55, -1.25, 8], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-7.66, -1.25, 6], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-6.77, -1.25, 4], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-5.88, -1.25, 2], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-4.99, -1.25, 0], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-4.10, -1.25, -2], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-3.21, -1.25, -4], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-2.32, -1.25, -6], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [-1.43, -1.25, -8], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [-0.54, -1.25, -10], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [0.35, -1.25, -12], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [1.24, -1.25, -14], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [2.13, -1.25, -16], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [3.02, -1.25, -18], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [3.91, -1.25, -20], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [4.80, -1.25, -22], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [5.69, -1.25, -24], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [6.58, -1.25, -26], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [7.47, -1.25, -28], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [8.36, -1.25, -30], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [9.25, -1.25, -32], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [10.14, -1.25, -34], [0, -24, 0], [8, 0.6, 5]],
        [false, "TombStone (4)", [11.03, -1.25, -36], [0, -24, 0], [8, 0.6, 5]],
        [true, "TombStone (4)", [11.92, -1.25, -38], [0, -24, 0], [8, 0.6, 5]],
    ],
    "industry20": [  // oil pump
        [false, "TombStone (4)", [3.83, 9.2, 55], [0, 0, 91], [3, 0.7, 1]],
        [false, "TombStone (4)", [3.89, 9.95, 55], [0, 0, 80], [3, 0.7, 1]],
        [false, "TombStone (4)", [4.1, 10.7, 55], [0, 0, 70], [3, 0.7, 1]],
        [false, "TombStone (4)", [4.45, 11.44, 55], [0, 0, 60], [3, 0.7, 1]],
        [false, "TombStone (4)", [4.99, 12.18, 55], [0, 0, 49], [3, 0.7, 1]],
        [false, "TombStone (4)", [5.75, 12.9, 55], [0, 0, 38], [3, 0.7, 1]],
        [false, "TombStone (4)", [6.29, 12.8, 55], [0, 0, 85], [3.35, 0.5, 1]],
        [false, "TombStone (4)", [5.027, 10.404, 55], [0, 0, 59], [9, 0.5, 1]],
        [false, "TombStone (4)", [5.027, 11.014, 55], [0, 0, 59], [9, 0.5, 1]],
        [false, "TombStone (4)", [5.027, 11.624, 55], [0, 0, 59], [8.5, 0.5, 1]],
        [false, "TombStone (4)", [3.36, 7.7, 55], [0, 0, 180], [0.1, 16, 0.2]],
        [false, "TombStone (4)", [3.36, 7.55, 55], [0, 0, 180], [0.4, 0.6, 0.2]],
        [false, "TombStone (4)", [3.36, 7.05, 55], [0, 0, 0], [0.4, 0.6, 0.2]],
        [true, "TombStone (4)", [3.36, 7.1, 55], [0, 0, 0], [0.65, 0.15, 0.2]],
        [true, "TombStone (4)", [3.36, 7.5, 55], [0, 0, 180], [0.65, 0.15, 0.2]],
        [false, "TombStone (4)", [3.36, -0.6, 55], [0, 0, 180], [0.75, 2.6, 0.2]],
        [true, "TombStone (4)", [3.36, -0.6, 55], [0, 0, 0], [1, 0.75, 0.2]],
        [false, "TombStone (4)", [3.36, -0.2, 55], [-90, 0, 0], [2.5, 0.1, 2.5]],
        [false, "TombStone (4)", [3.36, 0.25, 55], [-90, 0, 0], [1.5, 0.1, 6.2]],
        [false, "TombStone (4)", [3.36, 0.7, 55], [-90, 0, 0], [2.5, 0.1, 2.5]],
        [true, "TombStone (4)", [3.36, 0.9, 55], [-90, 0, 0], [1.5, 0.1, 1]],
        [false, "TombStone (4)", [3.36, 1.2, 55], [0, 0, 180], [1, 0.75, 0.2]],
        [true, "TombStone (4)", [3.36, 1.63, 55], [0, 0, 180], [0.5, 1.5, 0.2]],
        [true, "TombStone (4)", [3.61, 0.25, 55], [-90, 0, 0], [1, 0.1, 2.5]],
        [true, "TombStone (4)", [3.86, 0.25, 55], [-90, 0, 0], [1, 0.1, 1.5]],
        [false, "TombStone (4)", [4, 0.25, 55], [-90, 0, 0], [1.2, 0.1, 0.7]],
        [false, "TombStone (4)", [4.31, 0.25, 55], [-90, 0, 0], [0.15, 0.1, 5]],
        [true, "TombStone (4)", [3, 0.25, 55], [-90, 0, 0], [2, 0.1, 2]],
        [true, "TombStone (4)", [2.5, 0.25, 55], [-90, 0, 0], [0.3, 0.1, 4]],
        [false, "TombStone (4)", [6.4, 11.35, 55], [0, 0, -115], [2, 8, 1]],
        [false, "TombStone (4)", [13.35, 8.11, 55], [0, 0, 65], [2, 8, 1]],
        [false, "TombStone (4)", [13.6, 6.73, 55], [0, 0, 0], [0.6, 1, 1]],
        [false, "TombStone (4)", [13.6, 5.6, 55], [0, 0, 180], [1, 15, 1]],
        [false, "TombStone (4)", [12.56, 6.4, 55], [0, 0, 120], [0.75, 10.5, 1]],
        [false, "TombStone (4)", [6.3, 10.22, 55], [0, 0, 15], [0.6, 1, 1]],
        [false, "TombStone (4)", [6.25, 10.39, 55], [0, 0, -165], [0.9, 1, 1]],
        [false, "TombStone (4)", [6.58, 9.18, 55], [0, 0, -165], [0.4, 6, 1]],
        [false, "TombStone (4)", [7.65, 5.2, 55], [0, 0, 15], [0.9, 1, 1]],
        [false, "TombStone (4)", [4.9, 2.4, 55], [0, 0, -45], [1.5, 6.5, 1]],
        [false, "TombStone (4)", [5.25, 2.05, 55], [0, 0, 45], [1.75, 2.3, 1]],
        [false, "TombStone (4)", [4.55, 2.75, 55], [0, 0, -135], [1.75, 2.3, 1]],
        [false, "TombStone (4)", [6.85, 1.2, 55], [0, 0, 0], [3.5, 5.5, 1]],
        [false, "TombStone (4)", [7.5, 0.3, 55], [0, 0, 150], [7, 5.5, 1]],
        [false, "TombStone (4)", [7.5, 0.3, 55], [0, 0, -120], [5, 15, 1]],
        [false, "TombStone (4)", [8.3, 3.1, 55], [0, 0, -130], [0.75, 10.5, 1]],
    ],
    "industry21": [  // some factory building in russia i've googles
        [false, "TombStone (4)", [-37.75, 10, 55], [180, 0, 0], [2.6, 22, 1]],
        [false, "TombStone (4)", [-37.75, 12.42, 55], [0, 0, -180], [0.96, 1, 1]],
        [false, "TombStone (4)", [-38.46, 12.145, 55], [0, 0, -145], [2.4, 0.36, 1]],
        [false, "TombStone (4)", [-37.04, 12.145, 55], [0, 0, 145], [2.4, 0.36, 1]],
        [false, "TombStone (4)", [-36.5, 8.2, 55], [180, 0, 0], [2.6, 20, 1]],
        [false, "TombStone (4)", [-36.5, 10.42, 55], [0, 0, -180], [0.96, 1, 1]],
        [false, "TombStone (4)", [-37.21, 10.145, 55], [0, 0, -145], [2.4, 0.36, 1]],
        [false, "TombStone (4)", [-35.79, 10.145, 55], [0, 0, 145], [2.4, 0.36, 1]],
        [false, "TombStone (4)", [-39, 6.4, 55], [180, 0, 0], [2.6, 18, 1]],
        [false, "TombStone (4)", [-39, 8.42, 55], [0, 0, -180], [0.96, 1, 1]],
        [false, "TombStone (4)", [-39.71, 8.145, 55], [0, 0, -145], [2.4, 0.36, 1]],
        [false, "TombStone (4)", [-38.29, 8.145, 55], [0, 0, 145], [2.4, 0.36, 1]],
        [false, "TombStone (4)", [-34.9, 2.2, 55], [180, 0, 0], [4, 15, 1]],
        [false, "TombStone (4)", [-35, 4.3, 55], [0, 0, 145], [4.73, 2, 1]],
        [false, "TombStone (4)", [-33.85, 3.69, 55], [0, 0, 145], [2.4, 0.36, 1]],
        [false, "TombStone (4)", [-40.6, 2.2, 55], [180, 0, 0], [4, 15, 1]],
        [false, "TombStone (4)", [-40.5, 4.3, 55], [0, 0, -145], [4.73, 2, 1]],
        [false, "TombStone (4)", [-41.65, 3.69, 55], [0, 0, -145], [2.4, 0.36, 1]],
    ],
    "industry22": [  // some more chemistry container with ladder
        [false, "TombStone (5)", [39.5, -4, 57.5], [0, 0, 0], [4, 12, 1]],
        [false, "TombStone (5)", [39.5, 11, 57.5], [180, 0, 0], [1.75, 11, 1]],
        [false, "TombStone (5)", [44, -3, 57.5], [0, 0, 0], [6, 9, 1]],
        [false, "TombStone (5)", [44, 1, 57.5], [0, 0, 0], [6, 9, 1]],
        [false, "TombStone (5)", [41.5, -1.5, 57.5], [0, 0, 0], [2.5, 4, 1]],
        [false, "TombStone (5)", [41.5, 1, 57.5], [0, 0, 0], [0.65, 2, 1]],
        [false, "TombStone (5)", [41.5, 2.8, 57.5], [0, 0, 180], [1.4, 1.2, 1]],
        [false, "TombStone (5)", [44.4, 7.2, 57.5], [0, 0, 0], [0.4, 1.3, 0.2]],
        [false, "TombStone (5)", [44.4, 7.9, 57.5], [0, 0, 0], [0.4, 0.6, 0.2]],
        [true, "TombStone (5)", [44.06, 8.24, 57.5], [0, 0, -90], [0.4, 0.6, 0.2]],
        [true, "TombStone (5)", [40.2, 8.24, 57.5], [0, 0, 90], [0.4, 0.6, 0.2]],
        [false, "TombStone (5)", [42.1, 8.24, 57.5], [-90, 0, 0], [9.5, 0.02, 1]],
        [true, "TombStone (5)", [41.23, 8.24, 57.5], [0, 0, 90], [0.5, 0.65, 0.2]],
        [true, "TombStone (5)", [40.57, 8.24, 57.5], [0, 0, -90], [0.5, 0.65, 0.2]],
        [true, "TombStone (5)", [41.15, 8.24, 57.5], [-90, 0, 0], [0.2, 0.02, 3.5]],
        [true, "TombStone (5)", [40.65, 8.24, 57.5], [-90, 0, 0], [0.2, 0.02, 3.5]],
        [true, "TombStone (5)", [40.9, 8.17, 57.5], [0, 0, 180], [0.35, 0.35, 0.2]],
        [true, "TombStone (5)", [40.9, 8.05, 57.5], [0, 0, 180], [0.15, 0.4, 0.2]],
        [true, "TombStone (5)", [40.9, 7.79, 57.5], [-90, 0, 0], [0.8, 0.02, 0.5]],
        [false, "TombStone (5)", [43.6, 7.2, 57.5], [0, 0, 0], [0.4, 0.6, 0.2]],
        [false, "TombStone (5)", [43.6, 7.5, 57.5], [0, 0, 0], [0.4, 0.6, 0.2]],
        [true, "TombStone (5)", [43.26, 7.84, 57.5], [0, 0, -90], [0.4, 0.6, 0.2]],
        [false, "TombStone (5)", [42.625, 7.84, 57.5], [-90, 0, 0], [4.14, 0.02, 1]],
        [true, "TombStone (5)", [41.99, 7.84, 57.5], [0, 0, 90], [0.4, 0.6, 0.2]],
        [true, "TombStone (5)", [41.65, 7.5, 57.5], [0, 0, 0], [0.4, 0.6, 0.2]],
        [false, "TombStone (5)", [41.65, 5.2, 57.5], [-90, 0, 0], [0.25, 0.02, 43]],
        [false, "TombStone (5)", [41.35, 4.74, 57.5], [-90, 0, 0], [0.25, 0.02, 35]],
        [true, "TombStone (5)", [41.35, 6.5, 57.5], [0, 0, 0], [0.4, 0.6, 0.2]],
        [true, "TombStone (5)", [41.01, 6.84, 57.5], [0, 0, -90], [0.4, 0.6, 0.2]],
        [true, "TombStone (5)", [40.2, 6.84, 57.5], [0, 0, 90], [0.4, 0.6, 0.2]],
        [false, "TombStone (5)", [40.6, 6.84, 57.5], [-90, 0, 0], [3.24, 0.02, 1]],
        [false, "TombStone (5)", [43, 5.5, 57.5], [0, 0, 90], [1, 7.5, 1]],
        [false, "TombStone (5)", [38.8, 5.5, 57.5], [0, 0, 90], [1, 1.8, 1]],
        [false, "TombStone (5)", [38.8, 2.5, 57.5], [0, 0, 90], [1, 1.8, 1]],
        [false, "TombStone (5)", [37.7, 4.4, 57.5], [0, 0, 0], [1, 1.8, 1]],
        [false, "TombStone (5)", [37.7, 3.6, 57.5], [0, 0, 0], [1, 1.8, 1]],
        [false, "TombStone (5)", [37.7, 3.6, 57.5], [0, 0, 180], [1, 1.8, 1]],
        [true, "TombStone (5)", [39.5, 6.5, 57.5], [-90, 0, 0], [5.2, 0.02, 0.7]],
        [true, "TombStone (5)", [39.5, 6.8, 57.5], [-90, 0, 0], [5.2, 0.02, 0.3]],
        [true, "TombStone (5)", [39.5, 7.1, 57.5], [-90, 0, 0], [5.2, 0.02, 0.3]],
        [true, "TombStone (5)", [39.5, 7.33, 57.5], [-90, 0, 0], [5.2, 0.02, 0.3]],
        [true, "TombStone (5)", [38.22, 6.9, 57.5], [0, -90, 90], [1.7, 0.02, 0.3]],
        [true, "TombStone (5)", [38.42, 6.9, 57.5], [0, -90, 90], [1.7, 0.02, 0.3]],
        [true, "TombStone (5)", [38.72, 6.9, 57.5], [0, -90, 90], [1.7, 0.02, 0.3]],
        [true, "TombStone (5)", [40.78, 6.9, 57.5], [0, -90, 90], [1.7, 0.02, 0.3]],
        [true, "TombStone (5)", [40.58, 6.9, 57.5], [0, -90, 90], [1.7, 0.02, 0.3]],
        [true, "TombStone (5)", [40.28, 6.9, 57.5], [0, -90, 90], [1.7, 0.02, 0.3]],
        [true, "TombStone (5)", [38.65, 5.5, 57.5], [0, -90, 90], [4, 0.02, 0.3]],
        [true, "TombStone (5)", [38.35, 3.6, 57.5], [-18.5, -90, 90], [3.82, 0.02, 0.3]],
        [true, "TombStone (5)", [38.05, 0.5, 57.5], [0, -90, 90], [7.5, 0.02, 0.3]],
        [true, "TombStone (5)", [38.87, 6.1, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.87, 4.9, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.87, 4.5, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.77, 4.1, 57.5], [-90, 0, 0], [1, 0.02, 0.3]],
        [true, "TombStone (5)", [38.64, 3.7, 57.5], [-90, 0, 0], [1, 0.02, 0.3]],
        [true, "TombStone (5)", [38.51, 3.3, 57.5], [-90, 0, 0], [1, 0.02, 0.3]],
        [true, "TombStone (5)", [38.38, 2.9, 57.5], [-90, 0, 0], [1, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, 2.1, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, 1.7, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, 1.3, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, 0.9, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, 0.5, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, 0.1, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, -0.3, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, -0.7, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
        [true, "TombStone (5)", [38.28, -1.1, 57.5], [-90, 0, 0], [0.9, 0.02, 0.3]],
    ],
    "industry23": [  // cooling tower
        [false, "TombStone (4)", [-31.5, 13, 69.14], [180, -23, -15], [24, 35, 1]],
        [false, "TombStone (4)", [-33.0, 25, 68.5], [180, -23, 0], [27, 20, 1]],
        [false, "TombStone (4)", [-34.5, 13, 67.86], [180, -23, 15], [24, 35, 1]],
    ],
    "industry24": [  // big block factory building
        [false, "TombStone (4)", [28.5, 13.75, 67.5], [180, 60, 0], [20, 30, 100]],
        [false, "TombStone (4)", [26.45, 18.5, 67.5], [180, 60, 0], [6, 2, 15]],
        [false, "TombStone (4)", [25.7, 20.25, 67.5], [180, 60, 0], [1.6, 4, 8]],
        [false, "TombStone (4)", [26.45, 19.5, 67.5], [180, 60, 0], [1, 3, 6]],
        [false, "TombStone (4)", [28, 22.5, 62.5], [180, 27, 0], [5, 12, 1]],
        [false, "TombStone (4)", [28, 23, 62.5], [0, 27, 0], [5, 2, 1]],
        [true, "TombStone (4)", [28, 23, 62.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [true, "TombStone (4)", [28, 21.5, 62.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [true, "TombStone (4)", [28, 20, 62.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [false, "TombStone (4)", [23, 21.5, 67.5], [180, 27, 0], [5, 12, 1]],
        [false, "TombStone (4)", [23, 22, 67.5], [0, 27, 0], [5, 2, 1]],
        [true, "TombStone (4)", [23, 22.5, 67.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [true, "TombStone (4)", [23, 20.75, 67.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [true, "TombStone (4)", [23, 19.5, 67.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [false, "TombStone (4)", [34.5, 20.5, 67.5], [180, 27, 0], [5, 12, 1]],
        [false, "TombStone (4)", [34.5, 21, 67.5], [0, 27, 0], [5, 2, 1]],
        [true, "TombStone (4)", [34.5, 21, 67.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [true, "TombStone (4)", [34.5, 20, 67.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [true, "TombStone (4)", [34.5, 19, 67.5], [-90, 27, 0], [5.5, 0.1, 2]],
        [true, "TombStone (4)", [35.5, 23.5, 67], [180, 27, 0], [0.2, 4, 0.5]],
        [true, "TombStone (4)", [25.35, 22.5, 67], [180, 60, 0], [0.2, 6, 1]],
        [true, "TombStone (4)", [25.35, 23, 67], [-90, 0, 0], [2, 0.1, 0.5]],
        [true, "TombStone (4)", [25.35, 21.75, 67], [-90, 0, 0], [1.5, 0.1, 0.5]],
        [true, "TombStone (4)", [25, 22.35, 67], [0, 0, 94], [4, 0.4, 0.5]],
        [true, "TombStone (4)", [25.7, 22.35, 67], [0, 0, -94], [4, 0.4, 0.5]],
        [true, "TombStone (4)", [27.75, 21.25, 67], [180, 60, 0], [0.3, 6, 1]],
        [true, "TombStone (4)", [27.65, 21.25, 67], [0, 0, 90], [1, 1.5, 1]],
        [true, "TombStone (4)", [27.75, 22.25, 67], [180, 60, 0], [0.15, 2, 0.3]],
        [true, "TombStone (4)", [27.75, 22.25, 67], [-90, 0, 0], [1, 0.1, 0.5]],
        [true, "TombStone (4)", [27.5, 22.25, 67], [0, 0, 90], [0.5, 0.3, 0.1]],
        [true, "TombStone (4)", [28, 22.25, 67], [0, 0, -90], [0.5, 0.3, 0.1]],
    ],
    "industry25": [  // waste incineration power plant (Fernwärme Wien)
        [false, "TombStone (5)", [-3.52, -1.5, 65], [0, 0, 0], [1.6, 12.5, 1]],
        [false, "TombStone (5)", [-3.52, 5.2, 65], [0, 0, 0], [1.6, 3, 1]],
        [false, "TombStone (5)", [-5.02, 7.8, 65], [0, 0, -120], [1.6, 3, 1]],
        [false, "TombStone (5)", [-3.92, 7.165, 65], [0, 0, 60], [1.6, 3, 1]],
        [false, "TombStone (5)", [-5.97, 9.6, 65], [0, 0, 200], [1.6, 3, 1]],
        [false, "TombStone (5)", [-6.5, 19.48, 65], [-1.9, 90, -90], [41, 0.1, 8]],
        [false, "TombStone (5)", [-7.7, 19.48, 65], [1.9, 90, -90], [41, 0.1, 8]],
        [false, "TombStone (5)", [-7.1, 25, 65], [0, 0, 180], [2.41, 50, 1]],
        [false, "TombStone (5)", [-6.5, 13.7, 65], [-1.7, 90, -90], [65, 0.1, 8]],
        [false, "TombStone (5)", [-7.7, 13.7, 65], [1.7, 90, -90], [65, 0.1, 8]],
        [false, "TombStone (5)", [-6.7, 31, 65], [0, 0, 180], [1.2, 2, 1]],
        [false, "TombStone (5)", [-7.5, 31, 65], [0, 0, 180], [1.2, 2, 1]],
        [false, "TombStone (5)", [-7.7, 29.4, 65], [0, 0, -90], [2, 3, 1]],
        [false, "TombStone (5)", [-6.5, 29.4, 65], [0, 0, 90], [2, 3, 1]],
        [false, "TombStone (5)", [-7.1, 27.4, 65], [-90, 0, 0], [4.5, 0.1, 6]],
        [true, "TombStone (5)", [-7.1, 10, 65], [-90, 0, 0], [12, 0.05, 3]],
        [true, "TombStone (5)", [-7.1, 10.9, 65], [-90, 0, 0], [12, 0.05, 0.6]],
        [true, "TombStone (5)", [-7.1, 11.45, 65], [-90, 0, 0], [12, 0.05, 0.6]],
        [true, "TombStone (5)", [-4.14, 10.7, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-4.54, 10.7, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-5.14, 10.7, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-9.06, 10.7, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-9.66, 10.7, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-10.06, 10.7, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [false, "TombStone (5)", [-7.1, 20.5, 65], [-90, 0, 0], [9, 0.05, 3]],
        [true, "TombStone (5)", [-7.1, 21.4, 65], [-90, 0, 0], [9, 0.05, 0.6]],
        [false, "TombStone (5)", [-7.1, 21.95, 65], [-90, 0, 0], [9, 0.05, 0.6]],
        [false, "TombStone (5)", [-4.89, 21.2, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-5.19, 21.2, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-5.59, 21.2, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-8.61, 21.2, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-9.01, 21.2, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [false, "TombStone (5)", [-9.31, 21.2, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [false, "TombStone (5)", [-7.1, 22.4, 65], [-90, 0, 0], [12, 0.05, 3]],
        [true, "TombStone (5)", [-7.1, 23.3, 65], [-90, 0, 0], [12, 0.05, 0.6]],
        [false, "TombStone (5)", [-7.1, 23.85, 65], [-90, 0, 0], [12, 0.05, 0.6]],
        [false, "TombStone (5)", [-4.14, 23.1, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-4.54, 23.1, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-5.14, 23.1, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-9.06, 23.1, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-9.66, 23.1, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [false, "TombStone (5)", [-10.06, 23.1, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [false, "TombStone (5)", [-7.1, 24.3, 65], [-90, 0, 0], [7, 0.05, 3]],
        [true, "TombStone (5)", [-7.1, 25.2, 65], [-90, 0, 0], [7, 0.05, 0.6]],
        [false, "TombStone (5)", [-7.1, 25.75, 65], [-90, 0, 0], [7, 0.05, 0.6]],
        [false, "TombStone (5)", [-5.39, 25, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-5.59, 25, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-5.89, 25, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-8.31, 25, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [true, "TombStone (5)", [-8.61, 25, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [false, "TombStone (5)", [-8.81, 25, 65], [0, 90, -90], [3, 0.05, 0.6]],
        [false, "TombStone (5)", [-6.7, 23.2, 65], [0, 0, 86.2], [10.6, 2.6, 1]],
        [false, "TombStone (5)", [-7.5, 23.2, 65], [0, 0, -86.2], [10.6, 2.6, 1]],
        [false, "TombStone (5)", [-8.22, 9.6, 65], [0, 0, -200], [1.6, 3, 1]],
        [false, "TombStone (5)", [-10.48, 8.55, 65], [0, 0, -110], [1.6, 3, 1]],
        [false, "TombStone (5)", [-10.892, 8.7, 65], [0, 0, 70], [1.6, 3, 1]],
        [false, "TombStone (5)", [-12.76, 9.255, 65], [0, 0, 90], [1.6, 3, 1]],
        [false, "TombStone (5)", [-13.62, 7.5, 65], [0, 0, 180], [5, 18, 1]],
        [true, "TombStone (5)", [-13.62, 9.8, 65], [0, 0, 180], [2.5, 0.5, 1]],
        [false, "TombStone (5)", [-13.62, 10.3, 65], [0, 0, 180], [1, 1.5, 1]],
        [false, "TombStone (5)", [-13.62, 10.2, 65], [0, 0, 0], [0.5, 1.5, 1]],
        [true, "TombStone (5)", [-13.62, 10.5, 65], [0, 0, 0], [1.5, 0.2, 1]],
        [true, "TombStone (5)", [-13.62, 10.5, 65], [0, 0, 180], [1.5, 0.2, 1]],
        [true, "TombStone (5)", [-12.92, 9.7, 65], [0, 0, 90], [1.5, 0.2, 1]],
        [true, "TombStone (5)", [-12.92, 9.7, 65], [0, 0, -90], [1.5, 0.2, 1]],
        [true, "TombStone (5)", [-14.32, 9.7, 65], [0, 0, 90], [1.5, 0.2, 1]],
        [true, "TombStone (5)", [-14.32, 9.7, 65], [0, 0, -90], [1.5, 0.2, 1]],
        [false, "TombStone (5)", [-13.62, 11.1, 65], [0, 0, 90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [-13.62, 11.1, 65], [0, 0, -90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [-17.42, 2, 65], [0, 0, 180], [7, 8, 1]],
        [false, "TombStone (5)", [-17.42, 2, 65], [0, 0, 0], [7, 6, 1]],
        [false, "TombStone (5)", [-17.42, 5.1, 65], [0, 0, 0], [1.6, 3, 1]],
        [false, "TombStone (5)", [-16.02, 7.8, 65], [0, 0, 125], [1.6, 3, 1]],
        [false, "TombStone (5)", [-16.02, 7.8, 65], [0, 0, -55], [1.6, 3, 1]],
    ],
    "industry26": [  // oil rig
        [false, "TombStone (5)", [43.3, 15, 70], [0, 0, 180], [4, 30, 1]],
        [false, "TombStone (5)", [52.05, 15, 70], [0, 0, 180], [4, 30, 1]],
        [false, "TombStone (5)", [60.8, 15, 70], [0, 0, 180], [4, 30, 1]],
        [false, "TombStone (5)", [52.05, 11.8, 70], [-90, 0, 0], [42, 0.1, 5]],
        [false, "TombStone (5)", [52.05, 14.3, 70], [-90, 0, 0], [42, 0.1, 5]],
        [false, "TombStone (5)", [52.05, 16.5, 70], [-90, 0, 0], [42, 0.1, 3]],
        [false, "TombStone (5)", [52.05, 18, 70], [-90, 0, 0], [42, 0.1, 3]],
        [true, "TombStone (5)", [41.9, 13.05, 70], [0, 90, -90], [4.5, 0.1, 0.8]],
        [true, "TombStone (5)", [43.3, 13.05, 70], [-55, 90, -90], [7, 0.1, 0.8]],
        [true, "TombStone (5)", [44.7, 13.05, 70], [0, 90, -90], [4.5, 0.1, 0.8]],
        [true, "TombStone (5)", [46.188, 13.05, 70], [57, 90, -90], [7, 0.1, 0.8]],
        [true, "TombStone (5)", [47.675, 13.05, 70], [0, 90, -90], [4.5, 0.1, 0.8]],
        [true, "TombStone (5)", [49.163, 13.05, 70], [-57, 90, -90], [7, 0.1, 0.8]],
        [true, "TombStone (5)", [50.65, 13.05, 70], [0, 90, -90], [4.5, 0.1, 0.8]],
        [true, "TombStone (5)", [53.45, 13.05, 70], [0, 90, -90], [4.5, 0.1, 0.8]],
        [true, "TombStone (5)", [54.938, 13.05, 70], [57, 90, -90], [7, 0.1, 0.8]],
        [true, "TombStone (5)", [56.425, 13.05, 70], [0, 90, -90], [4.5, 0.1, 0.8]],
        [true, "TombStone (5)", [57.913, 13.05, 70], [-57, 90, -90], [7, 0.1, 0.8]],
        [true, "TombStone (5)", [59.4, 13.05, 70], [0, 90, -90], [4.5, 0.1, 0.8]],
        [true, "TombStone (5)", [60.8, 13.05, 70], [55, 90, -90], [7, 0.1, 0.8]],
        [true, "TombStone (5)", [62.2, 13.05, 70], [0, 90, -90], [4.5, 0.1, 0.8]],
        [true, "TombStone (5)", [41.9, 17.25, 70], [0, 90, -90], [3, 0.1, 0.8]],
        [true, "TombStone (5)", [43.3, 17.25, 70], [-68, 90, -90], [6, 0.1, 0.8]],
        [true, "TombStone (5)", [44.7, 17.25, 70], [0, 90, -90], [3, 0.1, 0.8]],
        [true, "TombStone (5)", [46.188, 17.25, 70], [70, 90, -90], [6.5, 0.1, 0.8]],
        [true, "TombStone (5)", [47.675, 17.25, 70], [0, 90, -90], [3, 0.1, 0.8]],
        [true, "TombStone (5)", [49.163, 17.25, 70], [-70, 90, -90], [6.5, 0.1, 0.8]],
        [true, "TombStone (5)", [50.65, 17.25, 70], [0, 90, -90], [3, 0.1, 0.8]],
        [true, "TombStone (5)", [53.45, 17.25, 70], [0, 90, -90], [3, 0.1, 0.8]],
        [true, "TombStone (5)", [54.938, 17.25, 70], [70, 90, -90], [6.5, 0.1, 0.8]],
        [true, "TombStone (5)", [56.425, 17.25, 70], [0, 90, -90], [3, 0.1, 0.8]],
        [true, "TombStone (5)", [57.913, 17.25, 70], [-70, 90, -90], [6.5, 0.1, 0.8]],
        [true, "TombStone (5)", [59.4, 17.25, 70], [0, 90, -90], [3, 0.1, 0.8]],
        [true, "TombStone (5)", [60.8, 17.25, 70], [68, 90, -90], [6, 0.1, 0.8]],
        [true, "TombStone (5)", [62.2, 17.25, 70], [0, 90, -90], [3, 0.1, 0.8]],
        [true, "TombStone (5)", [44.55, 10.45, 70], [0, 90, -90], [0.4, 0.05, 6]],
        [true, "TombStone (5)", [44.55, 7.45, 70], [0, 90, -90], [0.4, 0.05, 6]],
        [true, "TombStone (5)", [44.55, 4.45, 70], [0, 90, -90], [0.4, 0.05, 6]],
        [true, "TombStone (5)", [44.55, 1.45, 70], [0, 90, -90], [0.4, 0.05, 6]],
        [true, "TombStone (5)", [45.35, 11.3, 70], [0, 90, -90], [1.5, 0.05, 1.6]],
        [true, "TombStone (5)", [46.5, 11.3, 70], [0, 90, -90], [1.5, 0.05, 1.6]],
        [false, "TombStone (5)", [44.65, 4, 70], [0, 90, -90], [28, 0.05, 2.4]],
        [false, "TombStone (5)", [44.65, 10.45, 70], [0, 0, 0], [0.6, 1.2, 0.1]],
        [false, "TombStone (5)", [45.4, 11.2, 70], [0, 0, 90], [0.6, 1.2, 0.1]],
        [false, "TombStone (5)", [45.9, 11.2, 70], [0, 90, -90], [0.6, 0.05, 10]],
        [false, "TombStone (5)", [46.45, 11.2, 70], [0, 0, -90], [0.6, 1.2, 0.1]],
        [false, "TombStone (5)", [47.2, 11.95, 70], [0, 0, 180], [0.6, 1.2, 0.1]],
        [false, "TombStone (5)", [47.2, 11.95, 70], [0, 0, 0], [0.6, 1.2, 0.1]],
        [false, "TombStone (5)", [48, 13, 70], [0, 0, 90], [2.8, 2.8, 0.1]],
        [false, "TombStone (5)", [47.5, 13, 70], [0, 0, -90], [2.8, 2.8, 0.1]],
        [false, "TombStone (5)", [46.5, 13.05, 70], [0, 90, -90], [4.5, 0.1, 1.2]],
        [false, "TombStone (5)", [48.9, 13.05, 70], [0, 90, -90], [4.5, 0.1, 1.2]],
        [false, "TombStone (5)", [50.1, 20, 70], [0, 0, 180], [1, 40, 1]],
        [false, "TombStone (5)", [50.1, 23.1, 70], [0, 90, -90], [2, 0.1, 8]],
        [false, "TombStone (5)", [50.1, 23.4, 70], [0, 90, -90], [1, 0.1, 11]],
        [false, "TombStone (5)", [49.8, 24.2, 70], [25, 90, -90], [2.9, 0.1, 1.6]],
        [false, "TombStone (5)", [50.4, 24.2, 70], [-25, 90, -90], [2.9, 0.1, 1.6]],
        [false, "TombStone (5)", [50.1, 25.7, 70], [0, 0, 180], [1.7, 1.5, 0.5]],
        [false, "TombStone (5)", [50.1, 30.4, 70], [0, 0, 0], [1.7, 1.7, 0.5]],
        [false, "TombStone (5)", [49.9, 28, 70], [0, 90, -90], [10, 0.1, 1.3]],
        [false, "TombStone (5)", [50.3, 28, 70], [0, 90, -90], [10, 0.1, 1.3]],
        [false, "TombStone (5)", [48.9, 24.3, 70], [6.3, 90, -90], [25.5, 0.1, 2]],
        [false, "TombStone (5)", [51.3, 24.3, 70], [-6.3, 90, -90], [25.5, 0.1, 2]],
        [false, "TombStone (5)", [49.9, 19.8, 70], [45, 90, -90], [10, 0.1, 0.5]],
        [false, "TombStone (5)", [50.3, 19.8, 70], [-45, 90, -90], [10, 0.1, 0.5]],
        [false, "TombStone (5)", [49.9, 22.7, 70], [45, 90, -90], [8, 0.1, 0.5]],
        [false, "TombStone (5)", [50.3, 22.7, 70], [-45, 90, -90], [8, 0.1, 0.5]],
        [false, "TombStone (5)", [49.95, 25.1, 70], [45, 90, -90], [6, 0.1, 0.5]],
        [false, "TombStone (5)", [50.25, 25.1, 70], [-45, 90, -90], [6, 0.1, 0.5]],
        [false, "TombStone (5)", [50, 27, 70], [45, 90, -90], [5, 0.1, 0.5]],
        [false, "TombStone (5)", [50.2, 27, 70], [-45, 90, -90], [5, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 28.6, 70], [45, 90, -90], [4, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 28.6, 70], [-45, 90, -90], [4, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 29.8, 70], [45, 90, -90], [3.5, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 29.8, 70], [-45, 90, -90], [3.5, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 29.8, 70], [90, 90, -90], [2.6, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 29.2, 70], [90, 90, -90], [2.9, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 28.6, 70], [90, 90, -90], [3.2, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 27.85, 70], [90, 90, -90], [3.5, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 27.1, 70], [90, 90, -90], [3.9, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 26.18, 70], [90, 90, -90], [4.3, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 25.25, 70], [90, 90, -90], [4.6, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 24.08, 70], [90, 90, -90], [5, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 22.9, 70], [90, 90, -90], [5.4, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 21.45, 70], [90, 90, -90], [5.8, 0.1, 0.5]],
        [true, "TombStone (5)", [50.1, 20, 70], [90, 90, -90], [6.3, 0.1, 0.5]],
        [false, "TombStone (5)", [60.8, 18, 70], [0, 0, 0], [2.5, 3, 1]],
        [false, "TombStone (5)", [60.8, 20, 70], [0, 0, 0], [1.5, 2.5, 1]],
        [true, "TombStone (5)", [61.2, 22.9, 70], [0, 0, -90], [2, 0.8, 1]],
        [false, "TombStone (5)", [61.2, 21.8, 70], [0, 0, -90], [4, 1.4, 1]],
        [false, "TombStone (5)", [58, 23.6, 70], [30, 90, -90], [1.2, 0.1, 60]],
        [false, "TombStone (5)", [59.4, 21.5, 70], [60, 90, -90], [0.6, 0.1, 32]],
        [false, "TombStone (5)", [54.8, 24.2, 70], [0, 90, -90], [4, 0.1, 1]],
        [false, "TombStone (5)", [54.4, 23, 70], [60, 90, -90], [2.1, 0.1, 1]],
        [false, "TombStone (5)", [55.2, 23, 70], [-60, 90, -90], [2.1, 0.1, 1]],
        [false, "TombStone (5)", [54.8, 22.3, 70], [0, 90, -90], [2, 0.1, 14]],
        [false, "TombStone (5)", [53.35, 19.05, 70], [90, 90, -90], [2, 0.1, 14]],
        [false, "TombStone (5)", [54.8, 18.7, 70], [0, 90, -90], [2, 0.1, 14]],
        [false, "TombStone (5)", [56.6, 19.7, 70], [0, 90, -90], [6, 0.1, 14]],
        [false, "TombStone (5)", [58.4, 19.2, 70], [0, 90, -90], [4, 0.1, 14]],
        [false, "TombStone (5)", [43.3, 22, 70], [0, 0, 180], [2, 10, 1]],
        [false, "TombStone (5)", [43.3, 24, 70], [0, 0, 180], [3.5, 2, 1]],
        [true, "TombStone (5)", [42.7, 26, 70], [0, 0, 180], [0.2, 3, 1]],
        [false, "TombStone (5)", [45.0, 18.2, 70], [0, 0, 0], [2.5, 3.5, 1]],
        [false, "TombStone (5)", [45.0, 20.6, 70], [0, 0, 0], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.5, 21.1, 70], [0, 0, 90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.4, 21.1, 70], [0, 0, -90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.9, 20.6, 70], [0, 0, 0], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.9, 19.3, 70.04], [-90, 0, 0], [0.4, 0.17, 26]],
        [false, "TombStone (5)", [45.9, 18, 70], [0, 0, 180], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.4, 17.5, 70], [0, 0, -90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.7, 17.5, 70], [0, 0, 90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.2, 17, 70], [0, 0, 0], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.2, 15.25, 70.04], [-90, 0, 0], [0.4, 0.17, 33]],
        [false, "TombStone (5)", [45.2, 13.5, 70], [0, 0, 180], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [45.7, 13, 70], [0, 0, 90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [46.2, 13, 70], [0, 0, 90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [47.2, 18.2, 70], [0, 0, 0], [2.5, 3.5, 1]],
        [false, "TombStone (5)", [47.2, 20.6, 70], [0, 0, 0], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [46.7, 21.1, 70], [0, 0, -90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [46.8, 21.1, 70], [0, 0, 90], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [46.3, 20.6, 70], [0, 0, 0], [0.4, 0.8, 1]],
        [false, "TombStone (5)", [46.3, 18.3, 70.04], [-90, 0, 0], [0.4, 0.17, 43]],
        [true, "TombStone (5)", [46.3, 15.85, 70], [0, 90, -90], [1.3, 0.1, 4]],
        [false, "TombStone (5)", [46.3, 15.3, 70], [0, 90, -90], [2.8, 0.1, 7]],
        [true, "TombStone (5)", [46.7, 15.3, 70], [0, 90, -90], [1.8, 0.1, 4]],
        [false, "TombStone (5)", [47.4, 15.3, 70], [0, 90, -90], [1.1, 0.1, 11]],
        [true, "TombStone (5)", [48.1, 15.3, 70], [0, 90, -90], [1.8, 0.1, 4]],
        [false, "TombStone (5)", [48.5, 15.3, 70], [0, 90, -90], [2.8, 0.1, 7]],
        [false, "TombStone (5)", [48.4, 15.3, 70], [0, 90, -90], [1.8, 0.1, 2]],
        [true, "TombStone (5)", [45.56, 15.3, 70.04], [-90, 0, 0], [0.25, 0.17, 6]],
        [true, "TombStone (5)", [47.4, 15.75, 70], [0, 90, -90], [1, 0.1, 1.8]],
        [true, "TombStone (5)", [47.4, 16, 70], [0, 90, -90], [0.25, 0.1, 5]],
        [true, "TombStone (5)", [49, 15.3, 70], [0, 90, -90], [1, 0.1, 2]],
        [false, "TombStone (5)", [49.25, 15.3, 70.04], [-90, 0, 0], [15, 0.17, 2]],
        [false, "TombStone (5)", [47, 17, 70], [-90, 0, 0], [1.6, 0.1, 5]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [0, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [20, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [40, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [60, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [80, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [100, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [120, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [140, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [48.3, 17.05, 70], [160, 90, -90], [1.4, 0.1, 1.2]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [0, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [20, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [40, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [60, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [80, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [100, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [120, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [140, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [49.1, 17.1, 70], [160, 90, -90], [1.8, 0.1, 1.6]],
        [false, "TombStone (5)", [54.5, 12, 70], [0, 0, 0], [2, 5, 1]],
        [false, "TombStone (5)", [54.5, 14, 70], [0, 0, 0], [2, 3, 1]],
        [false, "TombStone (5)", [54.5, 11.95, 70], [0, 0, 180], [0.7, 1.4, 1]],
        [false, "TombStone (5)", [55.35, 11.1, 70], [0, 0, 90], [0.7, 1.4, 1]],
        [false, "TombStone (5)", [57.6, 11.1, 70.04], [0, 90, -90], [0.7, 0.17, 45]],
        [true, "TombStone (5)", [55.3, 11.2, 70], [0, 90, -90], [1.7, 0.17, 2]],
        [true, "TombStone (5)", [57.1, 11.2, 70], [0, 90, -90], [1.7, 0.17, 2]],
        [true, "TombStone (5)", [58.9, 11.2, 70], [0, 90, -90], [1.7, 0.17, 2]],
        [false, "TombStone (5)", [53.0, 15.3, 70], [0, 0, -90], [0.5, 0.8, 1]],
        [false, "TombStone (5)", [53.5, 14.8, 70], [0, 0, 0], [0.5, 0.8, 1]],
        [false, "TombStone (5)", [53.5, 14, 70.04], [-90, 0, 0], [0.5, 0.17, 16]],
        [false, "TombStone (5)", [53.5, 13.2, 70], [0, 0, 180], [0.5, 0.8, 1]],
        [false, "TombStone (5)", [54, 12.7, 70], [0, 0, 90], [0.5, 0.8, 1]],
        [false, "TombStone (5)", [56.2, 12, 70], [0, 0, 0], [3.5, 1.8, 1]],
        [false, "TombStone (5)", [58.3, 12, 70], [0, 0, 0], [3.5, 1.8, 1]],
        [true, "TombStone (5)", [55.4, 13.7, 70.04], [30, 90, -90], [0.5, 0.17, 20]],
        [true, "TombStone (5)", [56.6, 14.2, 70.04], [30, 90, -90], [0.5, 0.17, 35]],
        [false, "TombStone (5)", [54.5, 16.4, 70.04], [-90, 0, 0], [0.35, 0.17, 10]],
        [false, "TombStone (5)", [54.5, 16.85, 70], [0, 0, 0], [0.35, 0.65, 1]],
        [false, "TombStone (5)", [54.9, 17.25, 70], [0, 0, 90], [0.35, 0.65, 1]],
        [false, "TombStone (5)", [56.7, 17.25, 70], [0, 0, 90], [1.5, 2.5, 1]],
        [false, "TombStone (5)", [57.1, 17.25, 70], [0, 0, -90], [1.5, 2.5, 1]],
        [false, "TombStone (5)", [55.6, 17.25, 70.04], [-90, 0, 0], [0.5, 0.17, 12]],
        [false, "TombStone (5)", [58.2, 17.25, 70.04], [-90, 0, 0], [0.5, 0.17, 12]],
        [true, "TombStone (5)", [56.9, 15, 70], [0, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [56.9, 15, 70], [20, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [56.9, 15, 70], [40, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [56.9, 15, 70], [60, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [56.9, 15, 70], [80, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [56.9, 15, 70], [100, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [56.9, 15, 70], [120, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [56.9, 15, 70], [140, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [56.9, 15, 70], [160, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [0, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [20, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [40, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [60, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [80, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [100, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [120, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [140, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.8, 15, 70], [160, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [0, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [20, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [40, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [60, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [80, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [100, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [120, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [140, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.7, 15, 70], [160, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [0, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [20, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [40, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [60, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [80, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [100, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [120, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [140, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [57.35, 15.8, 70], [160, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [0, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [20, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [40, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [60, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [80, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [100, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [120, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [140, 90, -90], [1.8, 0.1, 1.6]],
        [true, "TombStone (5)", [58.25, 15.8, 70], [160, 90, -90], [1.8 , 0.1, 1.6]],
    ],
}

const destroy_steps = 5 // needs to be at least 5 to not look oddly symmetrical
for (let track_name in industry) {
    let parts = []
    for (let i = 0; i < industry[track_name].length; i++) {
        //let part_name = track_name + "_" + i
        let part_name = track_name + "_" + (i % destroy_steps)
        let element = {
            "id": industry[track_name][i][1],
            "lookupMethod": "EndsWith",
            "duplicate": 1,
            "active": true,
            "track": part_name,
            "position": industry[track_name][i][2],
            "rotation": industry[track_name][i][3],
            "scale": industry[track_name][i][4],
        }
        if (industry[track_name][i][0]) {
            environment_hd.push(element)
        } else {
            environment.push(element)
        }
    }
    for(let i = 0; i < destroy_steps; i++) {
        if (!industry[track_name][i]) {
            break // the cooling tower has only 3 parts
        }
        let part_name = track_name + "_" + i
        customEvents.push({
            "b": 0,
            "t": "AssignTrackParent",
            "d": {
                "childrenTracks": [part_name],
                "parentTrack": part_name + "_parent1",
            }
        }, {
            "b": 0,
            "t": "AssignTrackParent",
            "d": {
                "childrenTracks": [part_name + "_parent1"],
                "parentTrack": part_name + "_parent2",
            }
        })
        // the top parent track in destroy_building
        // tracks seem to not can have multiple parallel parents
        parts.push(part_name + "_parent2")

    }
    // using beat 0.001 here to not interfere with the parent tracks in destroy_building
    customEvents.push({
        "b": 0,
        "t": "AssignTrackParent",
        "d": {
            "childrenTracks": parts,
            "parentTrack": track_name + "_parent",
        }
    }, {
        "b": 0,
        "t": "AnimateTrack",
        "d": {
            "track": track_name + "_parent",
            "scale": [0, 0, 0],
        }
    })
}

function switch_tree_with_building(beat, number) {
    customEvents.push({
        "b": beat - 0.25,
        "t": "AnimateTrack",
        "d": {
            "track": "tree" + number,
            "scale": [0, 0, 0],
        }
    }, {
        "b": beat - 0.25,
        "t": "AnimateTrack",
        "d": {
            "track": "industry" + number + "_parent",
            "scale": [1, 1, 1],
        }
    })
}

function destroy_building(beat, number, duration_multiplier) {
    let track_name = "industry" + number
    let parts = industry[track_name]
    /*
    let step = 1 / parts.length

    for (let i in parts) {
        let part_name = track_name + "_" + i
        let d = 4 + Math.random() * 4 * (duration_multiplier || 1)
        let y = (-5 - Math.random() - parts[i][2][1]) * Math.max(1.1, ...parts[i][4])
        let x = (Math.random() - 0.5) * (parts[i][2][2] / 2)
        let z = (Math.random() - 0.5) * (parts[i][2][2] / 2)
    */
    for (let i = 0; i < destroy_steps; i++) {
        if (!parts[i]) {
            break // the cooling tower has only 3 parts
        }

        let part_name = track_name + "_" + i
        let d = 3 + Math.random() * 3 * (duration_multiplier || 1)
        let y1 = 0.5 + Math.random() / 2 * (parts[i][2][2] / 10)
        let y2 = 5 + Math.random() * parts[i][2][2]
        let x = (Math.random() - 0.5) * (parts[i][2][2] / 3)
        let z = (Math.random() - 0.5) * (parts[i][2][2] / 3)

        customEvents.push({
            //"b": beat + step * i,
            "b": beat + 0.25 * i,
            "t": "AnimateTrack",
            "d": {
                "track": part_name + "_parent1",
                "duration": d,
                "localPosition": [
                    [0, 0, 0, 0],
                    //[0, y, 0, 1, "easeInQuad"],
                    [0, y1, 0, 0.2, "easeOutSine"],
                    [0, -y2, 0, 1, "easeInCirc"],
                    [0, -1000, 0, 1],
                ],
            }
        }, {
            //"b": beat + step * i,
            "b": beat + 0.25 * i,
            "t": "AnimateTrack",
            "d": {
                "track": part_name + "_parent2",
                "duration": d,
                "localPosition": [
                    [0, 0, 0, 0],
                    [x, 0, z, 1, "easeOutQuad"],
                ],
            }
        })
    }
}


// the train
let train_parts = [
    // HD, object type, position, scale, rotation, material, track name
    // wheels
    [false, "Cylinder", [-0.95, -0.55, -0.7], [0.65, 0.05, 0.65], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.55, -0.7], [0.65, 0.05, 0.65], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.55, 0.88], [0.65, 0.05, 0.65], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.55, 0.88], [0.65, 0.05, 0.65], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.23, 1.8], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.23, 1.8], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.23, 3.1], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.23, 3.1], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.23, 4.4], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.23, 4.4], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.23, 5.7], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.23, 5.7], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.23, 8], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.23, 8], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.23, 9.3], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.23, 9.3], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.23, 10.6], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.23, 10.6], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.23, 11.9], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.23, 11.9], [1.3, 0.05, 1.3], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.55, 13.5], [0.65, 0.05, 0.65], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.55, 13.5], [0.65, 0.05, 0.65], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.55, 14.75], [0.65, 0.05, 0.65], [9, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, -0.55, 14.75], [0.65, 0.05, 0.65], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.95, -0.52, 18.75], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.95, -0.52, 18.75], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [-0.95, -0.52, 20.4], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.95, -0.52, 20.4], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [-0.95, -0.52, 21.7], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.95, -0.52, 21.7], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [-0.95, -0.52, 23], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.95, -0.52, 23], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [-0.95, -0.52, 24.3], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.95, -0.52, 24.3], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [-0.95, -0.52, 25.6], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.95, -0.52, 25.6], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [-0.95, -0.52, 26.9], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.95, -0.52, 26.9], [0.7, 0.05, 0.7], [9, 0, 90], "dark gray", "tenderpart"],
    // the front parts
    [false, "Cube", [0, -0.1, 0.2], [1.7, 0.5, 2.4], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, 0.4, -0.4], [1.7, 0.5, 1.2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, 0.71, -0.1], [2.8, 0.07, 0.8], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.2, 0.5, 0], [0.25, 0.2, 0.25], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.2, 0.5, 0], [0.25, 0.2, 0.25], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.95, 0.4, -0.8], [0.2, 0.15, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.95, 0.4, -0.5], [0.15, 0.15, 0.15], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.95, 0, -0.8], [0.2, 0.15, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.95, 0, -0.5], [0.15, 0.15, 0.15], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0.95, -0.14, -0.66], [0.22, 0.26, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0.95, 0.14, -0.66], [0.22, 0.26, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0.95, 0.24, -0.66], [0.22, 0.26, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0.95, 0.54, -0.66], [0.22, 0.26, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.37, 0.53, -0.45], [0.03, 0.4, 0.1], [18, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.1, 0.53, -0.45], [0.03, 0.4, 0.1], [18, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.235, 0.4, -0.558], [0.3, 0.2, 0.3], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.37, 0.364, -0.721], [0.03, 0.24, 0.13], [34, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.1, 0.364, -0.721], [0.03, 0.24, 0.13], [34, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.235, 0.177, -0.767], [0.3, 0.25, 0.15], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.235, 0, -0.857], [0.3, 0.15, 0.33], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.37, 0.53, -0.45], [0.03, 0.4, 0.1], [18, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.1, 0.53, -0.45], [0.03, 0.4, 0.1], [18, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.235, 0.4, -0.558], [0.3, 0.2, 0.3], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.37, 0.364, -0.721], [0.03, 0.24, 0.13], [34, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.1, 0.364, -0.721], [0.03, 0.24, 0.13], [34, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.235, 0.177, -0.767], [0.3, 0.25, 0.15], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.235, 0, -0.857], [0.3, 0.15, 0.33], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Triangle", [0, 0.075, -1.49], [1.43, 0.6, 1], [-90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [0, 0, -1.1], [2.77, 0.15, 0.18], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [0.459, 0, -1.52], [1.35, 0.15, 0.18], [0, -40, 0], "dark gray", "choochoopart"],
    [false, "Cube", [-0.459, 0, -1.52], [1.35, 0.15, 0.18], [0, 40, 0], "dark gray", "choochoopart"],
    [false, "Cube", [0.484, -0.75, -1.83], [1.38, 0.07, 0.14], [0, -40, 0], "dark gray", "choochoopart"],
    [false, "Cube", [-0.484, -0.75, -1.83], [1.38, 0.07, 0.14], [0, 40, 0], "dark gray", "choochoopart"],
    [false, "Cube", [0, -0.393, -2.05], [0.15, 0.78, 0.07], [27.5, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [0.225, -0.393, -1.877], [0.15, 0.78, 0.07], [20, -40, -15], "dark gray", "choochoopart"],
    [false, "Cube", [-0.225, -0.393, -1.877], [0.15, 0.78, 0.07], [20, 40, 15], "dark gray", "choochoopart"],
    [false, "Cube", [0.45, -0.393, -1.69], [0.15, 0.78, 0.07], [20, -40, -15], "dark gray", "choochoopart"],
    [false, "Cube", [-0.45, -0.393, -1.69], [0.15, 0.78, 0.07], [20, 40, 15], "dark gray", "choochoopart"],
    [false, "Cube", [0.675, -0.393, -1.502], [0.15, 0.78, 0.07], [20, -40, -15], "dark gray", "choochoopart"],
    [false, "Cube", [-0.675, -0.393, -1.502], [0.15, 0.78, 0.07], [20, 40, 15], "dark gray", "choochoopart"],
    [false, "Cube", [0.9, -0.393, -1.315], [0.15, 0.78, 0.07], [20, -40, -15], "dark gray", "choochoopart"],
    [false, "Cube", [-0.9, -0.393, -1.315], [0.15, 0.78, 0.07], [20, 40, 15], "dark gray", "choochoopart"],
    [true, "Cube", [1.22, -0.12, -1.15], [0.02, 0.27, 0.05], [27.5, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.08, -0.24, -1.21], [0.3, 0.023, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.22, -0.12, -1.15], [0.02, 0.27, 0.05], [27.5, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.08, -0.24, -1.21], [0.3, 0.023, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.065, -0.54, -1.353], [0.335, 0.023, 0.14], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.065, -0.512, -1.273], [0.335, 0.079, 0.02], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.065, -0.54, -1.353], [0.335, 0.023, 0.14], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-1.065, -0.512, -1.273], [0.335, 0.079, 0.02], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [0, 0.375, -1.02], [2.05, 0.6, 0.02], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [0.85, 0.8, -0.946], [0.35, 0.3, 0.02], [30, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [-0.85, 0.8, -0.946], [0.35, 0.3, 0.02], [30, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.22, 0.4, -1.035], [0.4, 0.4, 0.02], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-0.22, 0.4, -1.035], [0.4, 0.4, 0.02], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.22, 0.4, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.22, 0.35, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.22, 0.45, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.22, 0.3, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.22, 0.5, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.22, 0.25, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.22, 0.55, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-0.22, 0.4, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-0.22, 0.35, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-0.22, 0.45, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-0.22, 0.3, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-0.22, 0.5, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-0.22, 0.25, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [-0.22, 0.55, -1.04], [0.35, 0.03, 0.03], [35, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.35, -0.06, -1.25], [0.03, 0.085, 0.03], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.35, -0.06, -1.32], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.35, 0.07, -1.32], [0.03, 0.13, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.35, 0.2, -1.32], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.35, 0.2, -1.25], [0.03, 0.085, 0.03], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.35, 0.2, -1.18], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.126, 0.2, -1.18], [0.03, 0.224, 0.03], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Sphere", [0.91, 0.2, -1.18], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.49, 0.2, -1.53], [0.03, 0.55, 0.03], [0, -40, 90], "dark gray", "choochoopart"],
    [true, "Sphere", [0.06, 0.2, -1.89], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.13, 0.13, -1.15], [0.03, 0.08, 0.03], [-25, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.13, 0.2, -1.18], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [0.3, 0.2, -1.689], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.3, 0.13, -1.658], [0.03, 0.08, 0.03], [-25, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0, 0.3, -1.5], [0.1, 0.1, 0.1], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0, 0.17, -1.46], [0.07, 0.15, 0.07], [-18, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.3, 0.13, -1.658], [0.03, 0.08, 0.03], [-25, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-0.3, 0.2, -1.689], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.13, 0.2, -1.18], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [-1.13, 0.13, -1.15], [0.03, 0.08, 0.03], [-25, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-0.06, 0.2, -1.89], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.49, 0.2, -1.53], [0.03, 0.55, 0.03], [0, 40, 90], "dark gray", "choochoopart"],
    [true, "Sphere", [-0.91, 0.2, -1.18], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.126, 0.2, -1.18], [0.03, 0.224, 0.03], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.35, 0.2, -1.18], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.35, 0.2, -1.25], [0.03, 0.085, 0.03], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.35, 0.2, -1.32], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.35, 0.07, -1.32], [0.03, 0.13, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.35, -0.06, -1.32], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.35, -0.06, -1.25], [0.03, 0.085, 0.03], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.05, 0.29, -1.02], [0.05, 0.05, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.075, 0.38, -1.02], [0.03, 0.305, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.05, 0.67, -1.02], [0.05, 0.05, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.075, 1.054, -0.858], [0.03, 0.409, 0.03], [23.48, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.075, 1.42, -0.7], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.075, 1.42, -0.247], [0.03, 0.462, 0.03], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.075, 1.42, -0.45], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.075, 1.06, -0.45], [0.03, 0.36, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.05, 1.1, -0.45], [0.05, 0.05, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.89, 0.95, -0.45], [0.03, 0.21, 0.03], [0, 0, -40], "dark gray", "choochoopart"],
    [true, "Capsule", [0.76, 0.77, -0.45], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.075, 1.42, 0.2], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.075, 1.06, 0.2], [0.03, 0.36, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.05, 1.1, 0.2], [0.05, 0.05, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.89, 0.95, 0.2], [0.03, 0.21, 0.03], [0, 0, -40], "dark gray", "choochoopart"],
    [true, "Capsule", [0.76, 0.77, 0.2], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [-1.05, 0.29, -1.02], [0.05, 0.05, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.075, 0.38, -1.02], [0.03, 0.305, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [-1.05, 0.67, -1.02], [0.05, 0.05, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.075, 1.054, -0.858], [0.03, 0.409, 0.03], [23.48, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.075, 1.42, -0.7], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.075, 1.42, -0.247], [0.03, 0.462, 0.03], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.075, 1.42, -0.45], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.075, 1.06, -0.45], [0.03, 0.36, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [-1.05, 1.1, -0.45], [0.05, 0.05, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [-0.89, 0.95, -0.45], [0.03, 0.21, 0.03], [0, 0, 40], "dark gray", "choochoopart"],
    [true, "Capsule", [-0.76, 0.77, -0.45], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.075, 1.42, 0.2], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.075, 1.06, 0.2], [0.03, 0.36, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [-1.05, 1.1, 0.2], [0.05, 0.05, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [-0.89, 0.95, 0.2], [0.03, 0.21, 0.03], [0, 0, 40], "dark gray", "choochoopart"],
    [true, "Capsule", [-0.76, 0.77, 0.2], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.4, 1.05, -0.45], [0.03, 0.36, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [-0.4, 1.05, -0.45], [0.03, 0.36, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [0.4, 1.42, -0.45], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-0.4, 1.42, -0.45], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0, 1.42, -0.45], [0.03, 0.4, 0.03], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Capsule", [0.4, 1.1, -0.425], [0.05, 0.05, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [-0.4, 1.1, -0.425], [0.05, 0.05, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.4, 0.95, -0.265], [0.03, 0.21, 0.03], [-40, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [-0.4, 0.95, -0.265], [0.03, 0.21, 0.03], [-40, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0.4, 0.77, -0.14], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [-0.4, 0.77, -0.14], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    // the front lamp
    [false, "Cube", [0, 0.82, -0.3], [0.4, 0.2, 0.3], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [0, 0.97, -0.3], [0.25, 0.25, 0.25], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [0, 1.09, -0.42], [0.2, 0.2, 0.2], [-90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [0, 1.09, -0.6], [0.33, 0.1, 0.33], [-90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [0, 1.09, -0.67], [0.29, 0.29, 0.08], [0, 0, 0], "yellow light", "choochoopart", 2, 10],
    [true, "Cube", [0.27, 1.09, -0.55], [0.31, 0.15, 0.01], [0, -37, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0.221, 1.09, -0.587], [0.015, 0.1, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.2045, 1.102, -0.599], [0.015, 0.078, 0.011], [0, -37, -30], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.208, 1.065, -0.5965], [0.06, 0.015, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.2811, 1.09, -0.5411], [0.015, 0.05, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.274, 1.1222, -0.5465], [0.015, 0.033, 0.011], [0, -37, 41], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.264, 1.132, -0.554], [0.015, 0.015, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.254, 1.1222, -0.5615], [0.015, 0.033, 0.011], [0, -37, -41], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.247, 1.09, -0.567], [0.015, 0.05, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.254, 1.0578, -0.5615], [0.015, 0.033, 0.011], [0, -37, 41], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.264, 1.048, -0.554], [0.015, 0.015, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.274, 1.0578, -0.5465], [0.015, 0.033, 0.011], [0, -37, -41], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.307, 1.09, -0.522], [0.015, 0.1, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.363, 1.09, -0.48], [0.015, 0.1, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.3465, 1.102, -0.492], [0.015, 0.078, 0.011], [0, -37, -30], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [0.35, 1.065, -0.4895], [0.06, 0.015, 0.011], [0, -37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.27, 1.09, -0.55], [0.31, 0.15, 0.01], [0, 37, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.33, 1.09, -0.505], [0.015, 0.1, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.3465, 1.102, -0.4925], [0.015, 0.078, 0.011], [0, 37, -30], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.343, 1.065, -0.495], [0.06, 0.015, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.304, 1.09, -0.524], [0.015, 0.05, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.297, 1.1222, -0.5295], [0.015, 0.033, 0.011], [0, 37, -41], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.287, 1.132, -0.537], [0.015, 0.015, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.277, 1.1222, -0.5445], [0.015, 0.033, 0.011], [0, 37, 41], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.27, 1.09, -0.55], [0.015, 0.05, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.277, 1.0578, -0.5445], [0.015, 0.033, 0.011], [0, 37, -41], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.287, 1.048, -0.537], [0.015, 0.015, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.297, 1.0578, -0.5295], [0.015, 0.033, 0.011], [0, 37, 41], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.245, 1.09, -0.569], [0.015, 0.1, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.189, 1.09, -0.611], [0.015, 0.1, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.2055, 1.102, -0.5985], [0.015, 0.078, 0.011], [0, 37, -30], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.202, 1.065, -0.601], [0.06, 0.015, 0.011], [0, 37, 0], "yellow light", "choochoopart", 0.5, 0],
    // front wheel protector
    [false, "Cube", [0, -0.55, -1.07], [2.17, 0.2, 0.05], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.06, -0.55, -0.8], [0.05, 0.2, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.06, -0.645, -0.497], [0.05, 0.2, 0.35], [45, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.06, -0.74, 0.086], [0.05, 0.2, 1.06], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.06, -0.645, 0.669], [0.05, 0.2, 0.35], [-45, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.06, -0.55, 0.86], [0.05, 0.2, 0.275], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.06, -0.55, 0.86], [0.05, 0.2, 0.275], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.06, -0.645, 0.669], [0.05, 0.2, 0.35], [-45, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.06, -0.74, 0.086], [0.05, 0.2, 1.06], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.06, -0.645, -0.497], [0.05, 0.2, 0.35], [45, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.06, -0.55, -0.8], [0.05, 0.2, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    // the 1st steam pumps on the side
    [false, "Cylinder", [1.25, 0.15, 0.1], [0.5, 0.4, 0.5], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [1.2, -0.3, 0.1], [0.6, 0.4, 0.6], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Sphere", [1.25, 0.15, -0.3], [0.4, 0.15, 0.4], [90, 0, 0], "gray", "choochoopart"],
    [false, "Sphere", [1.2, -0.3, -0.3], [0.5, 0.25, 0.5], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.25, 0.15, 0.4], [0.38, 0.25, 0.38], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.2, -0.3, 0.4], [0.48, 0.15, 0.48], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.15, -0.075, 0.1], [0.7, 0.45, 0.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [-1.25, 0.15, 0.1], [0.5, 0.4, 0.5], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [-1.2, -0.3, 0.1], [0.6, 0.4, 0.6], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Sphere", [-1.25, 0.15, -0.3], [0.4, 0.15, 0.4], [90, 0, 0], "gray", "choochoopart"],
    [false, "Sphere", [-1.2, -0.3, -0.3], [0.5, 0.25, 0.5], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [-1.25, 0.15, 0.4], [0.38, 0.25, 0.38], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.2, -0.3, 0.4], [0.48, 0.15, 0.48], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [-1.15, -0.075, 0.1], [0.7, 0.45, 0.8], [0, 0, 0], "darker gray", "choochoopart"],
    // the 2nd steam pumps on the side
    [false, "Cylinder", [1.25, 0.15, 6.8], [0.5, 0.4, 0.5], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [1.2, -0.3, 6.8], [0.6, 0.4, 0.6], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Sphere", [1.25, 0.15, 6.4], [0.4, 0.15, 0.4], [90, 0, 0], "gray", "choochoopart"],
    [false, "Sphere", [1.2, -0.3, 6.4], [0.5, 0.25, 0.5], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.25, 0.15, 7.1], [0.38, 0.25, 0.38], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.2, -0.3, 7.1], [0.48, 0.15, 0.48], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.15, -0.075, 6.8], [0.7, 0.45, 0.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [-1.25, 0.15, 6.8], [0.5, 0.4, 0.5], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [-1.2, -0.3, 6.8], [0.6, 0.4, 0.6], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Sphere", [-1.25, 0.15, 6.4], [0.4, 0.15, 0.4], [90, 0, 0], "gray", "choochoopart"],
    [false, "Sphere", [-1.2, -0.3, 6.4], [0.5, 0.25, 0.5], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [-1.25, 0.15, 7.1], [0.38, 0.25, 0.38], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.2, -0.3, 7.1], [0.48, 0.15, 0.48], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [-1.15, -0.075, 6.8], [0.7, 0.45, 0.8], [0, 0, 0], "darker gray", "choochoopart"],
    // 1st non-moving parts on the front wheels
    [false, "Cube", [1.2, 0.02, 2], [0.15, 0.15, 1.45], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.2, 0.069, 1.191], [0.15, 0.13, 0.27], [30, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.25, 0.25, 1.13], [0.25, 0.4, 0.2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1, 0.1, 1.13], [0.35, 0.1, 0.2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.25, 0.17, 1.7], [0.25, 0.16, 0.35], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.25, 0.35, 1.4], [0.25, 0.2, 0.35], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.25, 0.278, 1.677], [0.249, 0.17, 0.363], [34, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.15, 0.32, 2.65], [0.05, 0.46, 0.15], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.15, 0.47, 2.95], [0.05, 0.16, 0.45], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [1.25, 0.47, 3.05], [0.1, 0.1, 0.1], [0, 0, 90], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.55, 3.13], [0.04, 0.095, 0.2], [-45, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.39, 3.13], [0.04, 0.095, 0.2], [45, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.607, 3.417], [0.04, 0.095, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.333, 3.417], [0.04, 0.095, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.47, 3.38], [0.04, 0.18, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.47, 3.714], [0.04, 0.37, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.55, 3.13], [0.04, 0.095, 0.2], [-45, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.39, 3.13], [0.04, 0.095, 0.2], [45, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.607, 3.417], [0.04, 0.095, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.333, 3.417], [0.04, 0.095, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.47, 3.38], [0.04, 0.18, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.47, 3.714], [0.04, 0.37, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.05, 0.47, 3.808], [0.59, 0.36, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0.8, 0.58, 3.808], [0.095, 0.58, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.225, 0.663, 2.45], [0.05, 0.088, 0.5], [14, 0, 0], "light gray", "choochoopart"],
    [false, "Cylinder", [1.245, 0.6, 2.7], [0.09, 0.05, 0.09], [0, 0, 90], "light gray", "choochoopart"],
    [false, "Cylinder", [0.655, 0.726, 2.2], [0.12, 0.6, 0.12], [0, 0, 90], "light gray", "choochoopart"],
    // 1st movable parts on the front wheels
    [false, "Cylinder", [1.05, -0.23, 2.2], [0.3, 0.03, 0.3], [0, 0, 90], "darker gray", "coupling rods"],
    [false, "Cylinder", [1.08, -0.23, 3.5], [0.3, 0.06, 0.3], [0, 0, 90], "darker gray", "coupling rods"],
    [false, "Cylinder", [1.155, -0.23, 4.8], [0.3, 0.14, 0.3], [0, 0, 90], "darker gray", "coupling rods"],
    [false, "Cylinder", [1.05, -0.23, 6.1], [0.3, 0.03, 0.3], [0, 0, 90], "darker gray", "coupling rods"],
    [false, "Cylinder", [1.04, -0.23, 2.2], [0.12, 0.045, 0.12], [0, 0, 90], "dark gray", "coupling rods"],
    [false, "Cylinder", [1.06, -0.23, 3.5], [0.12, 0.085, 0.12], [0, 0, 90], "dark gray", "coupling rods"],
    [false, "Cylinder", [1.13, -0.23, 4.8], [0.12, 0.17, 0.12], [0, 0, 90], "dark gray", "coupling rods"],
    [false, "Cylinder", [1.04, -0.23, 6.1], [0.12, 0.045, 0.12], [0, 0, 90], "dark gray", "coupling rods"],
    [false, "Cube", [1.05, -0.23, 2.85], [0.05, 0.17, 1.1], [0, 0, 0], "light gray", "coupling rods"],
    [false, "Cube", [1.11, -0.23, 4.15], [0.05, 0.17, 1.1], [0, 0, 0], "light gray", "coupling rods"],
    [false, "Cube", [1.05, -0.23, 5.45], [0.05, 0.17, 1.1], [0, 0, 0], "light gray", "coupling rods"],
    [false, "Cylinder", [1.2, -0.3, 1.4], [0.1, 0.9, 0.1], [90, 0, 0], "light gray", "lower pump rod"],
    [false, "Cylinder", [1.2, -0.3, 2.3], [0.17, 0.1, 0.17], [90, 0, 0], "light gray", "lower pump rod"],
    [false, "Capsule", [1.2, -0.25, 2.54], [0.2, 0.25, 0.33], [90, 0, 0], "dark gray", "lower pump rod"],
    [false, "Cylinder", [1.282, -0.23, 2.6], [0.22, 0.02, 0.22], [0, 0, 90], "light gray", "lower pump rod"],
    [false, "Cylinder", [1.283, -0.23, 2.6], [0.1, 0.02, 0.1], [0, 0, 90], "dark gray", "lower pump rod"],
    [false, "Cube", [1.2, -0.05, 2.54], [0.07, 0.15, 0.25], [0, 0, 0], "dark gray", "lower pump rod"],
    [false, "Cube", [1.225, -0.4, 2.54], [0.1, 0.2, 0.2], [35, 30, 45], "light gray", "lower pump rod"],
    [false, "Cylinder", [1.33, -0.53, 2.54], [0.1, 0.04, 0.1], [0, 0, 90], "light gray", "lower pump rod"],
    [false, "Cube", [1.33, -0.531, 2.32], [0.05, 0.05, 0.45], [0, 0, 0], "light gray", "handlebar"],
    [false, "Cylinder", [1.33, -0.53, 2.09], [0.1, 0.04, 0.1], [0, 0, 90], "light gray", "handlecross"],
    [false, "Cube", [1.33, -0.17, 2.09], [0.05, 0.66, 0.05], [0, 0, 0], "light gray", "handlelever"],
    [false, "Cube", [1.2, -0.23, 3.7], [0.05, 0.17, 2.2], [0, 0, 0], "light gray", "main rod"],
    [false, "Cylinder", [1.25, 0.15, 1.25], [0.05, 0.6, 0.05], [90, 0, 0], "light gray", "upper pump rod"],
    [false, "Cylinder", [1.25, 0.15, 1.75], [0.1, 0.1, 0.1], [90, 0, 0], "light gray", "upper pump rod"],
    [false, "Cube", [1.225, 0.25, 2.4], [0.05, 0.05, 1.3], [-8, 0, 0], "light gray", "slider rod"],
    [false, "Cylinder", [1.25, 0.34, 3.05], [0.11, 0.05, 0.11], [0, 0, 90], "light gray", "slider rod"],
    [false, "Cube", [1.27, 0.44, 2.7], [0.04, 0.3, 0.04], [0, 0, 0], "light gray", "hanging iron"],
    [false, "Cylinder", [1.245, 0.29, 2.7], [0.08, 0.05, 0.08], [0, 0, 90], "light gray", "hanging iron cross"],
    [false, "Cube", [1.275, 0, -0.08], [0.05, 0.65, 0.05], [0, 0, 0], "light gray", "swingarm"],
    [false, "Cube", [1.275, 0, 0.08], [0.05, 0.65, 0.05], [0, 0, 0], "light gray", "swingarm"],
    [false, "Cube", [1.275, 0.33, 0], [0.05, 0.05, 0.21], [0, 0, 0], "light gray", "swingarm"],
    [false, "Cube", [1.275, -0.33, 0], [0.05, 0.05, 0.21], [0, 0, 0], "light gray", "swingarm"],
    [false, "Cylinder", [1.3, -0.37, 0.12], [0.15, 0.06, 0.15], [0, 0, 90], "light gray", "swingarm"],
    [false, "Cube", [1.325, -0.071, 3.63], [0.05, 0.07, 1.3], [13.9, 0, 0], "light gray", "swingarm rod"],
    [false, "Cube", [1.26, -0.23, 4.8], [0.045, 0.45, 0.4], [0, 0, 0], "light gray", "counter crank"],
    [false, "Cube", [1.26, -0.07, 0], [0.045, 0.1, 0.4], [15, 0, 0], "light gray", "counter crank arm"],
    [false, "Cube", [1.26, 0.07, 0], [0.045, 0.1, 0.4], [-15, 0, 0], "light gray", "counter crank arm"],
    [false, "Cylinder", [1.298, 0, -0.2], [0.15, 0.062, 0.15], [0, 0, 90], "light gray", "counter crank arm"],
    // 2nd non-moving parts on the front wheels
    [false, "Cube", [1.2, 0.02, 8.2], [0.15, 0.15, 1.45], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.2, 0.042, 7.476], [0.15, 0.13, 0.142], [48, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.25, 0.25, 7.43], [0.25, 0.4, 0.1], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0, 0.35, 7.43], [2.25, 0.2, 0.1], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.25, 0.17, 7.9], [0.25, 0.16, 0.35], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.25, 0.35, 7.625], [0.25, 0.2, 0.3], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.25, 0.278, 7.877], [0.249, 0.17, 0.363], [34, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.15, 0.32, 8.85], [0.05, 0.46, 0.15], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.15, 0.47, 9.15], [0.05, 0.16, 0.45], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [1.25, 0.47, 9.25], [0.1, 0.1, 0.1], [0, 0, 90], "darker gray", "choochoopart"],
    [false, "Cylinder", [1.25, 0.47, 3.05], [0.1, 0.1, 0.1], [0, 0, 90], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.55, 9.33], [0.04, 0.095, 0.2], [-45, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.39, 9.33], [0.04, 0.095, 0.2], [45, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.607, 9.617], [0.04, 0.095, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.333, 9.617], [0.04, 0.095, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.47, 9.58], [0.04, 0.18, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.325, 0.47, 9.914], [0.04, 0.37, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.55, 9.33], [0.04, 0.095, 0.2], [-45, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.39, 9.33], [0.04, 0.095, 0.2], [45, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.607, 9.617], [0.04, 0.095, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.333, 9.617], [0.04, 0.095, 0.5], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.47, 9.58], [0.04, 0.18, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.22, 0.47, 9.914], [0.04, 0.37, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.05, 0.47, 10.008], [0.59, 0.36, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0.8, 0.58, 10.008], [0.095, 0.58, 0.095], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.225, 0.663, 8.65], [0.05, 0.088, 0.5], [14, 0, 0], "light gray", "choochoopart"],
    [false, "Cylinder", [1.245, 0.6, 8.9], [0.09, 0.05, 0.09], [0, 0, 90], "light gray", "choochoopart"],
    [false, "Cylinder", [0.655, 0.726, 8.4], [0.12, 0.6, 0.12], [0, 0, 90], "light gray", "choochoopart"],
    [true, "Cube", [-1.25, 0.25, 7.43], [0.25, 0.4, 0.1], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.25, 0.35, 7.625], [0.25, 0.2, 0.3], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.25, 0.278, 7.877], [0.249, 0.17, 0.363], [34, 0, 0], "darker gray", "choochoopart"],
    // 2nd movable parts on the front wheels
    [false, "Cylinder", [1.05, -0.23, 8.4], [0.3, 0.03, 0.3], [0, 0, 90], "darker gray", "coupling rods 2"],
    [false, "Cylinder", [1.08, -0.23, 9.7], [0.3, 0.06, 0.3], [0, 0, 90], "darker gray", "coupling rods 2"],
    [false, "Cylinder", [1.155, -0.23, 11], [0.3, 0.14, 0.3], [0, 0, 90], "darker gray", "coupling rods 2"],
    [false, "Cylinder", [1.05, -0.23, 12.3], [0.3, 0.03, 0.3], [0, 0, 90], "darker gray", "coupling rods 2"],
    [false, "Cylinder", [1.04, -0.23, 8.4], [0.12, 0.045, 0.12], [0, 0, 90], "dark gray", "coupling rods 2"],
    [false, "Cylinder", [1.06, -0.23, 9.7], [0.12, 0.085, 0.12], [0, 0, 90], "dark gray", "coupling rods 2"],
    [false, "Cylinder", [1.13, -0.23, 11], [0.12, 0.17, 0.12], [0, 0, 90], "dark gray", "coupling rods 2"],
    [false, "Cylinder", [1.04, -0.23, 12.3], [0.12, 0.045, 0.12], [0, 0, 90], "dark gray", "coupling rods 2"],
    [false, "Cube", [1.05, -0.23, 9.05], [0.05, 0.17, 1.1], [0, 0, 0], "light gray", "coupling rods 2"],
    [false, "Cube", [1.11, -0.23, 10.35], [0.05, 0.17, 1.1], [0, 0, 0], "light gray", "coupling rods 2"],
    [false, "Cube", [1.05, -0.23, 11.65], [0.05, 0.17, 1.1], [0, 0, 0], "light gray", "coupling rods 2"],
    [false, "Cylinder", [1.2, -0.3, 7.775], [0.1, 0.65, 0.1], [90, 0, 0], "light gray", "lower pump 2 rod"],
    [false, "Cylinder", [1.2, -0.3, 8.5], [0.17, 0.1, 0.17], [90, 0, 0], "light gray", "lower pump 2 rod"],
    [false, "Capsule", [1.2, -0.25, 8.74], [0.2, 0.25, 0.33], [90, 0, 0], "dark gray", "lower pump 2 rod"],
    [false, "Cylinder", [1.282, -0.23, 8.8], [0.22, 0.02, 0.22], [0, 0, 90], "light gray", "lower pump 2 rod"],
    [false, "Cylinder", [1.283, -0.23, 8.8], [0.1, 0.02, 0.1], [0, 0, 90], "dark gray", "lower pump 2 rod"],
    [false, "Cube", [1.2, -0.05, 8.74], [0.07, 0.15, 0.25], [0, 0, 0], "dark gray", "lower pump 2 rod"],
    [false, "Cube", [1.225, -0.4, 8.74], [0.1, 0.2, 0.2], [35, 30, 45], "light gray", "lower pump 2 rod"],
    [false, "Cylinder", [1.33, -0.53, 8.74], [0.1, 0.04, 0.1], [0, 0, 90], "light gray", "lower pump 2 rod"],
    [false, "Cube", [1.33, -0.531, 8.52], [0.05, 0.05, 0.45], [0, 0, 0], "light gray", "handlebar 2"],
    [false, "Cylinder", [1.33, -0.53, 8.29], [0.1, 0.04, 0.1], [0, 0, 90], "light gray", "handlecross 2"],
    [false, "Cube", [1.33, -0.17, 8.29], [0.05, 0.66, 0.05], [0, 0, 0], "light gray", "handlelever 2"],
    [false, "Cube", [1.2, -0.23, 9.9], [0.05, 0.17, 2.2], [0, 0, 0], "light gray", "main 2 rod"],
    [false, "Cylinder", [1.25, 0.15, 7.45], [0.05, 0.6, 0.05], [90, 0, 0], "light gray", "upper pump 2 rod"],
    [false, "Cylinder", [1.25, 0.15, 7.95], [0.1, 0.1, 0.1], [90, 0, 0], "light gray", "upper pump 2 rod"],
    [false, "Cube", [1.225, 0.25, 8.6], [0.05, 0.05, 1.3], [-8, 0, 0], "light gray", "slider 2 rod"],
    [false, "Cylinder", [1.25, 0.34, 9.25], [0.11, 0.05, 0.11], [0, 0, 90], "light gray", "slider 2 rod"],
    [false, "Cube", [1.27, 0.44, 8.9], [0.04, 0.3, 0.04], [0, 0, 0], "light gray", "hanging iron 2"],
    [false, "Cylinder", [1.245, 0.29, 8.9], [0.08, 0.05, 0.08], [0, 0, 90], "light gray", "hanging iron 2 cross"],
    [false, "Cube", [1.275, 0, -0.08], [0.05, 0.65, 0.05], [0, 0, 0], "light gray", "swingarm 2"],
    [false, "Cube", [1.275, 0, 0.08], [0.05, 0.65, 0.05], [0, 0, 0], "light gray", "swingarm 2"],
    [false, "Cube", [1.275, 0.33, 0], [0.05, 0.05, 0.21], [0, 0, 0], "light gray", "swingarm 2"],
    [false, "Cube", [1.275, -0.33, 0], [0.05, 0.05, 0.21], [0, 0, 0], "light gray", "swingarm 2"],
    [false, "Cylinder", [1.3, -0.37, 0.12], [0.15, 0.06, 0.15], [0, 0, 90], "light gray", "swingarm 2"],
    [false, "Cube", [1.325, -0.071, 9.83], [0.05, 0.07, 1.3], [13.9, 0, 0], "light gray", "swingarm 2 rod"],
    [false, "Cube", [1.26, -0.23, 11], [0.045, 0.45, 0.4], [0, 0, 0], "light gray", "counter crank 2"],
    [false, "Cube", [1.26, -0.07, 0], [0.045, 0.1, 0.4], [15, 0, 0], "light gray", "counter crank 2 arm"],
    [false, "Cube", [1.26, 0.07, 0], [0.045, 0.1, 0.4], [-15, 0, 0], "light gray", "counter crank 2 arm"],
    [false, "Cylinder", [1.298, 0, -0.2], [0.15, 0.062, 0.15], [0, 0, 90], "light gray", "counter crank 2 arm"],
    // smoke chamber
    [false, "Cylinder", [0, 1.9, 2.2], [2.5, 1.6, 2.5], [90, 0, 0], "light gray", "choochoopart"],
    [false, "Sphere", [0, 1.9, 0.6], [2.1, 2.1, 0.5], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Capsule", [0.74, 2.1, 0.39], [0.06, 0.06, 0.06], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.37, 2.1, 0.33], [0.04, 0.39, 0.04], [0, -5, 90], "dark gray", "choochoopart"],
    [true, "Capsule", [0, 2.1, 0.32], [0.06, 0.06, 0.06], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [-0.37, 2.1, 0.33], [0.04, 0.39, 0.04], [0, 5, 90], "dark gray", "choochoopart"],
    [true, "Capsule", [-0.74, 2.1, 0.39], [0.06, 0.06, 0.06], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.58, 2.45, 0.49], [0.8, 0.13, 0.15], [0, -12, 0], "gray", "choochoopart"],
    [true, "Cube", [0.58, 1.35, 0.49], [0.8, 0.13, 0.15], [0, -12, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.28, 2.45, 0.355], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.4, 2.45, 0.38], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.52, 2.45, 0.405], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.64, 2.45, 0.43], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.77, 2.45, 0.46], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.28, 1.35, 0.355], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.4, 1.35, 0.38], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.52, 1.35, 0.405], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.64, 1.35, 0.43], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.77, 1.35, 0.46], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [false, "Capsule", [0.98, 2.45, 0.54], [0.12, 0.12, 0.12], [0, 0, 0], "gray", "choochoopart"],
    [false, "Capsule", [0.98, 1.35, 0.54], [0.12, 0.12, 0.12], [0, 0, 0], "gray", "choochoopart"],
    [true, "Capsule", [0.118, 2.943, 0.56], [0.08, 0.12, 0.08], [28, -2, -6.43], "gray", "choochoopart"],
    [true, "Capsule", [0.347, 2.891, 0.56], [0.08, 0.12, 0.08], [25, -8, -19.29], "gray", "choochoopart"],
    [true, "Capsule", [0.559, 2.789, 0.56], [0.08, 0.12, 0.08], [22, -14, -32.14], "gray", "choochoopart"],
    [true, "Capsule", [0.742, 2.642, 0.56], [0.08, 0.12, 0.08], [18, -18, -45.00], "gray", "choochoopart"],
    [true, "Capsule", [0.991, 2.247, 0.56], [0.08, 0.12, 0.08], [8, -25, -70.71], "gray", "choochoopart"],
    [true, "Capsule", [1.043, 2.018, 0.56], [0.08, 0.12, 0.08], [2, -28, -83.57], "gray", "choochoopart"],
    [true, "Capsule", [1.043, 1.782, 0.56], [0.08, 0.12, 0.08], [-2, -28, -96.43], "gray", "choochoopart"],
    [true, "Capsule", [0.991, 1.553, 0.56], [0.08, 0.12, 0.08], [-8, -25, -109.29], "gray", "choochoopart"],
    [true, "Capsule", [0.742, 1.158, 0.56], [0.08, 0.12, 0.08], [-18, -18, -135.00], "gray", "choochoopart"],
    [true, "Capsule", [0.559, 1.011, 0.56], [0.08, 0.12, 0.08], [-22, -14, -147.86], "gray", "choochoopart"],
    [true, "Capsule", [0.347, 0.909, 0.56], [0.08, 0.12, 0.08], [-25, -8, -160.71], "gray", "choochoopart"],
    [true, "Capsule", [0.118, 0.857, 0.56], [0.08, 0.12, 0.08], [-28, -2, -173.57], "gray", "choochoopart"],
    [true, "Capsule", [-0.118, 2.943, 0.56], [0.08, 0.12, 0.08], [28, 2, 6.43], "gray", "choochoopart"],
    [true, "Capsule", [-0.347, 2.891, 0.56], [0.08, 0.12, 0.08], [25, 8, 19.29], "gray", "choochoopart"],
    [true, "Capsule", [-0.559, 2.789, 0.56], [0.08, 0.12, 0.08], [22, 14, 32.14], "gray", "choochoopart"],
    [true, "Capsule", [-0.742, 2.642, 0.56], [0.08, 0.12, 0.08], [18, 18, 45.00], "gray", "choochoopart"],
    [true, "Capsule", [-0.889, 2.459, 0.56], [0.08, 0.12, 0.08], [14, 22, 57.86], "gray", "choochoopart"],
    [true, "Capsule", [-0.991, 2.247, 0.56], [0.08, 0.12, 0.08], [8, 25, 70.71], "gray", "choochoopart"],
    [true, "Capsule", [-1.043, 2.018, 0.56], [0.08, 0.12, 0.08], [2, 28, 83.57], "gray", "choochoopart"],
    [true, "Capsule", [-1.043, 1.782, 0.56], [0.08, 0.12, 0.08], [-2, 28, 96.43], "gray", "choochoopart"],
    [true, "Capsule", [-0.991, 1.553, 0.56], [0.08, 0.12, 0.08], [-8, 25, 109.29], "gray", "choochoopart"],
    [true, "Capsule", [-0.889, 1.341, 0.56], [0.08, 0.12, 0.08], [-14, 22, 122.14], "gray", "choochoopart"],
    [true, "Capsule", [-0.742, 1.158, 0.56], [0.08, 0.12, 0.08], [-18, 18, 135.00], "gray", "choochoopart"],
    [true, "Capsule", [-0.559, 1.011, 0.56], [0.08, 0.12, 0.08], [-22, 14, 147.86], "gray", "choochoopart"],
    [true, "Capsule", [-0.347, 0.909, 0.56], [0.08, 0.12, 0.08], [-25, 8, 160.71], "gray", "choochoopart"],
    [true, "Capsule", [-0.118, 0.857, 0.56], [0.08, 0.12, 0.08], [-28, 2, 173.57], "gray", "choochoopart"],
    [false, "Cylinder", [0, 3.2, 1.6], [1, 0.3, 1], [0, 0, 0], "light gray", "choochoopart"],
    [false, "Cube", [0, 3.2, 2.2], [1, 0.6, 1.2], [0, 0, 0], "light gray", "choochoopart"],
    [false, "Cylinder", [0, 3.22, 3.2], [0.15, 0.3, 0.15], [-60, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0, 3.27, 3.45], [0.05, 0.12, 0.05], [30, 0, 0], "darker gray", "choochoopart"],
    [false, "Capsule", [0, 3.38, 3.52], [0.2, 0.02, 0.2], [30, 0, 0], "red", "choochoopart"],
    [false, "Cylinder", [0.6, 3.02, 3.01], [0.07, 0.6, 0.07], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0.6, 3.02, 3.63], [0.11, 0.15, 0.11], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [0.6, 3.02, 2.6], [0.11, 0.11, 0.11], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.6, 3.12, 2.6], [0.03, 0.08, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Capsule", [0.6, 3.2, 2.6], [0.15, 0.01, 0.15], [0, 0, 0], "red", "choochoopart"],
    [false, "Capsule", [0.586, 2.997, 2.387], [0.071, 0.071, 0.071], [45, 0, -22.5], "dark gray", "choochoopart"],
    [false, "Cube", [1.28, 1.75, 0.9], [0.13, 0.02, 0.35], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cube", [1.228, 1.825, 0.9], [0.13, 0.026, 0.35], [0, 0, 83], "dark gray", "choochoopart"],
    [false, "Cube", [1.21, 1.7, 2], [0.17, 0.032, 0.32], [0, 0, 81], "gray", "choochoopart"],
    [false, "Capsule", [0, 0.2, 0.5], [0.4, 0.4, 0.4], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [0, 0.4, 1.15], [0.4, 0.65, 0.4], [90, 0, 0], "gray", "choochoopart"],
    [false, "Capsule", [0, 0.6, 1.8], [0.4, 0.4, 0.4], [0, 0, 0], "gray", "choochoopart"],
    [false, "Capsule", [0, 0.5, 2.3], [0.4, 0.4, 0.4], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [0, 0.3, 4.55], [0.4, 2.25, 0.4], [90, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0, 0.3, 6.8], [0.4, 0.4, 0.4], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [0.45, 0.09, 6.8], [0.4, 0.5, 0.4], [0, 0, 65], "gray", "choochoopart"],
    [false, "Cylinder", [-0.45, 0.09, 6.8], [0.4, 0.5, 0.4], [0, 0, -65], "gray", "choochoopart"],
    [true, "Sphere", [1.21, 1.65, 0.75], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.21, 1.65, 1.25], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.21, 1.65, 1.75], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.21, 1.65, 2.25], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.21, 1.65, 2.75], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.21, 1.65, 3.25], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.13, 1.4, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.155, 1.45, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.18, 1.5, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.195, 1.55, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.20, 1.6, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.211, 1.65, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.218, 1.7, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.225, 1.75, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.232, 1.8, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.239, 1.85, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.246, 1.9, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.239, 1.95, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.232, 2, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.225, 2.05, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.218, 2.1, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.21, 2.15, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.201, 2.2, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.192, 2.25, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.18, 2.3, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.155, 2.35, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.13, 2.4, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.105, 2.45, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.08, 2.5, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.055, 2.55, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.03, 2.6, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.996, 2.65, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.947, 2.7, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.898, 2.75, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.849, 2.8, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.8, 2.85, 3.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [0.748, 2.9, 3.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    // the bell
    [true, "Sphere", [0, 2.97, 0.2], [0.1, 0.1, 0.1], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Capsule", [0, 2.98, 0.2], [0.4, 0.04, 0.4], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3, 0.2], [0.4, 0.1, 0.4], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Sphere", [0, 3.01, 0.2], [0.36, 0.11, 0.36], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3.02, 0.2], [0.33, 0.12, 0.33], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Sphere", [0, 3.03, 0.2], [0.31, 0.13, 0.31], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3.04, 0.2], [0.29, 0.14, 0.29], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Sphere", [0, 3.06, 0.2], [0.27, 0.15, 0.27], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3.08, 0.2], [0.26, 0.16, 0.26], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Sphere", [0, 3.1, 0.2], [0.25, 0.17, 0.25], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3.12, 0.2], [0.24, 0.18, 0.24], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Sphere", [0, 3.14, 0.2], [0.23, 0.19, 0.23], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3.16, 0.2], [0.22, 0.2, 0.22], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Sphere", [0, 3.18, 0.2], [0.21, 0.21, 0.21], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3.21, 0.2], [0.2, 0.14, 0.2], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Sphere", [0, 3.225, 0.2], [0.195, 0.11, 0.195], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3.235, 0.2], [0.19, 0.08, 0.19], [0, 0, 0], "bronze", "choochoopart"],
    [true, "Sphere", [0, 3.24, 0.2], [0.19, 0.06, 0.19], [0, 0, 0], "bronze", "choochoopart"],
    [false, "Cylinder", [0, 3.22, 0.2], [0.05, 0.19, 0.05], [0, 0, 90], "light gray", "choochoopart"],
    [false, "Cube", [0.17, 3.15, 0.65], [0.02, 0.07, 1], [9, 0, 0], "light gray", "choochoopart"],
    [false, "Cube", [-0.17, 3.15, 0.65], [0.02, 0.07, 1], [9, 0, 0], "light gray", "choochoopart"],
    [true, "Capsule", [0.13, 3.25, 0.2], [0.05, 0.05, 0.05], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Capsule", [0.11, 3.295, 0.2], [0.05, 0.05, 0.05], [0, 0, 45], "light gray", "choochoopart"],
    [true, "Capsule", [0.07, 3.3215, 0.2], [0.05, 0.05, 0.05], [0, 0, 67.5], "light gray", "choochoopart"],
    [true, "Cylinder", [0, 3.331, 0.2], [0.0497, 0.05, 0.0497], [0, 0, 90], "light gray", "choochoopart"],
    [true, "Capsule", [-0.07, 3.3215, 0.2], [0.05, 0.05, 0.05], [0, 0, -67.5], "light gray", "choochoopart"],
    [true, "Capsule", [-0.11, 3.295, 0.2], [0.05, 0.05, 0.05], [0, 0, -45], "light gray", "choochoopart"],
    [true, "Capsule", [-0.13, 3.25, 0.2], [0.05, 0.05, 0.05], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Capsule", [0, 3.331, 0.2], [0.06, 0.08, 0.06], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [0, 3.195, 0.665], [0.02, 0.5, 0.02], [-66, 0, 0], "light gray", "choochoopart"],
    // the top 4014
    [false, "Cube", [0.7, 3.15, 0.55], [0.7, 0.3, 0.05], [0, -50, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0.56, 3, 0.69], [0.4, 0.02, 0.43], [0, -50, 0], "gray", "choochoopart"],
    [false, "Cube", [0.66, 2.94, 0.61], [0.21, 0.12, 0.02], [0, 0, 0], "light gray", "choochoopart"],
    [false, "Cube", [0.545, 3.15, 0.333], [0.03, 0.2, 0.01], [0, -50, 23], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.545, 3.15, 0.333], [0.03, 0.2, 0.01], [0, -50, -23], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.655, 3.15, 0.464], [0.03, 0.2, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.6275, 3.174, 0.431], [0.03, 0.158, 0.01], [0, -50, -31], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.632, 3.1, 0.436], [0.12, 0.03, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.702, 3.15, 0.52], [0.03, 0.1, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.7145, 3.2145, 0.535], [0.03, 0.069, 0.01], [0, -50, -43], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.732, 3.235, 0.556], [0.03, 0.03, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.7495, 3.2145, 0.577], [0.03, 0.069, 0.01], [0, -50, 43], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.762, 3.15, 0.592], [0.03, 0.1, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.7495, 3.0855, 0.577], [0.03, 0.069, 0.01], [0, -50, -43], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.732, 3.065, 0.556], [0.03, 0.03, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.7145, 3.0855, 0.535], [0.03, 0.069, 0.01], [0, -50, 43], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.807, 3.15, 0.646], [0.03, 0.2, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.904, 3.15, 0.761], [0.03, 0.2, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.8765, 3.174, 0.728], [0.03, 0.158, 0.01], [0, -50, -31], "yellow light", "choochoopart", 0.5, 0],
    [false, "Cube", [0.881, 3.1, 0.733], [0.12, 0.03, 0.01], [0, -50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.7, 3.15, 0.55], [0.7, 0.3, 0.05], [0, 50, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.56, 3, 0.69], [0.4, 0.02, 0.43], [0, 50, 0], "gray", "choochoopart"],
    [true, "Cube", [-0.66, 2.94, 0.61], [0.21, 0.12, 0.02], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Cube", [-0.886, 3.15, 0.74], [0.03, 0.2, 0.01], [0, 50, -23], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.886, 3.15, 0.74], [0.03, 0.2, 0.01], [0, 50, 23], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.777, 3.15, 0.61], [0.03, 0.2, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.8045, 3.174, 0.643], [0.03, 0.158, 0.01], [0, 50, -31], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.8, 3.1, 0.638], [0.12, 0.03, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.73, 3.15, 0.554], [0.03, 0.1, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.7175, 3.2145, 0.539], [0.03, 0.069, 0.01], [0, 50, -43], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.7, 3.235, 0.518], [0.03, 0.03, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.6825, 3.2145, 0.497], [0.03, 0.069, 0.01], [0, 50, 43], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.67, 3.15, 0.482], [0.03, 0.1, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.6825, 3.0855, 0.497], [0.03, 0.069, 0.01], [0, 50, -43], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.7, 3.065, 0.518], [0.03, 0.03, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.7175, 3.0855, 0.539], [0.03, 0.069, 0.01], [0, 50, 43], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.625, 3.15, 0.428], [0.03, 0.2, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.528, 3.15, 0.311], [0.03, 0.2, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.5555, 3.174, 0.344], [0.03, 0.158, 0.01], [0, 50, -31], "yellow light", "choochoopart", 0.5, 0],
    [true, "Cube", [-0.551, 3.1, 0.339], [0.12, 0.03, 0.01], [0, 50, 0], "yellow light", "choochoopart", 0.5, 0],
    // the lanterns
    [false, "Cylinder", [-0.96, 2.75, 0.47], [0.23, 0.16, 0.23], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.96, 2.775, 0.47], [0.23, 0.13, 0.23], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-0.96, 2.775, 0.47], [0.23, 0.13, 0.23], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Sphere", [-1.09, 2.775, 0.47], [0.04, 0.18, 0.18], [0, 0, 0], "yellow light", "choochoopart", 1, 3],
    [false, "Sphere", [-0.96, 2.775, 0.34], [0.18, 0.18, 0.04], [0, 0, 0], "yellow light", "choochoopart", 1, 3],
    [true, "Cube", [-0.96, 2.59, 0.52], [0.13, 0.02, 0.25], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [0.96, 2.75, 0.47], [0.22, 0.16, 0.22], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.96, 2.775, 0.47], [0.23, 0.13, 0.23], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.96, 2.775, 0.47], [0.23, 0.13, 0.23], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Sphere", [1.09, 2.775, 0.47], [0.04, 0.18, 0.18], [0, 0, 0], "yellow light", "choochoopart", 1, 3],
    [false, "Sphere", [0.96, 2.775, 0.34], [0.18, 0.18, 0.04], [0, 0, 0], "yellow light", "choochoopart", 1, 3],
    [true, "Cube", [0.96, 2.59, 0.52], [0.13, 0.02, 0.25], [0, 0, 0], "gray", "choochoopart"],
    // boiler
    [false, "Cylinder", [0, 1.9, 8.9], [2.7, 5.2, 2.7], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Capsule", [0, 1.9, 3.63], [2.63, 0.09, 2.63], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0, 1.9, 3.8], [2.72, 0.05, 2.72], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0, 1.9, 6.2], [2.72, 0.05, 2.72], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0, 1.9, 7.6], [2.72, 0.05, 2.72], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0, 1.9, 8.8], [2.72, 0.05, 2.72], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0, 1.9, 11.2], [2.72, 0.05, 2.72], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0, 1.9, 12], [2.72, 0.05, 2.72], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0, 1.9, 13.2], [2.72, 0.05, 2.72], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Capsule", [0, 3, 13.4], [1.7, 1.5, 1.1], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 4], [0.2, 0.01, 0.2], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 4], [0.15, 0.015, 0.15], [0, 0, -63], "darker gray", "choochoopart"],
    [true, "Cube", [1.21, 2.45, 4], [0.05, 0.05, 0.05], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 5], [0.2, 0.01, 0.2], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 5], [0.15, 0.015, 0.15], [0, 0, -63], "darker gray", "choochoopart"],
    [true, "Cube", [1.21, 2.45, 5], [0.05, 0.05, 0.05], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 8.5], [0.2, 0.01, 0.2], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 8.5], [0.15, 0.015, 0.15], [0, 0, -63], "darker gray", "choochoopart"],
    [true, "Cube", [1.21, 2.45, 8.5], [0.05, 0.05, 0.05], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 10], [0.2, 0.01, 0.2], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 10], [0.15, 0.015, 0.15], [0, 0, -63], "darker gray", "choochoopart"],
    [true, "Cube", [1.21, 2.45, 10], [0.05, 0.05, 0.05], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 11], [0.2, 0.01, 0.2], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 11], [0.15, 0.015, 0.15], [0, 0, -63], "darker gray", "choochoopart"],
    [true, "Cube", [1.21, 2.45, 11], [0.05, 0.05, 0.05], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 12.25], [0.2, 0.01, 0.2], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 12.25], [0.15, 0.015, 0.15], [0, 0, -63], "darker gray", "choochoopart"],
    [true, "Cube", [1.21, 2.45, 12.25], [0.05, 0.05, 0.05], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 13], [0.2, 0.01, 0.2], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 13], [0.15, 0.015, 0.15], [0, 0, -63], "darker gray", "choochoopart"],
    [true, "Cube", [1.21, 2.45, 13], [0.05, 0.05, 0.05], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 13.75], [0.2, 0.01, 0.2], [0, 0, -63], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, 2.45, 13.75], [0.15, 0.015, 0.15], [0, 0, -63], "darker gray", "choochoopart"],
    [true, "Cube", [1.21, 2.45, 13.75], [0.05, 0.05, 0.05], [0, 0, -63], "light gray", "choochoopart"],
    [false, "Capsule", [0, 3, 10], [1.6, 1.2, 1.2], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Capsule", [0, 3.15, 7], [1, 0.4, 1], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Capsule", [0.4, 3.22, 7.8], [0.2, 0.1, 0.2], [0, 0, -20], "darker gray", "choochoopart"],
    [false, "Capsule", [0.43, 3.32, 7.8], [0.24, 0.08, 0.24], [0, 0, -20], "darker gray", "choochoopart"],
    [false, "Capsule", [0.43, 3.32, 8.1], [0.24, 0.08, 0.24], [0, 0, -20], "darker gray", "choochoopart"],
    [false, "Capsule", [0.4, 3.22, 8.1], [0.2, 0.1, 0.2], [0, 0, -20], "darker gray", "choochoopart"],
    [false, "Capsule", [0, 3, 5], [1.6, 1.2, 1.2], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Capsule", [0.75, 3.2, 11.4], [0.3, 0.3, 0.3], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Capsule", [0.75, 3.2, 11.8], [0.3, 0.3, 0.3], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cube", [0.83, 3.05, 11.6], [0.4, 0.01, 0.6], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.51, 3.45, 11.4], [0.1, 0.27, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.51, 3.45, 11.8], [0.1, 0.27, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.025, 2.9, 11.34], [0.01, 0.3, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.025, 2.9, 11.86], [0.01, 0.3, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0.9, 3.2, 11.24], [0.1, 0.06, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.9, 3, 11.22], [0.03, 0.2, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0.9, 3.2, 11.64], [0.1, 0.06, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [0.89, 2.98, 13.5], [0.1, 0.17, 0.1], [0, 0, 50], "dark gray", "choochoopart"],
    [false, "Capsule", [1.02, 2.85, 13.5], [0.1, 0.17, 0.1], [0, 0, 40], "dark gray", "choochoopart"],
    [false, "Capsule", [1.122, 2.71, 13.5], [0.1, 0.17, 0.1], [0, 0, 32], "dark gray", "choochoopart"],
    [false, "Capsule", [1.23, 2.53, 13.5], [0.1, 0.17, 0.1], [0, 0, 30], "dark gray", "choochoopart"],
    [false, "Capsule", [1.31, 2.36, 13.5], [0.1, 0.17, 0.1], [0, 0, 20], "dark gray", "choochoopart"],
    [false, "Capsule", [1.36, 2.17, 13.5], [0.1, 0.17, 0.1], [0, 0, 10], "dark gray", "choochoopart"],
    [false, "Capsule", [1.377, 1.97, 13.5], [0.1, 0.17, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.377, 1.79, 13.5], [0.2, 0.15, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.377, 1.79, 13.6], [0.1, 0.07, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.79, 13.85], [0.03, 0.3, 0.03], [90, 0, 0], "light gray", "choochoopart"],
    [false, "Capsule", [1.377, 1.57, 13.5], [0.1, 0.17, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.377, 1.41, 13.5], [0.1, 0.12, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.377, 1.335, 13.425], [0.1, 0.12, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.335, 10.47], [0.1, 2.9, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.377, 1.335, 7.57], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.26, 7.44], [0.1, 0.15, 0.1], [60, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.377, 1.185, 7.31], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.185, 5.94], [0.1, 1.37, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.377, 1.185, 4.57], [0.1, 0.1, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.474, 1.135, 4.473], [0.1, 0.15, 0.1], [70, -45, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.571, 1.085, 4.376], [0.1, 0.1, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 4.336], [0.1, 0.04, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 4.286], [0.14, 0.01, 0.2], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 4.267], [0.14, 0.01, 0.14], [90, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [1.546, 1.124, 4.25], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.596, 1.124, 4.25], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.621, 1.085, 4.25], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.596, 1.046, 4.25], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.546, 1.046, 4.25], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.165, 4.166], [0.02, 0.15, 0.02], [90, 0, 0], "light gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 4.166], [0.06, 0.1, 0.06], [90, 0, 0], "light gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.005, 4.166], [0.02, 0.15, 0.02], [90, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [1.546, 1.124, 4.082], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.596, 1.124, 4.082], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.621, 1.085, 4.082], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.596, 1.046, 4.082], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.546, 1.046, 4.082], [0.023, 0.01, 0.023], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 4.065], [0.14, 0.01, 0.14], [90, 0, 0], "light gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 4.046], [0.14, 0.01, 0.2], [90, 0, 0], "gray", "choochoopart"],
    [false, "Capsule", [1.571, 1.085, 3.98], [0.13, 0.1, 0.13], [90, 0, 0], "gray", "choochoopart"],
    [true, "Capsule", [1.571, 1.01, 3.95], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.571, 0.98, 3.95], [0.03, 0.1, 0.03], [0, 0, 0], "gray", "choochoopart"],
    [false, "Capsule", [1.571, 0.88, 3.95], [0.15, 0.01, 0.15], [0, 0, 0], "red", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 3.855], [0.1, 0.045, 0.1], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 3.82], [0.14, 0.01, 0.14], [90, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [1.54, 1.136, 3.807], [0.018, 0.036, 0.018], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.602, 1.136, 3.807], [0.018, 0.036, 0.018], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.631, 1.085, 3.807], [0.018, 0.036, 0.018], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.602, 1.034, 3.807], [0.018, 0.036, 0.018], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.54, 1.034, 3.807], [0.018, 0.036, 0.018], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 3.794], [0.14, 0.01, 0.14], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.085, 3.76], [0.1, 0.05, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.571, 1.085, 3.71], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.474, 1.135, 3.614], [0.1, 0.15, 0.1], [110, 45, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.377, 1.185, 3.516], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.185, 2.516], [0.1, 1, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.377, 1.185, 1.516], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.085, 1.516], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.377, 1.1, 1.516], [0.15, 0.02, 0.15], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.377, 1.076, 1.516], [0.15, 0.02, 0.15], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.427, 1.088, 1.566], [0.03, 0.036, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.427, 1.088, 1.466], [0.03, 0.036, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.327, 1.088, 1.566], [0.03, 0.036, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.327, 1.088, 1.466], [0.03, 0.036, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [1.377, 0.94, 1.516], [0.2, 0.08, 0.2], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 0.94, 1.4], [0.14, 0.08, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.273, 0.8, 1.458], [0.2, 0.136, 0.2], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.273, 0.8, 1.338], [0.3, 0.02, 0.3], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.39, 0.84, 1.36], [0.04, 0.02, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.373, 0.73, 1.36], [0.04, 0.02, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Sphere", [1.273, 0.8, 1.318], [0.3, 0.11, 0.3], [90, 0, 0], "dark gray", "choochoopart"],
    // feedwater pump
    [false, "Cylinder", [1.473, 1.11, 1.616], [0.03, 0.45, 0.03], [73, 9, 0], "light gray", "choochoopart"],
    [false, "Cylinder", [1.405, 0.978, 1.19], [0.05, 0.06, 0.05], [73, 9, 0], "light gray", "choochoopart"],
    [false, "Capsule", [1.39, 0.93, 1.2], [0.1, 0.05, 0.1], [0, 0, 90], "gray", "choochoopart"],
    [false, "Cylinder", [1.369, 0.878, 1.22], [0.05, 0.1, 0.05], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cube", [1.273, 0.73, 1.12], [0.3, 0.16, 0.4], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.233, 1, 1.22], [0.25, 0.4, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.273, 0.8, 1.12], [0.3, 0.11, 0.3], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.273, 0.8, 0.97], [0.3, 0.15, 0.3], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.273, 0.8, 0.848], [0.34, 0.02, 0.34], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.273, 0.8, 0.815], [0.34, 0.01, 0.34], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.416, 0.8, 0.81], [0.04, 0.03, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.34, 0.92, 0.81], [0.04, 0.03, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.34, 0.7, 0.81], [0.04, 0.03, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.206, 0.92, 0.81], [0.04, 0.03, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.206, 0.7, 0.81], [0.04, 0.03, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.273, 0.8, 0.754], [0.15, 0.15, 0.12], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.273, 0.83, 0.685], [0.3, 0.05, 0.3], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.273, 0.83, 0.613], [0.2, 0.06, 0.2], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.273, 0.83, 0.54], [0.2, 0.01, 0.2], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.273, 0.83, 0.505], [0.12, 0.08, 0.12], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.273, 0.91, 0.54], [0.03, 0.02, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.273, 0.75, 0.54], [0.03, 0.02, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.341, 0.87, 0.54], [0.03, 0.02, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.341, 0.79, 0.54], [0.03, 0.02, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.205, 0.87, 0.54], [0.03, 0.02, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.205, 0.78, 0.54], [0.03, 0.02, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [1.273, 1.05, 0.6], [0.08, 0.13, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.273, 1.18, 0.6], [0.08, 0.08, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.343, 1.18, 0.6], [0.08, 0.07, 0.08], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Sphere", [1.413, 1.18, 0.6], [0.08, 0.08, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.453, 1.14, 0.6], [0.08, 0.056, 0.08], [0, 0, 45], "dark gray", "choochoopart"],
    [false, "Sphere", [1.493, 1.1, 0.6], [0.08, 0.08, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.493, 1.1, 0.815], [0.08, 0.215, 0.08], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.493, 1.1, 0.68], [0.12, 0.02, 0.12], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.533, 1.14, 0.692], [0.03, 0.033, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.533, 1.06, 0.692], [0.03, 0.033, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.453, 1.14, 0.692], [0.03, 0.033, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.453, 1.06, 0.692], [0.03, 0.033, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.493, 1.1, 0.704], [0.12, 0.02, 0.12], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.493, 1.1, 0.815], [0.2, 0.2, 0.2], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.493, 0.955, 0.815], [0.02, 0.06, 0.02], [0, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.493, 1, 0.815], [0.03, 0.02, 0.03], [0, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.493, 0.93, 0.815], [0.03, 0.02, 0.03], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.51, 0.93, 0.815], [0.013, 0.01, 0.013], [0, 0, 90], "light gray", "choochoopart"],
    [false, "Cube", [1.513, 0.93, 0.77], [0.005, 0.022, 0.12], [0, 0, 0], "red", "choochoopart"],
    [true, "Cube", [1.493, 1.1, 0.926], [0.12, 0.02, 0.12], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.533, 1.14, 0.938], [0.03, 0.033, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.533, 1.06, 0.938], [0.03, 0.033, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.453, 1.14, 0.938], [0.03, 0.033, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.453, 1.06, 0.938], [0.03, 0.033, 0.03], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.493, 1.1, 0.95], [0.12, 0.02, 0.12], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.493, 1.1, 1], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.532, 1.16, 1.1], [0.1, 0.122, 0.1], [60.8, 21.3, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.571, 1.22, 1.2], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.22, 1.7], [0.1, 0.5, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.571, 1.22, 2.2], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.15, 2.53], [0.1, 0.337, 0.1], [102, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.571, 1.08, 2.91], [0.1, 0.1, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.545, 1.08, 3.007], [0.1, 0.1, 0.1], [90, -30, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.476, 1.08, 3.076], [0.1, 0.1, 0.1], [90, -60, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.129, 1.08, 3.101], [0.1, 0.3, 0.1], [90, -90, 0], "dark gray", "choochoopart"],
    // platform below the feedwater pump
    [false, "Cube", [1.282, 0.61, 0.97], [0.352, 0.04, 0.72], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.282, 0.655, 0.685], [0.35, 0.045, 0.14], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.126, 0.675, 0.635], [0.03, 0.05, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.438, 0.675, 0.635], [0.03, 0.05, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.438, 0.675, 0.735], [0.03, 0.05, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.282, 0.695, 0.685], [0.35, 0.03, 0.14], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.282, 0.637, 0.955], [0.35, 0.03, 0.07], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.423, 0.665, 0.925], [0.04, 0.06, 0.01], [0, 0, 35], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.44, 0.66, 0.955], [0.03, 0.01, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.423, 0.665, 0.985], [0.04, 0.06, 0.01], [0, 0, 35], "dark gray", "choochoopart"],
    [true, "Cube", [1.423, 0.665, 1.315], [0.04, 0.06, 0.01], [0, 0, 35], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.44, 0.66, 1.285], [0.03, 0.01, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.423, 0.665, 1.255], [0.04, 0.06, 0.01], [0, 0, 35], "dark gray", "choochoopart"],
    [false, "Cube", [1.282, 0.637, 1.285], [0.35, 0.03, 0.07], [0, 0, 0], "dark gray", "choochoopart"],
    // the holdings for the pipes directly below the runway
    [false, "Cylinder", [1.377, 1.335, 13.1], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.377, 1.38, 13.1], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.377, 1.335, 11.8], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.377, 1.38, 11.8], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.335, 10.5], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.377, 1.38, 10.5], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.377, 1.335, 9.2], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.377, 1.38, 9.2], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.335, 7.9], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.377, 1.38, 7.9], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.185, 6.9], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.377, 1.23, 6.9], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.377, 1.185, 5.8], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.377, 1.23, 5.8], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.185, 4.7], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.377, 1.23, 4.7], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.377, 1.185, 3.2], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.377, 1.23, 3.2], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.377, 1.185, 2], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.377, 1.23, 2], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.571, 1.22, 2.1], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.571, 1.265, 2.1], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.571, 1.22, 1.3], [0.14, 0.03, 0.14], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.571, 1.265, 1.3], [0.14, 0.09, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    // the pipes below the pump
    [false, "Cylinder", [1.151, 0.84, 1.52], [0.1, 0.21, 0.1], [90, -2, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.144, 0.84, 1.729], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.207, 0.84, 1.864], [0.1, 0.15, 0.1], [90, 25, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.27, 0.84, 2], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.27, 0.84, 2.34], [0.1, 0.34, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.27, 0.84, 2.41], [0.15, 0.01, 0.15], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.237, 0.893, 2.398], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.303, 0.893, 2.398], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.333, 0.84, 2.398], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.303, 0.787, 2.398], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.237, 0.787, 2.398], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.27, 0.84, 2.386], [0.15, 0.01, 0.15], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.27, 0.84, 2.68], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.895, 0.84, 2.815], [0.1, 0.4, 0.1], [90, -70, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.158, 0.962, 1.49], [0.1, 0.2, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.158, 0.962, 1.688], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.214, 0.962, 1.744], [0.1, 0.08, 0.1], [90, 45, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.27, 0.962, 1.8], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.27, 0.962, 2.14], [0.1, 0.34, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.27, 0.962, 2.3], [0.15, 0.01, 0.15], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.237, 1.015, 2.288], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.303, 1.015, 2.288], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.333, 0.962, 2.288], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.303, 0.909, 2.288], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.237, 0.909, 2.288], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.27, 0.962, 2.276], [0.15, 0.01, 0.15], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.27, 0.962, 2.48], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.11, 0.831, 2.64], [0.1, 0.26, 0.1], [120, -45, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [0.95, 0.7, 2.8], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.95, 0.7, 4.5], [0.1, 1.7, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.025, 0.314, 6.25], [0.1, 0.25, 0.1], [0, 0, 45], "dark gray", "choochoopart"],
    [true, "Sphere", [1.202, 0.137, 6.25], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.22, -0.21, 6.22], [0.1, 0.35, 0.1], [5, 0, 3], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.24, -0.63, 6.185], [0.25, 0.1, 0.25], [5, 0, 3], "dark gray", "choochoopart"],
    // back pipes
    [false, "Cylinder", [0.85, 0.6, 7.45], [0.1, 1.25, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [0.85, 0.6, 8.7], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.01, 0.65, 9.252], [0.1, 0.576, 0.1], [85, 16.1, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.17, 0.7, 9.803], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.7, 9.953], [0.1, 0.15, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.17, 0.7, 10.103], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.575, 10.103], [0.1, 0.125, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.17, 0.45, 10.103], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.322, 11.8], [0.1, 1.7, 0.1], [94.3, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.17, 0.194, 13.497], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.194, 14.497], [0.1, 1, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.145, 0.194, 15.542], [0.1, 0.1, 0.1], [90, -30, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.076, 0.194, 15.611], [0.1, 0.1, 0.1], [90, -60, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.75, 0.194, 15.636], [0.1, 0.28, 0.1], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.85, 0.6, 7.938], [0.15, 0.01, 0.15], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.85, 0.6, 7.962], [0.15, 0.01, 0.15], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.85, 0.662, 7.95], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0.903, 0.632, 7.95], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0.903, 0.568, 7.95], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0.85, 0.538, 7.95], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.307, 11.988], [0.15, 0.01, 0.15], [94.3, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.307, 12.012], [0.15, 0.01, 0.15], [94.3, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.369, 12.004], [0.022, 0.036, 0.022], [94.3, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.223, 0.339, 12.002], [0.022, 0.036, 0.022], [94.3, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.223, 0.275, 11.998], [0.022, 0.036, 0.022], [94.3, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.245, 11.996], [0.022, 0.036, 0.022], [94.3, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.194, 14.938], [0.15, 0.01, 0.15], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.194, 14.962], [0.15, 0.01, 0.15], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.256, 14.95], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.223, 0.226, 14.95], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.223, 0.162, 14.95], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.132, 14.95], [0.022, 0.036, 0.022], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [0.85, 0.6, 7.7], [0.13, 0.03, 0.13], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [0.75, 0.7, 7.7], [0.128, 0.3, 0.06], [0, 0, 45], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.01, 0.65, 9.252], [0.13, 0.03, 0.13], [85, 16.1, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.905, 0.756, 9.273], [0.128, 0.3, 0.06], [-5, 16.1, 45], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.365, 11.2], [0.13, 0.03, 0.13], [94.3, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.17, 0.445, 11.206], [0.13, 0.16, 0.06], [4.3, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.27, 12.5], [0.13, 0.03, 0.13], [94.3, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.8, 0.27, 12.5], [0.74, 0.13, 0.06], [4.3, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.194, 14.55], [0.13, 0.03, 0.13], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [0.8, 0.194, 14.55], [0.74, 0.13, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.465, 12.45], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.38, 12.475], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.38, 12.425], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.43, 12.49], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.43, 12.41], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [false, "Cylinder", [1.04, 0.42, 12.45], [0.13, 0.13, 0.13], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.09, 0.4, 12.53], [0.1, 0.075, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.09, 0.42, 12.33], [0.03, 0.075, 0.03], [90, 0, 0], "gray", "choochoopart"],
    [false, "Capsule", [1.09, 0.42, 12.25], [0.12, 0.012, 0.12], [90, 0, 0], "red", "choochoopart"],
    [false, "Cylinder", [0.82, 0.4, 12.6], [0.1, 0.35, 0.1], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Sphere", [1.17, 0.4, 12.6], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.4, 12.8], [0.1, 0.2, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.17, 0.4, 13], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.36, 13.24], [0.1, 0.243, 0.1], [99.5, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.17, 0.32, 13.48], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.32, 14.13], [0.1, 0.65, 0.1], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.17, 0.32, 14.78], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.17, 0.47, 14.78], [0.1, 0.15, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.17, 0.62, 14.78], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.82, 0.62, 14.78], [0.1, 0.35, 0.1], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.14, 0.46, 12.725], [0.05, 0.275, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.14, 0.46, 13], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.14, 0.42, 13.24], [0.05, 0.243, 0.05], [99.45, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.14, 0.38, 13.48], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.14, 0.38, 14.03], [0.05, 0.55, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.14, 0.38, 14.58], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.14, 0.46, 14.58], [0.05, 0.08, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.14, 0.54, 14.58], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.14, 0.54, 14.5], [0.05, 0.08, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.17, 0.43, 12.8], [0.15, 0.19, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.25, 0.47, 12.8], [0.04, 0.02, 0.04], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.25, 0.36, 12.8], [0.04, 0.02, 0.04], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cube", [1.17, 0.34, 13.525], [0.15, 0.19, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.25, 0.37, 13.525], [0.04, 0.02, 0.04], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.25, 0.27, 13.525], [0.04, 0.02, 0.04], [0, 0, 90], "gray", "choochoopart"],
    [false, "Cylinder", [0.98, -0.05, 15.92], [0.3, 0.25, 0.3], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.25, -0.05, 15.92], [0.15, 0.06, 0.15], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.31, 0.01, 15.92], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.31, -0.05, 15.86], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.31, -0.05, 15.98], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.31, -0.11, 15.92], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, 0.065, 15.965], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, 0, 16.03], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, -0.1, 16.03], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, -0.165, 15.965], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, 0.065, 15.875], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, 0, 15.81], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, -0.1, 15.81], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, -0.165, 15.875], [0.025, 0.02, 0.025], [0, 0, 90], "gray", "choochoopart"],
    [false, "Cylinder", [1.26, -0.025, 15.845], [0.05, 0.06, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.26, 0.355, 15.845], [0.025, 0.455, 0.025], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Sphere", [1.26, 0.81, 15.845], [0.025, 0.025, 0.025], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [1.32, 0.81, 15.785], [0.025, 0.084, 0.025], [90, -45, 0], "light gray", "choochoopart"],
    [true, "Sphere", [1.38, 0.81, 15.725], [0.025, 0.025, 0.025], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [1.38, 0.81, 14.565], [0.025, 1.16, 0.025], [90, 0, 0], "light gray", "choochoopart"],
    [true, "Sphere", [1.38, 0.81, 13.405], [0.025, 0.025, 0.025], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [1.38, 1.03, 13.405], [0.025, 0.22, 0.025], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Sphere", [1.38, 1.25, 13.405], [0.025, 0.025, 0.025], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [1.38, 1.25, 13.755], [0.025, 0.35, 0.025], [90, 0, 0], "light gray", "choochoopart"],
    [true, "Cylinder", [1.16, 0.11, 15.92], [0.07, 0.015, 0.07], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.16, 0.175, 15.92], [0.1, 0.015, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.16, 0.21, 15.92], [0.08, 0.02, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.16, 0.32, 15.92], [0.05, 0.23, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.16, 0.55, 15.92], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.33, 0.6505, 15.12], [0.05, 0.824, 0.05], [97, -12, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.5, 0.751, 14.32], [0.05, 0.05, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.5, 0.751, 13.67], [0.05, 0.65, 0.05], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.5, 0.763, 12.997], [0.05, 0.05, 0.05], [-60, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.5, 0.798, 12.962], [0.05, 0.05, 0.05], [-30, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.5, 0.999, 12.95], [0.05, 0.178, 0.05], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.488, 1.2, 12.95], [0.05, 0.05, 0.05], [0, 0, 30], "dark gray", "choochoopart"],
    [false, "Capsule", [1.453, 1.235, 12.95], [0.05, 0.05, 0.05], [0, 0, 60], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.353, 1.247, 12.95], [0.05, 0.08, 0.05], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.5, 0.999, 12.95], [0.08, 0.02, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.4, 0.999, 12.95], [0.2, 0.04, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.5, 1.099, 12.95], [0.08, 0.02, 0.08], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.5, 1.099, 12.95], [0.065, 0.04, 0.065], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.5, 0.751, 13.87], [0.08, 0.02, 0.08], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.4, 0.751, 13.87], [0.2, 0.08, 0.04], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.5, 0.751, 14.2], [0.08, 0.02, 0.08], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.5, 0.751, 14.2], [0.065, 0.04, 0.065], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.8, 0.15, 15.92], [0.1, 0.06, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.8, 0.19, 15.92], [0.14, 0.02, 0.14], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.8, 0.37, 15.92], [0.12, 0.18, 0.12], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [0.8, 0.55, 15.92], [0.12, 0.12, 0.12], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.8, 0.55, 15.57], [0.12, 0.35, 0.12], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [0.8, 0.55, 15.22], [0.12, 0.12, 0.12], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [0.8, 0.75, 15.22], [0.12, 0.2, 0.12], [0, 0, 0], "dark gray", "choochoopart"],
    // the big pipes
    [false, "Cylinder", [1.28, 1.05, 8.6], [0.4, 0.8, 0.4], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.28, 1.05, 8.1], [0.42, 0.02, 0.42], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.28, 1.05, 9.1], [0.42, 0.02, 0.42], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.28, 1.05, 7.8], [0.4, 0.4, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.28, 1.05, 9.4], [0.4, 0.4, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.32, 1.255, 8.1], [0.4, 0.02, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.32, 1.255, 9.1], [0.4, 0.02, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.32, 1.28, 8.055], [0.4, 0.03, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.32, 1.28, 9.055], [0.4, 0.03, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.32, 1.28, 8.145], [0.4, 0.03, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.32, 1.28, 9.145], [0.4, 0.03, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.485, 1.165, 8.1], [0.01, 0.23, 0.04], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.485, 1.165, 9.1], [0.01, 0.23, 0.04], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.945, 1.05, 7.594], [0.05, 0.3, 0.05], [0, 0, 90], "gray", "choochoopart"],
    [true, "Capsule", [1.262, 1.05, 7.612], [0.05, 0.05, 0.05], [90, 45, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.28, 1.05, 7.67], [0.05, 0.04, 0.05], [90, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.28, 1.05, 9.52], [0.05, 0.04, 0.05], [90, 0, 0], "gray", "choochoopart"],
    [true, "Capsule", [1.28, 1.068, 9.578], [0.05, 0.05, 0.05], [45, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.364, 1.225, 9.595], [0.05, 0.165, 0.05], [0, 0, -31.1], "gray", "choochoopart"],
    [true, "Sphere", [1.45, 1.367, 9.595], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.45, 1.367, 8.610], [0.05, 0.985, 0.05], [90, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.45, 1.367, 7.626], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.45, 1.302, 7.333], [0.05, 0.3, 0.05], [77.5, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.45, 1.237, 7.04], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.45, 1.237, 6.94], [0.05, 0.1, 0.05], [90, 0, 0], "gray", "choochoopart"],
    [true, "Capsule", [1.45, 1.22, 6.822], [0.05, 0.05, 0.05], [45, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.45, 1.08, 6.805], [0.05, 0.125, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Capsule", [1.45, 0.938, 6.788], [0.05, 0.05, 0.05], [45, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.45, 0.92, 6.73], [0.05, 0.04, 0.05], [90, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.45, 0.92, 4.47], [0.05, 0.04, 0.05], [90, 0, 0], "gray", "choochoopart"],
    [true, "Capsule", [1.432, 0.92, 4.412], [0.05, 0.05, 0.05], [90, 45, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.115, 0.92, 4.394], [0.05, 0.3, 0.05], [0, 0, 90], "gray", "choochoopart"],
    [false, "Cylinder", [1.45, 0.92, 5.6], [0.34, 1, 0.34], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.45, 0.92, 5], [0.36, 0.02, 0.36], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.45, 0.92, 6.3], [0.36, 0.02, 0.36], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.45, 0.92, 4.6], [0.34, 0.34, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.45, 0.92, 6.6], [0.34, 0.34, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.36, 1.1, 5], [0.6, 0.02, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.36, 1.1, 6.3], [0.6, 0.02, 0.1], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.36, 1.125, 4.955], [0.6, 0.03, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.36, 1.125, 6.255], [0.6, 0.03, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.36, 1.125, 5.045], [0.6, 0.03, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.36, 1.125, 6.345], [0.6, 0.03, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.625, 1.023, 5], [0.01, 0.203, 0.04], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.625, 1.023, 6.3], [0.01, 0.203, 0.04], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.1, 0.58, 6.75], [0.36, 0.4, 0.36], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.26, 0.4, 6.8], [0.25, 0.28, 0.25], [0, 0, 30], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.1, 0.58, 5.5], [0.25, 1, 0.25], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.1, 0.58, 4.5], [0.25, 0.25, 0.25], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.1, 0.735, 4.135], [0.25, 0.4, 0.25], [113, 0, 0], "dark gray", "choochoopart"],
    [false, "Sphere", [1.1, 0.89, 3.77], [0.25, 0.25, 0.25], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.1, 0.89, 3.57], [0.25, 0.2, 0.25], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.1, 0.89, 3.39], [0.4, 0.02, 0.4], [90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0.987, 1.003, 3.37], [0.05, 0.06, 0.05], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.1, 1.05, 3.37], [0.05, 0.06, 0.05], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.213, 1.003, 3.37], [0.05, 0.06, 0.05], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.26, 0.89, 3.37], [0.05, 0.06, 0.05], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.213, 0.777, 3.37], [0.05, 0.06, 0.05], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.1, 0.73, 3.37], [0.05, 0.06, 0.05], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [0.987, 0.777, 3.37], [0.05, 0.06, 0.05], [90, 0, 0], "darker gray", "choochoopart"],
    [false, "Cylinder", [1.1, 0.89, 3.35], [0.4, 0.02, 0.4], [90, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.1, 0.89, 3.17], [0.25, 0.2, 0.25], [90, 0, 0], "gray", "choochoopart"],
    [false, "Sphere", [1.1, 0.89, 2.97], [0.25, 0.25, 0.25], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.1, 0.992, 2.73], [0.25, 0.26, 0.25], [113, 0, 0], "gray", "choochoopart"],
    [false, "Sphere", [1.1, 1.094, 2.49], [0.25, 0.25, 0.25], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [1.075, 1.444, 2.49], [0.25, 0.35, 0.25], [0, 0, 4], "gray", "choochoopart"],
    [false, "Cylinder", [1.026, 1.06, 2.145], [0.248, 0.355, 0.248], [84.5, 12.25, 0], "gray", "choochoopart"],
    [false, "Capsule", [0.95, 0.9, 1.8], [0.25, 0.25, 0.25], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cylinder", [0.95, 0.65, 1.8], [0.5, 0.14, 0.5], [0, 0, 0], "gray", "choochoopart"],
    [false, "Capsule", [0.9, 0.65, 1.6], [0.27, 0.27, 0.27], [90, 7.5, 0], "gray", "choochoopart"],
    [false, "Cylinder", [0.81, 0.59, 0.9], [0.23, 0.6, 0.23], [84, 7.5, 0], "gray", "choochoopart"],
    [false, "Capsule", [0.693, 0.527, 0.2], [0.23, 0.23, 0.23], [90, 20, 0], "gray", "choochoopart"],
    [false, "Cylinder", [0, 0.3, 16.75], [0.5, 1, 0.5], [90, 0, 0], "dark gray", "choochoopart"],
    // firebox
    [false, "Cube", [0, 1.1, 12.3], [2.6, 1.2, 4.3], [0, 0, 0], "light gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.95, 14.35], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.85, 14.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.75, 14.35], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.65, 14.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 14.3], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 14.2], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 14.1], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 14.0], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 13.9], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 13.8], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 13.7], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 13.6], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 13.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 13.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 13.3], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 13.2], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 13.1], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 13.0], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 12.9], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 12.8], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 12.7], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 12.6], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 12.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 12.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 12.3], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 12.2], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 12.1], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 12.0], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 11.9], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 11.8], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 11.7], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 11.6], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 11.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 11.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 11.3], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 11.2], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 11.1], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 11.0], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 10.9], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 10.8], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 10.7], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 10.6], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 10.5], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.6, 10.4], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 10.3], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.65, 10.2], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.75, 10.25], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.85, 10.2], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.95, 10.25], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.05, 10.2], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 10.25], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.25, 10.2], [0.05, 0.05, 0.05], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 10.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 10.5], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 10.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 10.5], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 10.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 10.5], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.85, 10.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.85, 10.5], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.7, 10.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.7, 10.5], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 10.95], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.1, 11.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.1, 10.85], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 11.1], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.9, 11.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.85, 10.95], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.9, 10.85], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 10.8], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.25, 11.45], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.2, 11.55], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.2, 11.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.1, 11.6], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 11.55], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.95, 11.45], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 11.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.1, 11.3], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 11.85], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 12.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.2, 12.1], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.1, 12.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.05, 11.95], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.1, 11.85], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.2, 11.8], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.25, 12.6], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 12.55], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.1, 12.45], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 12.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.25, 12.3], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 13.1], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.2, 13.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 12.95], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.2, 12.85], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 12.8], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 13.6], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.2, 13.55], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 13.45], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.2, 13.35], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 13.3], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 13.75], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 13.9], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.3, 14.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 13.9], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1.15, 14.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 14.2], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 14.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 1, 13.9], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.85, 14.2], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.85, 14.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.7, 14.2], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.7, 14.05], [0.1, 0.1, 0.1], [0, 0, 0], "gray", "choochoopart"],
    [false, "Cube", [0, 0.55, 11.63], [1, 0.99, 8.3], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, -0.045, 15.655], [2.5, 0.2, 0.25], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [1.17, 0.04, 15.52], [0.16, 0.2, 0.02], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.17, 0.135, 15.43], [0.16, 0.02, 0.2], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.13, -0.03, 15.505], [0.04, 0.02, 0.04], [90, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.02, 15.505], [0.04, 0.02, 0.04], [90, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.03, 15.505], [0.04, 0.02, 0.04], [90, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.194, 15.46], [0.14, 0.013, 0.14], [90, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.17, 0.194, 15.37], [0.14, 0.013, 0.14], [90, 0, 0], "gray", "choochoopart"],
    [true, "Cube", [1.23, 0.169, 15.46], [0.02, 0.05, 0.026], [0, 0, 0], "gray", "choochoopart"],
    [true, "Cube", [1.23, 0.169, 15.37], [0.02, 0.05, 0.026], [0, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, 0.126, 15.46], [0.04, 0.016, 0.04], [0, 0, 0], "gray", "choochoopart"],
    [true, "Cylinder", [1.23, 0.126, 15.37], [0.04, 0.016, 0.04], [0, 0, 0], "gray", "choochoopart"],
    // driver cab
    [false, "Cube", [0, 1.9, 14.5], [3.6, 1.7, 0.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, 3.05, 14.5], [2.7, 0.6, 0.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.375, 2.9, 14.5], [0.75, 0.5, 0.8], [0, 0, -53], "darker gray", "choochoopart"],
    [false, "Cube", [1.094, 3.338, 14.5], [0.447, 0.25, 0.8], [0, 0, -26.7], "darker gray", "choochoopart"],
    [false, "Cube", [-1.375, 2.9, 14.5], [0.75, 0.5, 0.8], [0, 0, 53], "darker gray", "choochoopart"],
    [false, "Cube", [-1.094, 3.338, 14.5], [0.447, 0.25, 0.8], [0, 0, 26.7], "darker gray", "choochoopart"],
    [false, "Cube", [0, 3.2, 14.5], [1.9, 0.7, 0.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, 1.075, 15.8], [3.6, 0.05, 1.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.775, 1.4, 15.8], [0.05, 0.7, 1.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [-1.775, 1.4, 15.8], [0.05, 0.7, 1.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.775, 2.68, 15.8], [0.05, 0.14, 1.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [-1.775, 2.68, 15.8], [0.05, 0.14, 1.8], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.849, 1.73, 15.6], [0.1, 0.07, 1.8], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.57, 2.5, 14.1], [0.4, 0.17, 0.01], [0, 0, 0], "yellow light", "choochoopart", 0.25, 0],
    [false, "Cube", [1.57, 2.3, 14.1], [0.4, 0.17, 0.01], [0, 0, 0], "yellow light", "choochoopart", 0.25, 0],
    [false, "Cube", [1.57, 2.1, 14.1], [0.4, 0.17, 0.01], [0, 0, 0], "yellow light", "choochoopart", 0.25, 0],
    [false, "Cube", [1.796, 1.3, 14.9], [0.01, 0.1, 0.4], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.4, 15], [0.01, 0.5, 0.1], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.468, 14.863], [0.01, 0.1, 0.39], [-50.2, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.4, 15.25], [0.01, 0.25, 0.1], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.549, 15.307], [0.01, 0.195, 0.1], [50.1, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.6, 15.4], [0.01, 0.1, 0.1], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.549, 15.493], [0.01, 0.195, 0.1], [-50.1, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.4, 15.55], [0.01, 0.25, 0.1], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.251, 15.493], [0.01, 0.195, 0.1], [50.1, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.2, 15.4], [0.01, 0.1, 0.1], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.251, 15.307], [0.01, 0.195, 0.1], [-50.1, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.4, 15.75], [0.01, 0.5, 0.1], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.3, 16.1], [0.01, 0.1, 0.4], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.4, 16.2], [0.01, 0.5, 0.1], [0, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.796, 1.468, 16.063], [0.01, 0.1, 0.39], [-50.2, 0, 0], "white", "choochoopart", 0.4, 0],
    [false, "Cube", [1.775, 2.18, 16.575], [0.05, 0.86, 0.15], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [-1.775, 2.18, 16.575], [0.05, 0.86, 0.15], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.4, 1.9, 16.675], [0.8, 1.7, 0.05], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [-1.4, 1.9, 16.675], [0.8, 1.7, 0.05], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.331, 2.865, 16.675], [0.75, 0.61, 0.05], [0, 0, -53], "darker gray", "choochoopart"],
    [false, "Cube", [1.065, 3.28, 16.675], [0.445, 0.38, 0.05], [0, 0, -26.7], "darker gray", "choochoopart"],
    [false, "Cube", [-1.331, 2.865, 16.675], [0.75, 0.61, 0.05], [0, 0, 53], "darker gray", "choochoopart"],
    [false, "Cube", [-1.065, 3.28, 16.675], [0.445, 0.38, 0.05], [0, 0, 26.7], "darker gray", "choochoopart"],
    [false, "Cube", [0, 3.08, 16.675], [2.1, 0.94, 0.05], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.625, 3.036, 15.375], [0.86, 0.03, 3], [0, 0, -53], "darker gray", "choochoopart"],
    [false, "Cube", [1.49, 3.216, 17.375], [0.41, 0.03, 1], [0, 0, -53], "darker gray", "choochoopart"],
    [false, "Cube", [1.165, 3.479, 15.875], [0.463, 0.03, 4], [0, 0, -26.7], "darker gray", "choochoopart"],
    [false, "Cube", [0, 3.581, 15.875], [1.93, 0.03, 4], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [-1.165, 3.479, 15.875], [0.463, 0.03, 4], [0, 0, 26.7], "darker gray", "choochoopart"],
    [false, "Cube", [-1.49, 3.216, 17.375], [0.41, 0.03, 1], [0, 0, 53], "darker gray", "choochoopart"],
    [false, "Cube", [-1.625, 3.036, 15.375], [0.86, 0.03, 3], [0, 0, 53], "darker gray", "choochoopart"],
    [false, "Cube", [0, 1.0, 15.4], [3.4, 0.1, 2.6], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.55, 0.9, 15.1], [0.5, 0.1, 3.2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.45, 0.45, 14.5], [0.1, 0.1, 2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, 0.45, 13.975], [2.8, 0.1, 0.95], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.45, 0.69, 15.62], [0.1, 0.38, 0.28], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.52, 0.45, 13.57], [0.06, 0.02, 0.06], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.52, 0.45, 13.67], [0.06, 0.02, 0.06], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.52, 0.45, 13.77], [0.06, 0.02, 0.06], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.52, 0.45, 13.87], [0.06, 0.02, 0.06], [0, 0, 90], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.52, 0.45, 13.97], [0.06, 0.02, 0.06], [0, 0, 90], "dark gray", "choochoopart"],
    [false, "Cube", [1.45, 0.671, 16.082], [0.1, 0.1, 1.28], [-20.5, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.45, 0.88, 16.17], [0.1, 0.23, 1], [-20.5, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.3, 0.701, 16], [0.15, 0.42, 0.03], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.75, 2.65, 16.79], [0.04, 0.1, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Sphere", [1.75, 2.65, 16.89], [0.06, 0.06, 0.06], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.75, 1.65, 16.89], [0.04, 1, 0.04], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Sphere", [1.75, 0.65, 16.89], [0.06, 0.06, 0.06], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.75, 0.65, 16.69], [0.04, 0.2, 0.04], [90, 0, 0], "darker gray", "choochoopart"],
    [true, "Sphere", [1.75, 0.65, 16.49], [0.06, 0.06, 0.06], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cylinder", [1.75, 0.751, 16.49], [0.04, 0.1, 0.04], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, 1.075, 17.2], [3, 0.05, 1], [0, 0, 0], "gray", "choochoopart"],
    // back wheels
    [false, "Cylinder", [0, -0.55, 13.5], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "choochoopart"],
    [false, "Cylinder", [0, -0.55, 14.75], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.445, 13.455], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.445, 13.545], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.505, 13.395], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.595, 13.395], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.505, 13.605], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.595, 13.605], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.655, 13.455], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.655, 13.545], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.445, 14.705], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.445, 14.795], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.505, 14.645], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.595, 14.645], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.505, 14.855], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.595, 14.855], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.655, 14.705], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cylinder", [1.21, -0.655, 14.795], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "choochoopart"],
    [true, "Cube", [0.95, 0.076, 14.125], [0.2, 0.1, 2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.1, -0.024, 14.125], [0.1, 0.3, 2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.1, -0.287, 13.06], [0.1, 0.3, 0.78], [-60, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.1, -0.287, 15.19], [0.1, 0.3, 0.78], [60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0.8, -0.024, 14.125], [0.1, 0.3, 2], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0.8, -0.287, 13.06], [0.1, 0.3, 0.78], [-60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0.8, -0.287, 15.19], [0.1, 0.3, 0.78], [60, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.1, -0.287, 14.25], [0.1, 0.4, 0.5], [-60, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.1, -0.287, 14], [0.1, 0.4, 0.5], [60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0.8, -0.287, 14.25], [0.1, 0.4, 0.5], [-60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0.8, -0.287, 14], [0.1, 0.4, 0.5], [60, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [1.1, -0.55, 14.125], [0.1, 0.4, 3], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [0.8, -0.55, 14.125], [0.1, 0.4, 3], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.95, 0.076, 14.125], [0.2, 0.1, 2], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.1, -0.024, 14.125], [0.1, 0.3, 2], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.1, -0.287, 13.06], [0.1, 0.3, 0.78], [-60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.1, -0.287, 15.19], [0.1, 0.3, 0.78], [60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.8, -0.024, 14.125], [0.1, 0.3, 2], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.8, -0.287, 13.06], [0.1, 0.3, 0.78], [-60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.8, -0.287, 15.19], [0.1, 0.3, 0.78], [60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.1, -0.287, 14.25], [0.1, 0.4, 0.5], [-60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-1.1, -0.287, 14], [0.1, 0.4, 0.5], [60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.8, -0.287, 14.25], [0.1, 0.4, 0.5], [-60, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.8, -0.287, 14], [0.1, 0.4, 0.5], [60, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [-1.1, -0.55, 14.125], [0.1, 0.4, 3], [0, 0, 0], "darker gray", "choochoopart"],
    [true, "Cube", [-0.8, -0.55, 14.125], [0.1, 0.4, 3], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, -0.55, 12.725], [2.1, 0.4, 0.2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Cube", [0, -0.55, 15.525], [2.1, 0.4, 0.2], [0, 0, 0], "darker gray", "choochoopart"],
    [false, "Capsule", [1.23, -0.074, 14.125], [0.25, 0.25, 0.25], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.23, -0.074, 13.575], [0.04, 0.31, 0.04], [90, 0, 0], "light gray", "choochoopart"],
    [false, "Cylinder", [1.23, -0.074, 13.25], [0.06, 0.03, 0.06], [0, 0, 90], "light gray", "choochoopart"],
    [false, "Cube", [1.18, -0.3, 13.158], [0.05, 0.61, 0.12], [22.5, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.18, -0.55, 13.055], [0.18, 0.05, 0.18], [0, 0, 90], "dark gray", "choochoopart"],
    // runway and handles
    [false, "Cylinder", [-1.15, 2.551, 0.825], [0.04, 0.145, 0.04], [0, 0, 45], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.15, 2.551, 0.825], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.15, 2.551, 2.025], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.15, 2.551, 3.225], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.15, 2.551, 4.425], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.15, 2.551, 5.625], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.15, 2.551, 6.825], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.15, 2.551, 8.025], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.15, 2.551, 9.225], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.15, 2.551, 10.425], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.15, 2.551, 11.625], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [true, "Cylinder", [1.15, 2.551, 12.825], [0.04, 0.145, 0.04], [0, 0, -45], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.25, 2.65, 0.825], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 0.825], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 2.025], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 3.225], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 4.425], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 5.625], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 6.825], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 8.025], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 9.225], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 10.425], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 11.625], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.65, 12.825], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.25, 2.25, 0.42], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [-1.25, 2.25, 0.42], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.25, 2.65, 7.52], [0.04, 6.7, 0.04], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.25, 2.446, 0.624], [0.04, 0.297, 0.04], [45, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.25, 1.78, 0.42], [0.04, 0.47, 0.04], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [-1.25, 2.65, 7.52], [0.04, 6.7, 0.04], [90, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.25, 2.446, 0.624], [0.04, 0.297, 0.04], [45, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [-1.25, 1.78, 0.42], [0.04, 0.47, 0.04], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [-1.45, 1.3, 3.66], [0.5, 0.06, 6.6], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.45, 1.3, 3.66], [0.5, 0.06, 6.6], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cube", [1.5, 1.45, 10.6], [0.5, 0.06, 7.3], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.68, 1.33, 13.86], [0.1, 0.2, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.68, 1.33, 13.7], [0.1, 0.2, 0.01], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Cube", [1.68, 1.23, 13.78], [0.1, 0.01, 0.17], [0, 0, 0], "dark gray", "choochoopart"],
    // lamps below the runway
    [false, "Cylinder", [1.6, 1.4, 12.5], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.6, 1.32, 12.5], [0.095, 0.1, 0.095], [0, 0, 0], "yellow light", "choochoopart", 1.2, 3],
    [true, "Capsule", [1.6, 1.32, 12.5], [0.11, 0.11, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.6, 1.32, 12.5], [0.03, 0.11, 0.11], [0, 0, 0], "dark gray", "choochoopart" ],
    [true, "Sphere", [1.6, 1.33, 12.5], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.6, 1.28, 12.5], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.6, 1.4, 9.75], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.6, 1.32, 9.75], [0.095, 0.1, 0.095], [0, 0, 0], "yellow light", "choochoopart", 1.2, 3],
    [true, "Capsule", [1.6, 1.32, 9.75], [0.11, 0.11, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.6, 1.32, 9.75], [0.03, 0.11, 0.11], [0, 0, 0], "dark gray", "choochoopart" ],
    [true, "Sphere", [1.6, 1.33, 9.75], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.6, 1.28, 9.75], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.6, 1.25, 6.1], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.6, 1.17, 6.1], [0.095, 0.1, 0.095], [0, 0, 0], "yellow light", "choochoopart", 1.2, 3],
    [true, "Capsule", [1.6, 1.17, 6.1], [0.11, 0.11, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.6, 1.17, 6.1], [0.03, 0.11, 0.11], [0, 0, 0], "dark gray", "choochoopart" ],
    [true, "Sphere", [1.6, 1.18, 6.1], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.6, 1.13, 6.1], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.35, 1.25, 4.1], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.35, 1.17, 4.1], [0.095, 0.1, 0.095], [0, 0, 0], "yellow light", "choochoopart", 1.2, 3],
    [true, "Capsule", [1.35, 1.17, 4.1], [0.11, 0.11, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.35, 1.17, 4.1], [0.03, 0.11, 0.11], [0, 0, 0], "dark gray", "choochoopart" ],
    [true, "Sphere", [1.35, 1.18, 4.1], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.35, 1.13, 4.1], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.47, 1.25, 2.49], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.47, 1.17, 2.49], [0.095, 0.1, 0.095], [0, 0, 0], "yellow light", "choochoopart", 1.2, 3],
    [true, "Capsule", [1.47, 1.17, 2.49], [0.11, 0.11, 0.03], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.47, 1.17, 2.49], [0.03, 0.11, 0.11], [0, 0, 0], "dark gray", "choochoopart" ],
    [true, "Sphere", [1.47, 1.18, 2.49], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.47, 1.13, 2.49], [0.11, 0.03, 0.11], [0, 0, 0], "dark gray", "choochoopart"],
    [false, "Cylinder", [1.3, 0.55, 16.04], [0.11, 0.03, 0.11], [-90, 0, 0], "dark gray", "choochoopart"],
    [false, "Capsule", [1.3, 0.55, 16.12], [0.095, 0.1, 0.095], [-90, 0, 0], "yellow light", "choochoopart", 1.2, 3],
    [true, "Capsule", [1.3, 0.55, 16.12], [0.11, 0.11, 0.03], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [1.3, 0.55, 16.12], [0.03, 0.11, 0.11], [-90, 0, 0], "dark gray", "choochoopart" ],
    [true, "Sphere", [1.3, 0.55, 16.11], [0.11, 0.03, 0.11], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [1.3, 0.55, 16.16], [0.11, 0.03, 0.11], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Cylinder", [0, 3, 16.72], [0.11, 0.03, 0.11], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0, 3, 16.8], [0.095, 0.1, 0.095], [-90, 0, 0], "yellow light", "choochoopart", 1.2, 3],
    [true, "Capsule", [0, 3, 16.8], [0.11, 0.11, 0.03], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Capsule", [0, 3, 16.8], [0.03, 0.11, 0.11], [-90, 0, 0], "dark gray", "choochoopart" ],
    [true, "Sphere", [0, 3, 16.79], [0.11, 0.03, 0.11], [-90, 0, 0], "dark gray", "choochoopart"],
    [true, "Sphere", [0, 3, 16.84], [0.11, 0.03, 0.11], [-90, 0, 0], "dark gray", "choochoopart"],
    // tender
    [false, "Cube", [0, 0.55, 17.85], [3, 1, 0.5], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [0, -0.2, 17.85], [1.9, 0.5, 0.5], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [0, -0.25, 16.5], [0.4, 0.22, 2.3], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.6, -0.2, 17.8], [0.5, 0.29, 0.5], [90, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [0.6, 0, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [0.74, -0.06, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [0.8, -0.2, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [0.74, -0.34, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [0.6, -0.4, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [0.46, -0.34, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [0.4, -0.2, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [0.46, -0.06, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cylinder", [-0.6, -0.2, 17.8], [0.5, 0.29, 0.5], [90, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [-0.6, 0, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [-0.74, -0.06, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [-0.8, -0.2, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [-0.74, -0.34, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [-0.6, -0.4, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [-0.46, -0.34, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [-0.4, -0.2, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [-0.46, -0.06, 17.5], [0.05, 0.02, 0.05], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cylinder", [0, -0.2, 17.85], [0.35, 1.2, 0.35], [0, 0, 90], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.105, 17.755], [0.05, 0.02, 0.05], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.295, 17.755], [0.05, 0.02, 0.05], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.105, 17.945], [0.05, 0.02, 0.05], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.295, 17.945], [0.05, 0.02, 0.05], [0, 0, 90], "gray", "tenderpart"],
    [false, "Capsule", [1.25, -0.2, 17.85], [0.2, 0.2, 0.2], [0, 0, 90], "dark gray", "tenderpart"],
    [false, "Capsule", [1.349, -0.3, 17.85], [0.2, 0.2, 0.2], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Capsule", [1.349, -0.488, 17.799], [0.2, 0.2, 0.2], [30, 0, 0], "dark gray", "tenderpart"],
    [false, "Capsule", [1.349, -0.627, 17.66], [0.2, 0.2, 0.2], [60, 0, 0], "dark gray", "tenderpart"],
    [false, "Capsule", [1.349, -0.678, 17.47], [0.2, 0.2, 0.2], [90, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [1.149, -0.612, 16.9], [0.2, 0.515, 0.2], [97.3, 23, 0], "dark gray", "tenderpart"],
    [false, "Capsule", [0.95, -0.497, 16.34], [0.2, 0.2, 0.2], [-60, 0, 0], "dark gray", "tenderpart"],
    [false, "Capsule", [0.95, -0.358, 16.201], [0.2, 0.2, 0.2], [-30, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.95, -0.28, 16], [0.25, 0.15, 0.25], [90, 0, 0], "darker gray", "tenderpart"],
    [false, "Capsule", [0.95, -0.25, 15.9], [0.3, 0.16, 0.3], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.65, 0.25, 17.63], [0.1, 1.56, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.65, 0.25, 17.97], [0.1, 1.56, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.55, 0.98, 17.63], [0.1, 0.1, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.55, 0.98, 17.97], [0.1, 0.1, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.51, 0.98, 17.71], [0.02, 0.07, 0.15], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.51, 0.98, 17.89], [0.02, 0.07, 0.15], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.52, 0.98, 17.68], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.52, 0.98, 17.75], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.52, 0.98, 17.92], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.52, 0.98, 17.85], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.55, 0.12, 17.63], [0.1, 0.1, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.55, 0.12, 17.97], [0.1, 0.1, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.51, 0.12, 17.71], [0.02, 0.07, 0.15], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.51, 0.12, 17.89], [0.02, 0.07, 0.15], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.52, 0.12, 17.68], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.52, 0.12, 17.75], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.52, 0.12, 17.92], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.52, 0.12, 17.85], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.65, 0.84, 17.8], [0.1, 0.02, 0.32], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, 0.885, 17.65], [0.1, 0.07, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, 0.795, 17.95], [0.1, 0.07, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.65, 0.885, 17.64], [0.03, 0.03, 0.03], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.65, 0.795, 17.96], [0.03, 0.03, 0.03], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.65, 0.5, 17.8], [0.1, 0.02, 0.32], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, 0.545, 17.65], [0.1, 0.07, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, 0.455, 17.95], [0.1, 0.07, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.65, 0.545, 17.64], [0.03, 0.03, 0.03], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.65, 0.455, 17.96], [0.03, 0.03, 0.03], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.65, 0.16, 17.8], [0.1, 0.02, 0.32], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, 0.205, 17.65], [0.1, 0.07, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, 0.115, 17.95], [0.1, 0.07, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.65, 0.205, 17.64], [0.03, 0.03, 0.03], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.65, 0.115, 17.96], [0.03, 0.03, 0.03], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.65, -0.18, 17.8], [0.1, 0.02, 0.32], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, -0.135, 17.65], [0.1, 0.07, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, -0.225, 17.95], [0.1, 0.07, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.65, -0.135, 17.64], [0.03, 0.03, 0.03], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.65, -0.225, 17.96], [0.03, 0.03, 0.03], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.65, -0.52, 17.8], [0.1, 0.02, 0.32], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [0, 0.5, 19.2], [3.5, 0.9, 2.2], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [0, 1.8, 23.1], [3.5, 1.7, 10], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.329, 0.598, 24.2], [0.5, 0.978, 7.8], [0, 0, -23], "darker gray", "tenderpart"],
    [false, "Cube", [0, 0.5, 24.2], [2.736, 0.9, 7.8], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [-1.329, 0.598, 24.2], [0.5, 0.978, 7.8], [0, 0, 23], "darker gray", "tenderpart"],
    [false, "Cube", [1.6, 2.94, 21.2], [0.05, 0.651, 5.3], [0, 0, 23], "darker gray", "tenderpart"],
    [false, "Cube", [-1.6, 2.94, 21.2], [0.05, 0.651, 5.3], [0, 0, -23], "darker gray", "tenderpart"],
    [false, "Cube", [0, 2.94, 18.65], [3, 0.58, 0.05], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.48, 2.88, 18.65], [0.3, 0.651, 0.05], [0, 0, 23], "darker gray", "tenderpart"],
    [false, "Cube", [-1.48, 2.88, 18.65], [0.3, 0.651, 0.05], [0, 0, -23], "darker gray", "tenderpart"],
    [true, "Cube", [0, 2.94, 23], [3, 0.58, 0.05], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [1.48, 2.88, 23], [0.3, 0.651, 0.05], [0, 0, 23], "darker gray", "tenderpart"],
    [true, "Cube", [-1.48, 2.88, 23], [0.3, 0.651, 0.05], [0, 0, -23], "darker gray", "tenderpart"],
    [true, "Cube", [0, 2.8, 23.9], [0.8, 0.3, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [0.4, 2.8, 23.9], [0.5, 0.15, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [-0.4, 2.8, 23.9], [0.5, 0.15, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Capsule", [0, 2.95, 23.9], [0.1, 0.7, 0.6], [0, 0, 90], "dark gray", "tenderpart"],
    [true, "Cube", [0, 2.8, 25.3], [0.8, 0.3, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [0.4, 2.8, 25.3], [0.5, 0.15, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [-0.4, 2.8, 25.3], [0.5, 0.15, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Capsule", [0, 2.95, 25.3], [0.1, 0.7, 0.6], [0, 0, 90], "dark gray", "tenderpart"],
    [true, "Cube", [0, 2.8, 26.7], [0.8, 0.3, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [0.4, 2.8, 26.7], [0.5, 0.15, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [-0.4, 2.8, 26.7], [0.5, 0.15, 0.5], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Capsule", [0, 2.95, 26.7], [0.1, 0.7, 0.6], [0, 0, 90], "dark gray", "tenderpart"],
    [false, "Sphere", [0, 2.9, 28.35], [0.34, 0.34, 0.03], [0, 0, 0], "yellow light", "tenderpart", 2, 3],
    [false, "Cylinder", [0, 2.9, 28.1], [0.4, 0.25, 0.4], [90, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [0, 2.675, 28.05], [0.5, 0.06, 0.09], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [0, 3.125, 28.05], [0.5, 0.06, 0.09], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [0.22, 2.88, 27.82], [0.06, 0.65, 0.06], [40, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [-0.22, 2.88, 27.82], [0.06, 0.65, 0.06], [40, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.205, 3.1, 28.05], [0.04, 0.422, 0.04], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [0.205, 3.5, 28.05], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [0.955, 3.11, 28.05], [0.04, 0.842, 0.04], [0, 0, 62], "dark gray", "tenderpart"],
    [false, "Capsule", [1.705, 2.675, 28.05], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [-0.205, 3.1, 28.05], [0.04, 0.422, 0.04], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [-0.205, 3.5, 28.05], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [-0.955, 3.11, 28.05], [0.04, 0.842, 0.04], [0, 0, -62], "dark gray", "tenderpart"],
    [false, "Capsule", [-1.705, 2.675, 28.05], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.6, 2.75, 24.2], [0.06, 0.1, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.6, 2.75, 24.8], [0.06, 0.1, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.6, 2.75, 25.4], [0.06, 0.1, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.6, 2.75, 26], [0.06, 0.1, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.6, 2.75, 26.6], [0.06, 0.1, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.6, 2.75, 27.2], [0.06, 0.1, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.6, 2.88, 24.2], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.6, 2.88, 24.8], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.6, 2.88, 25.4], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.6, 2.88, 26], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.6, 2.88, 26.6], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.6, 2.88, 27.2], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.6, 2.88, 25.4], [0.06, 1.8, 0.06], [90, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.8, 1, 27.5], [0.1, 3.2, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.84, 1, 27.535], [0.02, 3.2, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.84, 1, 27.965], [0.02, 3.2, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.8, 1, 28.0], [0.1, 3.2, 0.02], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.79, -0.59, 27.75], [0.08, 0.02, 0.48], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.86, -0.2, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 0.1, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 0.4, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 0.7, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.0, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.3, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.6, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.9, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 2.2, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 2.5, 27.53], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, -0.2, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cylinder", [1.86, 0.1, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 0.4, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cylinder", [1.86, 0.7, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.0, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cylinder", [1.86, 1.3, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.6, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cylinder", [1.86, 1.9, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 2.2, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [false, "Cylinder", [1.86, 2.5, 27.75], [0.04, 0.21, 0.04], [90, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, -0.2, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 0.1, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 0.4, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 0.7, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.0, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.3, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.6, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 1.9, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 2.2, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.86, 2.5, 27.97], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    // husky
    [false, "Cube", [-0.094, 0.936, 28.1], [0.02, 0.3, 0.01], [0, 0, -37.5], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [0.126, 0.998, 28.1], [0.02, 0.3, 0.01], [0, 0, 69], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [0.343, 0.995, 28.1], [0.02, 0.2, 0.01], [0, 0, -59], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [0.326, 1.143, 28.1], [0.02, 0.3, 0.01], [0, 0, 49.5], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [0.194, 1.308, 28.1], [0.02, 0.15, 0.01], [0, 0, 16], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [0.119, 1.424, 28.1], [0.02, 0.15, 0.01], [0, 0, 49.5], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [0.102, 1.582, 28.1], [0.02, 0.25, 0.01], [0, 0, -17], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [0.015, 1.606, 28.1], [0.02, 0.3, 0.01], [0, 0, -53], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [0.02, 1.648, 28.1], [0.02, 0.1, 0.01], [0, 0, -17], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [-0.089, 1.6, 28.1], [0.02, 0.3, 0.01], [0, 0, -53], "white", "tenderpart", 0.6, 0],
    [false, "Cube", [-0.357, 1.376, 28.1], [0.02, 0.402, 0.01], [0, 0, -48], "white", "tenderpart", 0.6, 0],
    // tender wheels
    [false, "Cylinder", [0, -0.52, 18.75], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "tenderpart"],
    [false, "Cylinder", [0, -0.52, 20.4], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "tenderpart"],
    [false, "Cylinder", [0, -0.52, 21.7], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "tenderpart"],
    [false, "Cylinder", [0, -0.52, 23], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "tenderpart"],
    [false, "Cylinder", [0, -0.52, 24.3], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "tenderpart"],
    [false, "Cylinder", [0, -0.52, 25.6], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "tenderpart"],
    [false, "Cylinder", [0, -0.52, 26.9], [0.3, 1.2, 0.3], [0, 0, 90], "light gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 18.705], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 18.795], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 18.645], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 18.645], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 18.855], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 18.855], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 18.705], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 18.795], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 20.355], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 20.445], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 20.295], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 20.295], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 20.505], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 20.505], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 20.355], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 20.445], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 21.655], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 21.745], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 21.595], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 21.595], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 21.805], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 21.805], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 21.655], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 21.745], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 22.955], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 23.045], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 22.895], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 22.895], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 23.105], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 23.105], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 22.955], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 23.045], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 24.255], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 24.345], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 24.195], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 24.195], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 24.405], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 24.405], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 24.255], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 24.345], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 25.555], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 25.645], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 25.495], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 25.495], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 25.705], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 25.705], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 25.555], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 25.645], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 26.855], [0.03, 0.015, 0.03], [9, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.415, 26.945], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 26.795], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 26.795], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.475, 27.005], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.565, 27.005], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 26.855], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.21, -0.625, 26.945], [0.03, 0.015, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.1, -0.13, 19.575], [0.1, 0.2, 2], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.52, 19.575], [0.1, 0.4, 2.4], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.146, 18.567], [0.1, 0.2, 0.65], [-48, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.146, 18.933], [0.1, 0.2, 0.65], [48, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.146, 20.217], [0.1, 0.2, 0.65], [-48, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.146, 20.583], [0.1, 0.2, 0.65], [48, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [-1.1, -0.13, 19.575], [0.1, 0.2, 2], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [-1.1, -0.52, 19.575], [0.1, 0.4, 2.4], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [-1.1, -0.247, 18.495], [0.1, 0.2, 0.418], [-44, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [-1.1, -0.247, 20.655], [0.1, 0.2, 0.418], [44, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [-1.1, -0.247, 19.005], [0.1, 0.2, 0.418], [44, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [-1.1, -0.247, 20.145], [0.1, 0.2, 0.418], [-44, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [0, -0.395, 18.325], [2.3, 0.15, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [0, -0.395, 20.825], [2.3, 0.15, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Capsule", [1.23, -0.446, 19.575], [0.25, 0.25, 0.25], [90, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.23, -0.446, 19.275], [0.035, 0.15, 0.035], [90, 0, 0], "light gray", "tenderpart"],
    [true, "Cube", [1.23, -0.446, 19.875], [0.05, 0.1, 0.3], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.23, -0.457, 19.15], [0.05, 0.52, 0.1], [-15, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.23, -0.457, 20], [0.05, 0.52, 0.1], [15, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.23, -0.21, 19.12], [0.1, 0.1, 0.2], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.23, -0.21, 20.03], [0.1, 0.1, 0.2], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.23, -0.21, 19.575], [0.03, 0.4, 0.03], [90, 0, 0], "light gray", "tenderpart"],
    [true, "Cylinder", [1.22, -0.7, 18.97], [0.03, 0.22, 0.03], [90, 0, 0], "light gray", "tenderpart"],
    [true, "Cylinder", [1.22, -0.7, 20.18], [0.03, 0.22, 0.03], [90, 0, 0], "light gray", "tenderpart"],
    [true, "Capsule", [1.189, -0.7, 18.75], [0.04, 0.046, 0.04], [0, 0, 90], "light gray", "tenderpart"],
    [true, "Capsule", [1.189, -0.7, 20.4], [0.04, 0.046, 0.04], [0, 0, 90], "light gray", "tenderpart"],
    [true, "Cylinder", [1.17, -0.64, 19.1], [0.03, 0.35, 0.03], [90, 0, 0], "light gray", "tenderpart"],
    [true, "Cylinder", [1.17, -0.64, 20.05], [0.03, 0.35, 0.03], [90, 0, 0], "light gray", "tenderpart"],
    [true, "Cube", [1.17, -0.58, 19.475], [0.05, 0.15, 0.07], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.17, -0.58, 19.675], [0.05, 0.15, 0.07], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.1, -0.52, 24.3], [0.1, 0.3, 5.8], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.06, 21.05], [0.1, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.06, 22.35], [0.1, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.06, 23.65], [0.1, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.06, 24.95], [0.1, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.06, 26.25], [0.1, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [0, -0.06, 27.65], [2.3, 0.3, 0.45], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 21.238], [0.1, 0.661, 0.217], [-45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 22.538], [0.1, 0.661, 0.217], [-45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 23.838], [0.1, 0.661, 0.217], [-45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 25.138], [0.1, 0.661, 0.217], [-45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 26.438], [0.1, 0.661, 0.217], [-45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 22.162], [0.1, 0.661, 0.217], [45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 23.462], [0.1, 0.661, 0.217], [45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 24.762], [0.1, 0.661, 0.217], [45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 26.062], [0.1, 0.661, 0.217], [45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.1, -0.362, 27.362], [0.1, 0.661, 0.217], [45.9, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [-1.1, -0.362, 27.362], [0.1, 0.661, 0.217], [45.9, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 21.35], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 21.35], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 21.42], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 21.48], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 21.45], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [1.025, -0.09, 21.7], [0.05, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 21.95], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 21.92], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 21.98], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 22.05], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 22.05], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 21.717], [0.04, 0.66, 0.09], [70, 0, 0], "gray", "tenderpart"],
    [true, "Cube", [1.025, -0.028, 21.7], [0.04, 0.08, 0.6], [0, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 21.683], [0.04, 0.66, 0.09], [-70, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 22.65], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 22.65], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 22.72], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 22.78], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 22.75], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [1.025, -0.09, 23], [0.05, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 23.25], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 23.22], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 23.28], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 23.35], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 23.35], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 23.017], [0.04, 0.66, 0.09], [70, 0, 0], "gray", "tenderpart"],
    [true, "Cube", [1.025, -0.028, 23], [0.04, 0.08, 0.6], [0, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 22.983], [0.04, 0.66, 0.09], [-70, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 23.95], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 23.95], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 24.02], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 24.08], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 24.05], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [1.025, -0.09, 24.3], [0.05, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 24.55], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 24.52], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 24.58], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 24.65], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 24.65], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 24.317], [0.04, 0.66, 0.09], [70, 0, 0], "gray", "tenderpart"],
    [true, "Cube", [1.025, -0.028, 24.3], [0.04, 0.08, 0.6], [0, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 24.283], [0.04, 0.66, 0.09], [-70, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 25.25], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 25.25], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 25.32], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 25.38], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 25.35], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [1.025, -0.09, 25.6], [0.05, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 25.85], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 25.82], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 25.88], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 25.95], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 25.95], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 25.617], [0.04, 0.66, 0.09], [70, 0, 0], "gray", "tenderpart"],
    [true, "Cube", [1.025, -0.028, 25.6], [0.04, 0.08, 0.6], [0, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 25.583], [0.04, 0.66, 0.09], [-70, 0, 0], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 26.55], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 26.55], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 26.62], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 26.68], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 26.65], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cube", [1.025, -0.09, 26.9], [0.05, 0.3, 0.25], [0, 0, 0], "darker gray", "tenderpart"],
    [false, "Cube", [1.025, -0.32, 27.15], [0.05, 0.22, 0.12], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 27.12], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.24, 27.18], [0.03, 0.02, 0.03], [0, 0, 90], "gray", "tenderpart"],
    [true, "Cube", [1.025, 0, 27.25], [0.05, 0.2, 0.1], [0, 0, 0], "darker gray", "tenderpart"],
    [true, "Cylinder", [1.05, -0.05, 27.25], [0.06, 0.02, 0.06], [0, 0, 90], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 26.917], [0.04, 0.66, 0.09], [70, 0, 0], "gray", "tenderpart"],
    [true, "Cube", [1.025, -0.028, 26.9], [0.04, 0.08, 0.6], [0, 0, 0], "gray", "tenderpart"],
    [false, "Cube", [1.025, -0.14, 26.883], [0.04, 0.66, 0.09], [-70, 0, 0], "gray", "tenderpart"],
    [false, "Cylinder", [1.49, 0.2, 24], [0.1, 3.8, 0.1], [-90, 0, 0], "dark gray", "tenderpart"],
    [false, "Capsule", [1.49, 0.175, 27.845], [0.1, 0.1, 0.1], [-60, 0, 0], "dark gray", "tenderpart"],
    [false, "Capsule", [1.49, 0.106, 27.914], [0.1, 0.1, 0.1], [-30, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [1.49, -0.04, 27.939], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Capsule", [1.465, -0.185, 27.939], [0.1, 0.1, 0.1], [0, 0, -30], "dark gray", "tenderpart"],
    [false, "Capsule", [1.396, -0.254, 27.939], [0.1, 0.1, 0.1], [0, 0, -60], "dark gray", "tenderpart"],
    [false, "Cylinder", [1.3, -0.279, 27.939], [0.1, 0.05, 0.1], [0, 0, -90], "dark gray", "tenderpart"],
    [false, "Capsule", [1.204, -0.254, 27.939], [0.1, 0.1, 0.1], [0, 0, 60], "dark gray", "tenderpart"],
    [false, "Capsule", [1.135, -0.185, 27.939], [0.1, 0.1, 0.1], [0, 0, 30], "dark gray", "tenderpart"],
    [false, "Cylinder", [1.11, -0.04, 27.939], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [false, "Cylinder", [1.49, 0.2, 20.6], [0.14, 0.03, 0.14], [-90, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.44, 0.25, 20.6], [0.138, 0.138, 0.06], [0, 0, 45], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.49, 0.2, 21.8], [0.14, 0.03, 0.14], [-90, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.44, 0.25, 21.8], [0.138, 0.138, 0.06], [0, 0, 45], "dark gray", "tenderpart"],
    [false, "Cylinder", [1.49, 0.2, 22.9], [0.14, 0.03, 0.14], [-90, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.44, 0.25, 22.9], [0.138, 0.138, 0.06], [0, 0, 45], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.49, 0.2, 24], [0.14, 0.03, 0.14], [-90, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.44, 0.25, 24], [0.138, 0.138, 0.06], [0, 0, 45], "dark gray", "tenderpart"],
    [false, "Cylinder", [1.49, 0.2, 25.1], [0.14, 0.03, 0.14], [-90, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.44, 0.25, 25.1], [0.138, 0.138, 0.06], [0, 0, 45], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.49, 0.2, 26.2], [0.14, 0.03, 0.14], [-90, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.44, 0.25, 26.2], [0.138, 0.138, 0.06], [0, 0, 45], "dark gray", "tenderpart"],
    [false, "Cylinder", [1.49, 0.2, 27.3], [0.14, 0.03, 0.14], [-90, 0, 0], "dark gray", "tenderpart"],
    [false, "Cube", [1.44, 0.25, 27.3], [0.138, 0.138, 0.06], [0, 0, 45], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.65, 0.2, 20.4], [0.1, 0.3, 0.1], [-90, 0, 0], "dark gray", "tenderpart"],
    [true, "Capsule", [1.65, 0.175, 20.745], [0.1, 0.1, 0.1], [-60, 0, 0], "dark gray", "tenderpart"],
    [true, "Capsule", [1.65, 0.106, 20.814], [0.1, 0.1, 0.1], [-30, 0, 0], "dark gray", "tenderpart"],
    [true, "Capsule", [1.65, 0.012, 20.839], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Capsule", [1.625, -0.085, 20.839], [0.1, 0.1, 0.1], [0, 0, -30], "dark gray", "tenderpart"],
    [true, "Capsule", [1.556, -0.154, 20.839], [0.1, 0.1, 0.1], [0, 0, -60], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.31, -0.179, 20.839], [0.1, 0.2, 0.1], [0, 0, -90], "dark gray", "tenderpart"],
    [true, "Capsule", [1.064, -0.154, 20.839], [0.1, 0.1, 0.1], [0, 0, 60], "dark gray", "tenderpart"],
    [true, "Capsule", [0.995, -0.085, 20.839], [0.1, 0.1, 0.1], [0, 0, 30], "dark gray", "tenderpart"],
    [true, "Cylinder", [0.97, 0.06, 20.839], [0.1, 0.1, 0.1], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.65, 0.2, 20.6], [0.14, 0.03, 0.14], [-90, 0, 0], "dark gray", "tenderpart"],
    [true, "Cube", [1.57, 0.2, 20.6], [0.16, 0.14, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.8, 1.33, 18], [0.04, 1.34, 0.04], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.8, -0.01, 18], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.7, -0.01, 18], [0.04, 0.09, 0.04], [0, 0, 90], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.65, -0.01, 18], [0.08, 0.05, 0.08], [0, 0, 90], "dark gray", "tenderpart"],
    [true, "Cube", [1.65, -0.01, 17.992], [0.1, 0.2, 0.024], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.8, 2.67, 18], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.75, 2.67, 18.085], [0.04, 0.08, 0.04], [0, 60, 90], "dark gray", "tenderpart"],
    [true, "Cube", [1.685, 2.662, 18.2], [0.08, 0.024, 0.12], [0, -30, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.8, 0.7, 28.15], [0.04, 0.8, 0.04], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.8, -0.1, 28.15], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.8, -0.1, 28.07], [0.04, 0.07, 0.04], [90, 0, 0], "dark gray", "tenderpart"],
    [true, "Sphere", [1.8, 1.5, 28.15], [0.06, 0.06, 0.06], [0, 0, 0], "dark gray", "tenderpart"],
    [true, "Cylinder", [1.8, 1.5, 28.07], [0.04, 0.07, 0.04], [90, 0, 0], "dark gray", "tenderpart"],
]


/* calculate positioning for the closing parts on the engine front
let s = 180/14
for(let i = s/2; i < 180; i+=s) {
    let r = 2.95 - 1.9
    let a = (i - 90) * Math.PI / 180;
    let x = r * Math.cos(a)
    let y = -r * Math.sin(a)
    console.log(i, x, y + 1.9)
}
*/

materials["red"] = {"color": [1, 0, 0], "shader": "Standard"}
materials["gray"] = {"color": [0.65, 0.65, 0.65], "shader": "Standard"}
materials["dark gray"] = {"color": [0.5, 0.5, 0.5], "shader": "Standard"}
materials["darker gray"] = {"color": [0.3, 0.3, 0.3], "shader": "Standard"}
materials["light gray"] = {"color": [0.8, 0.8, 0.8], "shader": "Standard"}
materials["bronze"] = {"color": [0.81, 0.69, 0.39], "shader": "Standard"}
materials["white"] = {"color": [1, 1, 1], "shader": "OpaqueLight"}
materials["yellow light"] = {"color": [1, 0.9, 0.3], "shader": "OpaqueLight"}

//let train_light_id = 0
for (let i = 0; i < train_parts.length; i++) {
    let element = {
        "geometry": {"type": train_parts[i][1], "material": train_parts[i][5]},
        "position": train_parts[i][2],
        "scale": train_parts[i][3],
        "rotation": train_parts[i][4],
        "track": train_parts[i][6],
    }
    if (train_parts[i].length > 7) {
        element["components"] = {
            "ILightWithId": {"type": 0/*, "lightID": 700 + train_light_id*/},
            "TubeBloomPrePassLight": {
                "colorAlphaMultiplier": train_parts[i][7],
                "bloomFogIntensityMultiplier": train_parts[i][8]
            }
        }
        //train_light_id += 1
    }
    if (train_parts[i][0]) {
        environment_hd.push(element)
    } else {
        environment.push(element)
    }
}
//console.log(700 + train_light_id - 1)

// parent tracks for animating the train parts
const train_parents = [{
// 1st wheel set
    "childrenTracks": ["counter crank arm"],
    "parentTrack": "counter crank arm parent",
}, {
    "childrenTracks": ["counter crank arm parent"],
    "parentTrack": "counter crank arm parent 2",
}, {
    "childrenTracks": ["coupling rods", "counter crank"],
    "parentTrack": "coupling parent 1",
}, {
    "childrenTracks": ["coupling parent 1"],
    "parentTrack": "coupling parent 2",
}, {
    "childrenTracks": ["handlebar"],
    "parentTrack": "handlebar parent",
}, {
    "childrenTracks": ["handlelever"],
    "parentTrack": "handlelever parent",
}, {
    "childrenTracks": ["handlecross"],
    "parentTrack": "handlecross parent",
}, {
    "childrenTracks": ["swingarm"],
    "parentTrack": "swingarm parent",
}, {
    "childrenTracks": ["swingarm rod"],
    "parentTrack": "swingarm rod parent",
}, {
    "childrenTracks": ["swingarm rod parent"],
    "parentTrack": "swingarm rod parent 2",
}, {
    "childrenTracks": ["hanging iron"],
    "parentTrack": "hanging iron parent",
}, {
    "childrenTracks": ["slider rod", "hanging iron parent", "hanging iron cross"],
    "parentTrack": "slider rod parent",
}, {
    "childrenTracks": ["lower pump rod", "handlebar parent", "handlecross parent", "handlelever parent"],
    "parentTrack": "pump1-1",
}, {
    "childrenTracks": ["upper pump rod"],
    "parentTrack": "pump1-2",
}, {
    "childrenTracks": ["main rod"],
    "parentTrack": "main rod parent 1",
}, {
    "childrenTracks": ["main rod parent 1"],
    "parentTrack": "main rod parent 2",
}, {
// 2nd wheel set
    "childrenTracks": ["counter crank 2 arm"],
    "parentTrack": "counter crank 2 arm parent",
}, {
    "childrenTracks": ["counter crank 2 arm parent"],
    "parentTrack": "counter crank 2 arm parent 2",
}, {
    "childrenTracks": ["coupling rods 2", "counter crank 2"],
    "parentTrack": "coupling 2 parent 1",
}, {
    "childrenTracks": ["coupling 2 parent 1"],
    "parentTrack": "coupling 2 parent 2",
}, {
    "childrenTracks": ["handlebar 2"],
    "parentTrack": "handlebar 2 parent",
}, {
    "childrenTracks": ["handlelever 2"],
    "parentTrack": "handlelever 2 parent",
}, {
    "childrenTracks": ["handlecross 2"],
    "parentTrack": "handlecross 2 parent",
}, {
    "childrenTracks": ["swingarm 2"],
    "parentTrack": "swingarm 2 parent",
}, {
    "childrenTracks": ["swingarm 2 rod"],
    "parentTrack": "swingarm 2 rod parent",
}, {
    "childrenTracks": ["swingarm 2 rod parent"],
    "parentTrack": "swingarm 2 rod parent 2",
}, {
    "childrenTracks": ["hanging iron 2"],
    "parentTrack": "hanging iron 2 parent",
}, {
    "childrenTracks": ["slider 2 rod", "hanging iron 2 parent", "hanging iron 2 cross"],
    "parentTrack": "slider 2 rod parent",
}, {
    "childrenTracks": ["lower pump 2 rod", "handlebar 2 parent", "handlecross 2 parent", "handlelever 2 parent"],
    "parentTrack": "pump2-1",
}, {
    "childrenTracks": ["upper pump 2 rod"],
    "parentTrack": "pump2-2",
}, {
    "childrenTracks": ["main 2 rod"],
    "parentTrack": "main 2 rod parent 1",
}, {
    "childrenTracks": ["main 2 rod parent 1"],
    "parentTrack": "main 2 rod parent 2",
}]

for (let i = 0; i < train_parents.length; i++) {
    customEvents.push({
        "b": 0,
        "t": "AssignTrackParent",
        "d": train_parents[i],
    })
}

customEvents.push({
    "b": 0,
    "t": "AssignTrackParent",
    "d": {
        "childrenTracks": ["tenderpart"],
        "parentTrack": "tender",
    }
}, {
    "b": 0,
    "t": "AssignTrackParent",
    "d": {
        "childrenTracks": [
            "choochoopart",
            "coupling parent 2",
            "coupling 2 parent 2",
            "pump1-1",
            "pump1-2",
            "pump2-1",
            "pump2-2",
            "main rod parent 2",
            "main 2 rod parent 2",
            "swingarm parent",
            "swingarm 2 parent",
            "slider rod parent",
            "slider 2 rod parent",
            "swingarm rod parent 2",
            "swingarm 2 rod parent 2",
            "counter crank arm parent 2",
            "counter crank 2 arm parent 2",
            "tender",
        ],
        "parentTrack": "choochoo",
    }
}, {
    "b": 0,
    "t": "AssignTrackParent",
    "d": {
        "childrenTracks": ["choochoo"],
        "parentTrack": "choochoo_parent",
    }
}, {
    "b": 0,
    "t": "AssignTrackParent",
    "d": {
        "childrenTracks": ["choochoo_parent"],
        "parentTrack": "choochoo_grandparent",
    }
}, {
    "b": 0,
    "t": "AssignTrackParent",
    "d": {
        "childrenTracks": ["choochoo_grandparent"],
        "parentTrack": "choochoo_greatgrandparent",
    }
})

// point definitions for the train animations
// 1st wheel set
pointDefinitions["pump1-1 position"] = [
    [0, 0, 0, 0],
    [0, 0, -0.8, 0.5, "easeInOutSine"],
    [0, 0, 0, 1, "easeInOutSine"],
]
pointDefinitions["pump1-2 position"] = [
    [0, 0, 0, 0],
    [0, 0, -0.3, 0.5, "easeInOutSine"],
    [0, 0, 0, 1, "easeInOutSine"],
]
pointDefinitions["coupling parent 1 position"] = [
    [0, 0, 0, 0],
    [0, 0, -0.8, 0.5, "easeInOutSine"],
    [0, 0, 0, 1, "easeInOutSine"],
]
pointDefinitions["coupling parent 2 position"] = [
    [0, 0, 0, 0],
    [0, 0.4, 0, 0.25, "easeOutSine"],
    [0, 0, 0, 0.5, "easeInSine"],
    [0, -0.4, 0, 0.75, "easeOutSine"],
    [0, 0, 0, 1, "easeInSine"],
]
pointDefinitions["main rod parent 1 position"] = [
    [0, 0, 0, 0],
    [0, 0, -0.4, 0.25, "easeInSine"],
    [0, 0, -0.8, 0.5, "easeOutSine"],
    [0, 0, -0.4, 0.75, "easeInSine"],
    [0, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["main rod parent 1 rotation"] = [
    [0, 0, 0, 0],
    [-10, 0, 0, 0.25, "easeOutSine"],
    [0, 0, 0, 0.5, "easeInSine"],
    [10, 0, 0, 0.75, "easeOutSine"],
    [0, 0, 0, 1, "easeInSine"],
]
pointDefinitions["main rod parent 2 position"] = [
    [0, 0, 0, 0],
    [0, 0.19, 0, 0.25, "easeOutSine"],
    [0, 0, 0, 0.5, "easeInSine"],
    [0, -0.19, 0, 0.75, "easeOutSine"],
    [0, 0, 0, 1, "easeInSine"],
]
pointDefinitions["handlebar rotation"] = [
    [7.5, 0, 0, 0],
    [-2.5, 0, 0, 0.25, "easeInSine"],
    [7.5, 0, 0, 0.5, "easeOutSine"],
    [-2.5, 0, 0, 0.75, "easeInSine"],
    [7.5, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["handlebar position"] = [
    [0, 0.027, 0, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [0, 0.027, 0, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [0, 0.027, 0, 1, "easeOutSine"],
]
pointDefinitions["handlecross position"] = [
    [0, 0.056, 0, 0],
    [0, -0.01, 0, 0.25, "easeInSine"],
    [0, 0.056, 0, 0.5, "easeOutSine"],
    [0, -0.01, 0, 0.75, "easeInSine"],
    [0, 0.056, 0, 1, "easeOutSine"],
]
pointDefinitions["handlelever rotation"] = [
    [-27, 0, 0, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [27, 0, 0, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [-27, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["handlelever position"] = [
    [0, 0, -0.15, 0],
    [0, 0, 0, 0.25, "easeInQuad"],
    [0, 0, 0.15, 0.5, "easeOutQuad"],
    [0, 0, 0, 0.75, "easeInQuad"],
    [0, 0, -0.15, 1, "easeOutQuad"],
]
pointDefinitions["swingarm rotation"] = [
    [30, 0, 0, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [-30, 0, 0, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [30, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["swingarm position"] = [[0, 0.47, 3.05, 0],[0, 0.47, 3.05, 1]]
pointDefinitions["slider rod position"] = [
    [0, 0, -0.075, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [0, 0, 0.075, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [0, 0, -0.075, 1, "easeOutSine"],
]
pointDefinitions["hanging iron position"] = [
    [0, 0, 0.0375, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [0, 0, -0.0375, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [0, 0, 0.0375, 1, "easeOutSine"],
]
pointDefinitions["hanging iron rotation"] = [
    [15, 0, 0, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [-15, 0, 0, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [15, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["swingarm rod parent position"] = [
    [0, 0, 0, 0],
    [0, 0, 0.15, 0.25, "easeInSine"],
    [0, 0, 0.31, 0.5, "easeOutSine"],
    [0, 0, 0.16, 0.75, "easeInSine"],
    [0, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["swingarm rod parent 2 position"] = [
    [0, 0, 0, 0],
    [0, -0.07, 0, 0.25, "easeOutSine"],
    [0, 0.07, 0, 0.5],
    [0, 0.085, 0, 0.75, "easeOutExpo"],
    [0, 0, 0, 1],
]
pointDefinitions["swingarm rod rotation"] = [
    [13.9, 0, 0, 0],
    [21.9, 0, 0, 0.25],
    [19.9, 0, 0, 0.5, "easeInBack"],
    [7.9, 0, 0, 0.75],
    [13.9, 0, 0, 1, "easeInQuad"],
]
pointDefinitions["counter crank rotation"] = [
    [0, 0, 0, 0],
    [-90, 0, 0, 0.25],
    [-180, 0, 0, 0.5],
    [-270, 0, 0, 0.75],
    [-360, 0, 0, 1],
]
pointDefinitions["counter crank arm position"] = [
    [0, -0.23, 4.45, 0],
    [0, -0.23, 4.35, 0.5, "easeInOutSine"],
    [0, -0.23, 4.45, 1, "easeInOutSine"],
]
pointDefinitions["counter crank arm rotation"] = [
    [0, 0, 0, 0],
    [-90, 0, 0, 0.25],
    [-180, 0, 0, 0.5],
    [-270, 0, 0, 0.75],
    [-360, 0, 0, 1],
]
pointDefinitions["counter crank arm position 2"] = [
    [0, 0, 0, 0],
    [0, 0.05, 0, 0.25, "easeOutSine"],
    [0, 0, 0, 0.5, "easeInSine"],
    [0, -0.05, 0, 0.75, "easeOutSine"],
    [0, 0, 0, 1, "easeInSine"],
]
// 2nd wheel set
pointDefinitions["pump2-1 position"] = [
    [0, 0, -0.8, 0],
    [0, 0, 0, 0.5, "easeInOutSine"],
    [0, 0, -0.8, 1, "easeInOutSine"],
]
pointDefinitions["pump2-2 position"] = [
    [0, 0, -0.3, 0],
    [0, 0, 0, 0.5, "easeInOutSine"],
    [0, 0, -0.3, 1, "easeInOutSine"],
]
pointDefinitions["coupling 2 parent 1 position"] = [
    [0, 0, -0.8, 0],
    [0, 0, 0, 0.5, "easeInOutSine"],
    [0, 0, -0.8, 1, "easeInOutSine"],
]
pointDefinitions["coupling 2 parent 2 position"] = [
    [0, 0, 0, 0],
    [0, -0.4, 0, 0.25, "easeOutSine"],
    [0, 0, 0, 0.5, "easeInSine"],
    [0, 0.4, 0, 0.75, "easeOutSine"],
    [0, 0, 0, 1, "easeInSine"],
]
pointDefinitions["main 2 rod parent 1 position"] = [
    [0, 0, -0.8, 0],
    [0, 0, -0.4, 0.25, "easeInSine"],
    [0, 0, 0, 0.5, "easeOutSine"],
    [0, 0, -0.4, 0.75, "easeInSine"],
    [0, 0, -0.8, 1, "easeOutSine"],
]
pointDefinitions["main 2 rod parent 1 rotation"] = [
    [0, 0, 0, 0],
    [10, 0, 0, 0.25, "easeOutSine"],
    [0, 0, 0, 0.5, "easeInSine"],
    [-10, 0, 0, 0.75, "easeOutSine"],
    [0, 0, 0, 1, "easeInSine"],
]
pointDefinitions["main 2 rod parent 2 position"] = [
    [0, 0, 0, 0],
    [0, -0.19, 0, 0.25, "easeOutSine"],
    [0, 0, 0, 0.5, "easeInSine"],
    [0, 0.19, 0, 0.75, "easeOutSine"],
    [0, 0, 0, 1, "easeInSine"],
]
pointDefinitions["handlebar 2 rotation"] = [
    [7.5, 0, 0, 0],
    [-2.5, 0, 0, 0.25, "easeInSine"],
    [7.5, 0, 0, 0.5, "easeOutSine"],
    [-2.5, 0, 0, 0.75, "easeInSine"],
    [7.5, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["handlebar 2 position"] = [
    [0, 0.027, 0, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [0, 0.027, 0, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [0, 0.027, 0, 1, "easeOutSine"],
]
pointDefinitions["handlecross 2 position"] = [
    [0, 0.056, 0, 0],
    [0, -0.01, 0, 0.25, "easeInSine"],
    [0, 0.056, 0, 0.5, "easeOutSine"],
    [0, -0.01, 0, 0.75, "easeInSine"],
    [0, 0.056, 0, 1, "easeOutSine"],
]
pointDefinitions["handlelever 2 rotation"] = [
    [27, 0, 0, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [-27, 0, 0, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [27, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["handlelever 2 position"] = [
    [0, 0, 0.15, 0],
    [0, 0, 0, 0.25, "easeInQuad"],
    [0, 0, -0.15, 0.5, "easeOutQuad"],
    [0, 0, 0, 0.75, "easeInQuad"],
    [0, 0, 0.15, 1, "easeOutQuad"],
]
pointDefinitions["swingarm 2 rotation"] = [
    [-30, 0, 0, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [30, 0, 0, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [-30, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["swingarm 2 position"] = [[0, 0.47, 9.25, 0],[0, 0.47, 9.25, 1]]
pointDefinitions["slider 2 rod position"] = [
    [0, 0, 0.075, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [0, 0, -0.075, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [0, 0, 0.075, 1, "easeOutSine"],
]
pointDefinitions["hanging iron 2 position"] = [
    [0, 0, -0.0375, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [0, 0, 0.0375, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [0, 0, -0.0375, 1, "easeOutSine"],
]
pointDefinitions["hanging iron 2 rotation"] = [
    [-15, 0, 0, 0],
    [0, 0, 0, 0.25, "easeInSine"],
    [15, 0, 0, 0.5, "easeOutSine"],
    [0, 0, 0, 0.75, "easeInSine"],
    [-15, 0, 0, 1, "easeOutSine"],
]
pointDefinitions["swingarm 2 rod parent position"] = [
    [0, 0, 0.31, 0],
    [0, 0, 0.16, 0.25, "easeInSine"],
    [0, 0, 0, 0.5, "easeOutSine"],
    [0, 0, 0.15, 0.75, "easeInSine"],
    [0, 0, 0.31, 1, "easeOutSine"],
]
pointDefinitions["swingarm 2 rod parent 2 position"] = [
    [0, 0.07, 0, 0],
    [0, 0.085, 0, 0.25, "easeOutExpo"],
    [0, 0, 0, 0.5],
    [0, -0.07, 0, 0.75, "easeOutSine"],
    [0, 0.07, 0, 1],
]
pointDefinitions["swingarm 2 rod rotation"] = [
    [19.9, 0, 0, 0],
    [7.9, 0, 0, 0.25],
    [13.9, 0, 0, 0.5, "easeInQuad"],
    [21.9, 0, 0, 0.75],
    [19.9, 0, 0, 1, "easeInBack"],
]
pointDefinitions["counter crank 2 rotation"] = [
    [-0, 0, 0, 0],
    [-90, 0, 0, 0.25],
    [-180, 0, 0, 0.5],
    [-270, 0, 0, 0.75],
    [-360, 0, 0, 1],
]
pointDefinitions["counter crank 2 arm position"] = [
    [0, -0.23, 10.55, 0],
    [0, -0.23, 10.65, 0.5, "easeInOutSine"],
    [0, -0.23, 10.55, 1, "easeInOutSine"],
]
pointDefinitions["counter crank 2 arm rotation"] = [
    [-180, 0, 0, 0],
    [-270, 0, 0, 0.25],
    [-360, 0, 0, 0.5],
    [-450, 0, 0, 0.75],
    [-540, 0, 0, 1],
]
pointDefinitions["counter crank 2 arm position 2"] = [
    [0, 0, 0, 0],
    [0, -0.05, 0, 0.25, "easeOutSine"],
    [0, 0, 0, 0.5, "easeInSine"],
    [0, 0.05, 0, 0.75, "easeOutSine"],
    [0, 0, 0, 1, "easeInSine"],
]

//
const train_animations = [{
// 1st wheel set
    "track": "pump1-1",
    "localPosition": "pump1-1 position",
}, {
    "track": "pump1-2",
    "localPosition": "pump1-2 position",
}, {
    "track": "coupling parent 1",
    "localPosition": "coupling parent 1 position",
}, {
    "track": "coupling parent 2",
    "localPosition": "coupling parent 2 position",
}, {
    "track": "main rod",
    "localRotation": "main rod parent 1 rotation",
}, {
    "track": "main rod parent 1",
    "localPosition": "main rod parent 1 position",
}, {
    "track": "main rod parent 2",
    "localPosition": "main rod parent 2 position",
}, {
    "track": "handlebar",
    "localRotation": "handlebar rotation",
}, {
    "track": "handlebar parent",
    "localPosition": "handlebar position",
}, {
    "track": "handlecross parent",
    "localPosition": "handlecross position",
}, {
    "track": "handlelever",
    "localRotation": "handlelever rotation",
}, {
    "track": "handlelever parent",
    "localPosition": "handlelever position",
}, {
    "track": "swingarm parent",
    "localRotation": "swingarm rotation",
    "localPosition": "swingarm position",
}, {
    "track": "slider rod parent",
    "localPosition": "slider rod position",
}, {
    "track": "hanging iron parent",
    "localPosition": "hanging iron position",
}, {
    "track": "hanging iron",
    "localRotation": "hanging iron rotation",
}, {
    "track": "swingarm rod",
    "localRotation": "swingarm rod rotation",
}, {
    "track": "swingarm rod parent",
    "localPosition": "swingarm rod parent position",
}, {
    "track": "swingarm rod parent 2",
    "localPosition": "swingarm rod parent 2 position",
}, {
    "track": "counter crank",
    "localRotation": "counter crank rotation",
}, {
    "track": "counter crank arm parent",
    "localPosition": "counter crank arm position",
    "localRotation": "counter crank arm rotation",
}, {
    "track": "counter crank arm parent 2",
    "localPosition": "counter crank arm position 2",
}, {
// 2nd wheel set
    "track": "pump2-1",
    "localPosition": "pump2-1 position",
}, {
    "track": "pump2-2",
    "localPosition": "pump2-2 position",
}, {
    "track": "coupling 2 parent 1",
    "localPosition": "coupling 2 parent 1 position",
}, {
    "track": "coupling 2 parent 2",
    "localPosition": "coupling 2 parent 2 position",
}, {
    "track": "main 2 rod",
    "localRotation": "main 2 rod parent 1 rotation",
}, {
    "track": "main 2 rod parent 1",
    "localPosition": "main 2 rod parent 1 position",
}, {
    "track": "main 2 rod parent 2",
    "localPosition": "main 2 rod parent 2 position",
}, {
    "track": "handlebar 2",
    "localRotation": "handlebar 2 rotation",
}, {
    "track": "handlebar 2 parent",
    "localPosition": "handlebar 2 position",
}, {
    "track": "handlecross 2 parent",
    "localPosition": "handlecross 2 position",
}, {
    "track": "handlelever 2",
    "localRotation": "handlelever 2 rotation",
}, {
    "track": "handlelever 2 parent",
    "localPosition": "handlelever 2 position",
}, {
    "track": "swingarm 2 parent",
    "localRotation": "swingarm 2 rotation",
    "localPosition": "swingarm 2 position",
}, {
    "track": "slider 2 rod parent",
    "localPosition": "slider 2 rod position",
}, {
    "track": "hanging iron 2 parent",
    "localPosition": "hanging iron 2 position",
}, {
    "track": "hanging iron 2",
    "localRotation": "hanging iron 2 rotation",
}, {
    "track": "swingarm 2 rod",
    "localRotation": "swingarm 2 rod rotation",
}, {
    "track": "swingarm 2 rod parent",
    "localPosition": "swingarm 2 rod parent position",
}, {
    "track": "swingarm 2 rod parent 2",
    "localPosition": "swingarm 2 rod parent 2 position",
}, {
    "track": "counter crank 2",
    "localRotation": "counter crank 2 rotation",
}, {
    "track": "counter crank 2 arm parent",
    "localPosition": "counter crank 2 arm position",
    "localRotation": "counter crank 2 arm rotation",
}, {
    "track": "counter crank 2 arm parent 2",
    "localPosition": "counter crank 2 arm position 2",
}]

function drive_train(beat, duration, destroy_it) {
    show_train(beat)

    //duration = duration * 1  // for development
    //repeat = repeat * 4 // for development
    let repeat = 29 // wheel rotation in sync with forwars movement
    for (let i = 0; i < train_animations.length; i++) {
        customEvents.push({
            "b": beat,
            "t": "AnimateTrack",
            "d": {
                "duration": duration / repeat,
                "repeat": repeat,
                ...train_animations[i]
            }
        })
    }

    customEvents.push({
        "b": beat,
        "t": "AnimateTrack",
        "d": {
            "track": "choochoo_greatgrandparent",
            "duration": duration,
            //"position": [-5.49, 0, 0], // for dev only
            //"position": [10, 0, -30], // for dev only
            "localPosition": [[-40.61, 0.12, 80, 0], [12.82, 0.12, -40, 1]],
            //"rotation": [0, -24, 0],
        }
    })
    if (destroy_it) {
        customEvents.push({
            "b": beat,
            "t": "AnimateTrack",
            "d": {
                "track": "choochoo_grandparent",
                "duration": duration,
                "localPosition": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0.42],
                    [-9, 0, 0, 1],
                    [0, 0, 0, 1],
                ],
            }
        }, {
            "b": beat,
            "t": "AnimateTrack",
            "d": {
                "track": "choochoo_parent",
                "duration": duration,
                "localPosition": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0.42],
                    [0, 6, 0, 0.536, "easeOutSine"],
                    [0, -2, 0, 0.768, "easeInSine"],
                    [0, -9, 0, 1, "easeOutSine"],
                    [0, -1000, 0, 1],
                ],
                "localRotation": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0.42],
                    [-30, 120, 0, 1, "easeOutQuad"],
                    [0, 0, 0, 1],
                ],
            }
        }, {
            "b": beat,
            "t": "AnimateTrack",
            "d": {
                "track": "choochoo",
                "duration": duration,
                "localRotation": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0.42],
                    [0, 0, 135, 0.536],
                    [0, 0, 240, 0.652],
                    [0, 0, 300, 0.768],
                    [0, 0, 345, 0.884],
                    [0, 0, 390, 1],
                    [0, 0, 0, 1],
                ],
            }
        })
    }

    // light events not needed since the ring light is on all the time anyway
    //light(beat, ring, w_on, 0, ids(train_ids))
    //light(beat + duration / 2, ring, w_trans, 2, ids(train_ids))
    //light(beat + duration, ring, off, 0, ids(train_ids))

    hide_train(beat + duration)
}

function show_train(beat) {
    customEvents.push({
        "b": beat - 0.001,
        "t": "AnimateTrack",
        "d": {"track": "choochoo_greatgrandparent", "localPosition": [-40.61, 0.12, 80], "rotation": [0, -24, 0]}
    })
}

function hide_train(beat) {
    customEvents.push({
        "b": beat + 0.001,
        "t": "AnimateTrack",
        "d": {"track": "choochoo_greatgrandparent", "localPosition": [0, -1000, 0]}
    })
}

function rot_train(beat) {
    customEvents.push({
        "b": beat - 0.02,
        "t": "AnimateTrack",
        "d": {
            "track": "choochoo_greatgrandparent",
            "localPosition": [11, 0, 20],
            "localRotation": [0, 112, 0],
            "scale": [0, 0, 0],
        }
    }, {
        "b": beat - 0.02,
        "t": "AnimateTrack",
        "d": {
            "track": "tender",
            "localRotation": [0, 77, 0],
            "localPosition": [-17, 0, 14.5],
        }
    }, {
        "b": beat - 0.01,
        "t": "AnimateTrack",
        "d": {
            "track": "choochoo_parent",
            "localPosition": [0, 0, 0],
            //"scale": [2, 2, 2],
        }
    }, {
        "b": beat,
        "t": "AnimateTrack",
        "d": {
            "track": "choochoo_greatgrandparent",
            "duration": 5,
            "scale": [[0, 0, 0, 0], [2, 2, 2, 1]],
            "localPosition": [[11, 0, 20, 0], [-5, -0.75, 40, 1]],
        }
    })
    /*
    for (let i = 0; i < train_animations.length; i++) {
        let d = {"track": train_animations[i]["track"]}
        if (train_animations[i]["localPosition"]) {
            d["localPosition"] = [
                pointDefinitions[train_animations[i]["localPosition"]][0][0],
                pointDefinitions[train_animations[i]["localPosition"]][0][1],
                pointDefinitions[train_animations[i]["localPosition"]][0][2],
            ]
        }
        if (train_animations[i]["localRotation"]) {
            d["localRotation"] = [
                pointDefinitions[train_animations[i]["localRotation"]][0][0],
                pointDefinitions[train_animations[i]["localRotation"]][0][1],
                pointDefinitions[train_animations[i]["localRotation"]][0][2],
            ]
        }
        customEvents.push({
            "b": beat - 0.02,
            "t": "AnimateTrack",
            "d": d,
        })
    }
    */
}
//rot_train(1)


// clouds
materials["cloud"] = {"color": [1, 1, 1], "shader": "OpaqueLight"}
for (let i = -30; i <= 30; i+=12) {

    let pos_log = []
    function check_poslog(new_pos) {
        for (let old_pos of pos_log) {
            let vector_distance = Math.sqrt(
                Math.pow(Math.abs(Math.abs(old_pos[0]) - Math.abs(new_pos[0])), 2) +
                Math.pow(Math.abs(Math.abs(old_pos[1]) - Math.abs(new_pos[1])), 2) +
                Math.pow(Math.abs(Math.abs(old_pos[2]) - Math.abs(new_pos[2])), 2)
            )
            if (vector_distance < 6) {
                return false
            }
        }
        return true
    }

    function make_pos(x) {
        while (true) {
            let new_pos = [
                x + r(Math.random()) * 16,
                27 + Math.random() * 8,
                Math.random() * 32,
            ]
            if (check_poslog(new_pos)) {
                pos_log.push(new_pos)
                return new_pos
            }
        }
    }

    for (let j = 0; j < 18; j++) {
        environment.push({
            "geometry": {"type": "Sphere", "material": "cloud"},
            "position": make_pos(i),
            "scale": [
                7 + Math.random() * 11,
                5 + Math.random() * 8,
                6 + Math.random() * 10,
            ],
            "rotation": [
                Math.round(Math.random() * 90 - 45),
                Math.round(Math.random() * 180 - 90),
                Math.round(Math.random() * 90 - 45),
            ],
            "components": {
                "ILightWithId": {"type": 0},
                "TubeBloomPrePassLight": {
                    "colorAlphaMultiplier": Math.random() * 0.2 + 0.5,
                    "bloomFogIntensityMultiplier": 0,
                },
            },
            "track": "cloud" + i,
        })
    }

    customEvents.push({
        "b": 0,
        "t": "AssignTrackParent",
        "d": {
            "childrenTracks": ["cloud" + i],
            "parentTrack": "cloud" + i + "_parent",
        }
    }, {
        "b": 0,
        "t": "AnimateTrack",
        "d": {
            "track": "cloud" + i + "_parent",
            "localPosition": [0, -1000, 0],
        }
    })
}

function move_cloud(beat, track_name, duration) {
    customEvents.push({
        "b": beat,
        "t": "AnimateTrack",
        "d": {
            "track": track_name + "_parent",
            "duration": duration,
            "localPosition": [[0, 0, 70, 0], [0, -3, -15, 1], [0, -1000, 0, 1]],
        }
    })
}

// cloud lanes: -30, -18, -6, 6, 18, 30
// [lane, beat, duration]
let cloud_lanes = [
    [-18, 97, 12], [18, 99.5, 16], [-30, 105, 14],
    [6, 113, 12], [30, 115, 16], [-6, 121, 14],
    [18, 129, 10], [-18, 130, 10], [6, 131.5, 12], [30, 137, 12],
    [-30, 145, 10], [-6, 146, 11], [18, 147, 12], [-18, 153, 9], [30, 155, 8], [6, 157, 7], [-30, 159, 6],
]

for (let i = 0; i < cloud_lanes.length; i++) {
    move_cloud(cloud_lanes[i][1], "cloud" + cloud_lanes[i][0], cloud_lanes[i][2])
}

function move_storm(beat) {
    let cloud_ids = [-6, 18, -18, 6, -30, 30]
    for (let i = 0; i < cloud_ids.length; i++) {
        customEvents.push({
            "b": beat + i * 4,
            "t": "AnimateTrack",
            "d": {
                "track": "cloud" + cloud_ids[i] + "_parent",
                "duration": 85,
                "localPosition": [[0, 5, 5, 0], [0, 10, 80, 1], [0, -1000, 0, 1]],
            }
        })
    }
}
move_storm(160)


// the hail
const hail_steps = 3
materials["hail"] = {"color": [0.6, 0.7, 0.8], "shader": "Standard", "shaderKeywords": []}
for (let i = 0; i < hail_steps; i++) {
    for(let j = 0; j < 13; j++) {
        environment.push({
            "geometry": {"type": "Sphere", "material": "hail"},
            "position": [
                Math.random() * 28 - 29,
                Math.random() * 20 - 1000,
                Math.random() * 12,
            ],
            "scale": [
                (1.2 + Math.random()) / 3,
                (1.2 + Math.random()) / 3,
                (1.2 + Math.random()) / 3,
            ],
            "track": "hail_" + i,
        })
    }
    customEvents.push({
        "b": 0,
        "t": "AssignTrackParent",
        "d": {
            "childrenTracks": ["hail_" + i,],
            "parentTrack": "hail_" + i + "_parent",
        }
    })
}
function let_it_hail(beat) {
    let duration = 3

    for (let i = 0; i < hail_steps; i++) {
        let b = beat + duration / hail_steps * i

        customEvents.push({
            "b": b,
            "t": "AnimateTrack",
            "d": {
                "track": "hail_" + i + "_parent",
                "duration": duration,
                "position": [
                    [11.5, 1039, b - 150, 0],
                    [-4.5, 979, b - 150 + duration, 1], // clouds move with 1 unit per beat
                    [0, -1000, 0, 1]
                ],
            }
        })
    }
}

// the beat number here is used for Z positioning, don't use repeat!
let_it_hail(164)
let_it_hail(167)
let_it_hail(170)
let_it_hail(173)
let_it_hail(176)
let_it_hail(179)
let_it_hail(182)
let_it_hail(185)
let_it_hail(188)
let_it_hail(191)
let_it_hail(194)


// the lightning
materials["lightning"] = {"color": [0.83, 0.9, 0.96], "shader": "TransparentLight"}

let lightning = [
    // position, rotation, scale, alpha, bloom
    // 1st lightning
    [[-11.9, 29.95, 21.15], [10, 0, 20], [0.25, 6, 0.25], 1.5, 6.3],
    [[-11.6, 26, 20.5], [10, 0, -30], [0.14, 3, 0.14], 1.3, 2.8], // left branch 1
    [[-8.9, 26.5, 20.3], [0, 10, 70], [0.21, 4.2, 0.21], 1.4, 6.2],
    [[-13.4, 24.7, 20.25], [15, 0, -90], [0.14, 2.2, 0.14], 1.2, 2.7], // left branch 1
    [[-7.3, 24.6, 19.85], [5, 0, -15], [0.2, 2.5, 0.2], 1.3, 6.1],
    [[-15.35, 24.3, 20.25], [0, 0, -66], [0.13, 1.9, 0.13], 1.1, 2.6], // left branch 1.1
    [[-14.1, 23.3, 19.8], [20, 0, 15], [0.13, 2.8, 0.13], 1.1, 2.6], // left branch 1.2
    [[-7.1, 22.85, 19.6], [15, 0, 40], [0.19, 1.5, 0.19], 1.3, 6],
    [[-17.45, 24.45, 20.2], [-5, 0, -115], [0.12, 2.7, 0.12], 1, 2.5], // left branch 1.1
    [[-13.9, 21, 19.15], [10, 0, -10], [0.1, 2, 0.1], 1, 2.5], // left branch 1.2
    [[-6.05, 20.75, 19.2], [10, 0, 20], [0.19, 3.4, 0.19], 1.3, 5.8],
    [[-19.3, 24.5, 20.25], [-10, 0, -50], [0.11, 1.7, 0.11], 1, 2.4], // left branch 1.1
    [[-5.7, 18.2, 18.9], [0, 0, -15], [0.16, 2, 0.16], 1.2, 5.6],
    [[-20.1, 23.4, 20.6], [-20, 0, -10], [0.1, 1.3, 0.1], 0.9, 2.2], // left branch 1.1
    [[-5.3, 16.1, 18.9], [0, 0, 30], [0.11, 2.4, 0.11], 1, 2.6], // right branch 2
    [[-6.5, 16.5, 17.7], [10, -60, -60], [0.15, 3, 0.15], 1.2, 5.4],
    [[-20.6, 22.4, 20.9], [-10, 0, -40], [0.09, 1.1, 0.09], 0.9, 2], // left branch 1.1.1
    [[-20, 22.35, 20.8], [0, 0, 20], [0.1, 0.9, 0.1], 0.9, 2], // left branch 1.1.2
    [[-4.85, 14.35, 18.7], [15, 0, -10], [0.1, 1.4, 0.1], 0.9, 2.4], // right branch 2.1
    [[-3.65, 14.8, 18.9], [-10, 0, 75], [0.1, 2.1, 0.1], 0.9, 2.4], // right branch 2.2
    [[-7.2, 15, 16.15], [25, 0, -10], [0.14, 1.7, 0.14], 1.2, 5.2],
    [[-5.35, 13.2, 18.45], [5, 0, -40], [0.09, 1.2, 0.09], 0.8, 2.2], // right branch 2.1
    [[-2.05, 14.75, 18.9], [-10, 0, 110], [0.09, 1.3, 0.09], 0.8, 2.2], // right branch 2.2.1
    [[-2.1, 13.75, 18.7], [20, 0, 35], [0.09, 1.9, 0.09], 0.8, 2.2], // right branch 2.2.2
    [[-7.95, 13.63, 15.38], [35, 0, -40], [0.13, 2, 0.13], 1.1, 5],
    [[-5.5, 11.9, 18.45], [-5, 0, 15], [0.08, 1.7, 0.08], 0.7, 2], // right branch 2.1
    [[-1.4, 15.45, 18.95], [10, 0, 175], [0.08, 1, 0.08], 0.7, 2], // right branch 2.2.1
    [[-0.7, 12.7, 18.5], [10, 0, 65], [0.08, 1.9, 0.08], 0.7, 2], // right branch 2.2.2
    [[-9.15, 11.52, 14.38], [20, 0, -20], [0.12, 3.3, 0.12], 1.1, 4.8],
    [[-0.95, 16.45, 19], [0, 0, 140], [0.07, 1.3, 0.07], 0.6, 1.8], // right branch 2.2.1
    [[0, 11.85, 18.45], [0, 0, -20], [0.08, 0.9, 0.08], 0.6, 1.8], // right branch 2.2.2.1
    [[0.55, 11.7, 18.6], [-15, 0, 30], [0.08, 1.5, 0.08], 0.6, 1.8], // right branch 2.2.2.2
    [[-10.65, 10.45, 13.5], [15, -30, -110], [0.08, 2, 0.08], 0.9, 2.4], // left branch 3.1
    [[-10.45, 9.75, 13.9], [-10, 0, -65], [0.08, 1.5, 0.08], 0.9, 2.4], // left branch 3.2
    [[-9.15, 9.55, 13.55], [30, 0, 45], [0.11, 1.7, 0.11], 1.1, 4.6],
    [[-12.05, 11.35, 13.05], [-5, 0, -135], [0.07, 1.6, 0.07], 0.8, 2.2], // left branch 3.1.1
    [[-11.9, 10.75, 13.1], [25, 0, -90], [0.07, 0.8, 0.07], 0.8, 2.2], // left branch 3.1.2
    [[-11.05, 8.97, 13.8], [20, 0, 10], [0.07, 1, 0.07], 0.8, 2.2], // left branch 3.2
    [[-8.27, 8.5, 13.1], [15, 0, 25], [0.1, 1.2, 0.1], 1, 4.4],
    [[-13.25, 12.2, 13.05], [-10, 0, -110], [0.06, 1.1, 0.06], 0.7, 2], // left branch 3.1.1
    [[-12.45, 10.5, 13.1], [0, 0, -25], [0.06, 0.6, 0.06], 0.7, 2], // left branch 3.1.2
    [[-11.25, 7.95, 13.55], [10, 0, -25], [0.06, 1.3, 0.06], 0.7, 2], // left branch 3.2
    [[-7.6, 7.4, 12.95], [0, 0, 35], [0.08, 1.3, 0.08], 0.8, 2.4], // right branch 4
    [[-8.15, 7.08, 12.55], [25, 20, 0], [0.09, 2, 0.09], 1, 4.2],
    [[-12.85, 10, 13.05], [15, 0, -50], [0.05, 0.7, 0.05], 0.7, 2], // left branch 3.1.2
    [[-12.05, 7.5, 13.15], [0, -30, -99], [0.06, 1.2, 0.06], 0.6, 1.8], // left branch 3.2.1
    [[-11.75, 7.1, 13.32], [25, 0, -40], [0.05, 0.8, 0.05], 0.6, 1.8], // left branch 3.2.2
    [[-6.8, 6.66, 12.98], [-10, 0, 65], [0.07, 0.9, 0.07], 0.7, 2.2], // right branch 4
    [[-8.3, 5.7, 12.15], [0, 0, 0], [0.09, 1, 0.09], 1, 4],
    [[-12.94, 7.47, 12.55], [0, -40, -75], [0.05, 1, 0.05], 0.5, 1.6], // left branch 3.2.1.1
    [[-12.8, 7.25, 12.78], [0, -20, -40], [0.05, 0.8, 0.05], 0.5, 1.6], // left branch 3.2.1.2
    [[-11.9, 6.3, 13], [20, 0, 10], [0.04, 1.1, 0.04], 0.55, 1.6], // left branch 3.2.2
    [[-6.55, 6.25, 13.08], [-15, 0, -40], [0.06, 0.6, 0.06], 0.6, 2], // right branch 4
    [[-8.78, 4.7, 11.95], [20, 0, -40], [0.08, 1.5, 0.08], 1, 3.9],
    [[-11.73, 5.43, 12.56], [35, 0, 10], [0.04, 0.9, 0.04], 0.5, 1.4], // left branch 3.2.2
    [[-6.72, 5.7, 13.27], [-20, 0, 5], [0.05, 0.7, 0.05], 0.55, 1.8], // right branch 4
    [[-9.25, 3.75, 11.5], [30, 0, 0], [0.08, 1, 0.08], 0.9, 3.8],
    [[-11.78, 4.9, 12.1], [50, 0, -20], [0.03, 0.6, 0.03], 0.45, 1.2], // left branch 3.2.2.1
    [[-11.45, 4.73, 12.2], [20, 0, 30], [0.03, 0.8, 0.03], 0.45, 1.2], // left branch 3.2.2.2
    [[-6.55, 5.19, 13.48], [-25, 0, 35], [0.04, 0.5, 0.04], 0.5, 1.6], // right branch 4
    [[-8.15, 2.7, 11], [60, -60, 15], [0.08, 2.6, 0.08], 0.9, 3.7],
    [[-11.42, 4.46, 11.35], [70, -30, 10], [0.03, 1.5, 0.03], 0.4, 1], // left branch 3.2.2.1
    [[-6.46, 4.84, 13.68], [-35, 0, -15], [0.03, 0.4, 0.03], 0.45, 1.6], // right branch 4
    [[-7.08, 1.87, 10.56], [40, 0, -5], [0.07, 0.6, 0.07], 0.9, 3.6],
    [[-7.02, 1.18, 10.24], [15, 0, 10], [0.07, 1, 0.07], 0.9, 3.5],
    [[-5.8, -0.7, 9.3], [30, 0, 35], [0.07, 4, 0.07], 0.9, 3.5],
    // 2nd lightning
    [[-8.4, 29.4, 33.7], [0, 0, 10], [0.15, 3.3, 0.15], 2.5, 5],
    [[-8.7, 27.1, 33.7], [0, 0, -40], [0.15, 1.7, 0.15], 2.5, 5],
    [[-10.2, 26.25, 33.7], [0, 0, -75], [0.11, 2, 0.11], 1.7, 2.9], // left branch 1
    [[-8.4, 25.8, 33.7], [0, 0, 50], [0.15, 2.2, 0.15], 2.4, 5],
    [[-12, 26.15, 33.7], [0, 0, -100], [0.11, 1.7, 0.11], 1.6, 2.8], // left branch 1
    [[-7.75, 24.25, 33.7], [0, 0, -15], [0.15, 1.8, 0.15], 2.4, 5],
    [[-13.1, 25.8, 33.7], [0, 0, -25], [0.1, 1.2, 0.1], 1.6, 2.7], // left branch 1
    [[-7.7, 22.6, 33.7], [0, 0, 20], [0.11, 1.5, 0.11], 1.5, 2.7], // right branch 2
    [[-9.2, 22.8, 33.7], [0, 0, -65], [0.15, 2.7, 0.15], 2.4, 5],
    [[-13.8, 25, 33.7], [0, 0, -60], [0.1, 1, 0.1], 1.5, 2.6], // left branch 1.1
    [[-13.3, 24.5, 33.7], [0, 0, 5], [0.1, 1.5, 0.1], 1.5, 2.6], // left branch 1.2
    [[-6.87, 21.2, 33.7], [0, 0, 40], [0.11, 1.8, 0.11], 1.4, 2.6], // right branch 2
    [[-10.85, 21.5, 33.7], [0, 0, -30], [0.15, 1.8, 0.15], 2.3, 5],
    [[-15.15, 24.83, 33.7], [0, 0, -95], [0.09, 1.9, 0.09], 1.5, 2.5], // left branch 1.1
    [[-13.42, 23.25, 33.7], [0, 0, -20], [0.09, 1.1, 0.09], 1.5, 2.5], // left branch 1.2
    [[-6.87, 20.2, 33.7], [0, 0, -60], [0.1, 1.4, 0.1], 1.4, 2.5], // right branch 2
    [[-11.3, 20.3, 33.7], [0, 0, 0], [0.15, 0.8, 0.15], 2.3, 5],
    [[-16.5, 25.16, 33.7], [0, 0, -120], [0.09, 0.9, 0.09], 1.4, 2.4], // left branch 1.1.1
    [[-16.7, 24.54, 33.7], [0, 0, -60], [0.09, 1.4, 0.09], 1.4, 2.4], // left branch 1.1.2
    [[-14.02, 22.3, 33.7], [0, 0, -45], [0.09, 1.2, 0.09], 1.4, 2.4], // left branch 1.2
    [[-6.8, 19.4, 33.7], [0, 0, 55], [0.1, 1.7, 0.1], 1.3, 2.4], // right branch 2
    [[-10.85, 19.7, 33.7], [0, 0, 65], [0.15, 1.1, 0.15], 2.3, 5],
    [[-17.15, 25.7, 33.7], [0, 0, -145], [0.08, 0.8, 0.08], 1.4, 2.3], // left branch 1.1.1
    [[-17.66, 23.78, 33.7], [0, 0, -40], [0.08, 1.1, 0.08], 1.4, 2.3], // left branch 1.1.2
    [[-14.5, 21.15, 33.7], [0, 0, -5], [0.08, 1.5, 0.08], 1.4, 2.3], // left branch 1.2
    [[-6.44, 18.47, 33.7], [0, 0, -30], [0.09, 1, 0.09], 1.3, 2.3], // right branch 2.1
    [[-5.84, 18.17, 33.7], [0, 0, 20], [0.09, 1.6, 0.09], 1.3, 2.3], // right branch 2.2
    [[-10.7, 18.7, 33.7], [0, 0, -20], [0.15, 1.6, 0.15], 2.3, 5],
    [[-18.2, 26.35, 33.7], [0, 0, -110], [0.08, 1.7, 0.08], 1.3, 2.2], // left branch 1.1.1
    [[-18, 23, 33.7], [0, 0, 0], [0.08, 0.7, 0.08], 1.3, 2.2], // left branch 1.1.2
    [[-14.75, 20, 33.7], [0, 0, -25], [0.08, 0.9, 0.08], 1.3, 2.2], // left branch 1.2.1
    [[-14.3, 19.9, 33.7], [0, 0, 25], [0.08, 1.2, 0.08], 1.3, 2.2], // left branch 1.2.2
    [[-7, 17.85, 33.7], [0, 0, -55], [0.09, 0.7, 0.09], 1.2, 2.2], // right branch 2.1
    [[-10.9, 17.3, 33.7], [0, 0, 10], [0.15, 1.3, 0.15], 2.3, 5],
    [[-18.2, 22.03, 33.7], [0, 0, -20], [0.07, 1.3, 0.07], 1.3, 2.1], // left branch 1.1.2
    [[-14, 19.02, 33.7], [0, 0, 5], [0.07, 0.6, 0.07], 1.3, 2.1], // left branch 1.2.2
    [[-7.33, 17.1, 33.7], [0, 0, -5], [0.08, 1.1, 0.08], 1.2, 2.1], // right branch 2.1
    [[-10.3, 16, 33.7], [0, 0, 35], [0.09, 1.6, 0.09], 1.3, 2.1], // right branch 3
    [[-11.4, 16, 33.7], [0, 0, -40], [0.15, 1.8, 0.15], 2.2, 5],
    [[-19.2, 21.15, 33.7], [0, 0, -70], [0.07, 1.6, 0.07], 1.2, 2], // left branch 1.1.2.1
    [[-18.7, 21, 33.7], [0, 0, -35], [0.07, 1, 0.07], 1.2, 2], // left branch 1.1.2.2
    [[-9.75, 14.85, 33.7], [0, 0, 10], [0.08, 0.9, 0.08], 1.3, 2], // right branch 3
    [[-12.3, 15.6, 33.7], [0, 0, 45], [0.15, 1, 0.15], 2.2, 5],
    [[-20.55, 21.02, 33.7], [0, 0, -105], [0.06, 1.2, 0.06], 1.2, 1.9], // left branch 1.1.2.1
    [[-19, 20.1, 33.7], [0, 0, 0], [0.06, 1, 0.06], 1.2, 1.9], // left branch 1.1.2.2
    [[-9.85, 14.05, 33.7], [0, 0, -25], [0.08, 0.8, 0.08], 1.2, 1.9], // right branch 3
    [[-12.9, 15.2, 33.7], [0, 0, -20], [0.15, 1.4, 0.15], 2.2, 5],
    [[-21.5, 20.65, 33.7], [0, 0, -30], [0.06, 1.3, 0.06], 1.1, 1.8], // left branch 1.1.2.1
    [[-18.8, 19.25, 33.7], [0, 0, 25], [0.06, 0.8, 0.06], 1.1, 1.8], // left branch 1.1.2.2
    [[-10.4, 13.4, 33.7], [0, 0, -50], [0.07, 1, 0.07], 1.2, 1.8], // right branch 3
    [[-14.08, 14.22, 33.7], [0, 0, -70], [0.15, 2, 0.15], 2.2, 5],
    [[-22.13, 19.9, 33.7], [0, 0, -60], [0.05, 0.7, 0.05], 1.1, 1.7], // left branch 1.1.2.1
    [[-10.78, 12.57, 33.7], [0, 0, 0], [0.07, 1, 0.07], 1.1, 1.7], // right branch 3
    [[-15.5, 13.3, 33.7], [0, 0, -40], [0.15, 1.5, 0.15], 2.2, 5],
    [[-22.87, 19.77, 33.7], [0, 0, -95], [0.05, 0.9, 0.05], 1, 1.6], // left branch 1.1.2.1
    [[-10.4, 11.52, 33.7], [0, 0, 35], [0.06, 1.3, 0.06], 1.1, 1.6], // right branch 3
    [[-15, 11.8, 33.7], [0, 0, 45], [0.15, 2.7, 0.15], 2.2, 5], // main 2
    [[-14.15, 10.2, 33.7], [0, 0, -10], [0.08, 1.4, 0.08], 1.3, 1.6], // right branch 4
    [[-16.1, 13.1, 33.7], [0, 0, 15], [0.15, 0.7, 0.15], 2.2, 5], // main 1
    [[-15, 10.1, 33.7], [0, 0, -50], [0.15, 2.4, 0.15], 2.2, 5], // main 2
    [[-14.1, 9.15, 33.7], [0, 0, 25], [0.08, 0.8, 0.08], 1.2, 1.5], // right branch 4
    [[-16.9, 13.9, 33.7], [0, 0, 55], [0.15, 1.6, 0.15], 2.2, 5], // main 1
    [[-17.9, 15, 33.7], [0, 0, 25], [0.1, 1.2, 0.1], 1.3, 1.7], // left branch 5
    [[-17, 9.3, 33.7], [0, 0, -90], [0.15, 2.1, 0.15], 2.2, 5], // main 2
    [[-14.15, 8.35, 33.7], [0, 0, -25], [0.07, 1, 0.07], 1.2, 1.4], // right branch 4
    [[-18.2, 13.3, 33.7], [0, 0, -30], [0.15, 2.6, 0.15], 2.2, 5], // main 1
    [[-18.9, 15.7, 33.7], [0, 0, 80], [0.09, 1.5, 0.09], 1.3, 1.6], // left branch 5
    [[-18.85, 8.15, 33.7], [0, 0, -35], [0.15, 2.9, 0.15], 2.2, 5], // main 2
    [[-14.9, 7.65, 33.7], [0, 0, -65], [0.07, 1.2, 0.07], 1.1, 1.3], // right branch 4
    [[-19.9, 11.8, 33.7], [0, 0, -70], [0.15, 2.2, 0.15], 2.2, 5], // main 1
    [[-19.9, 15.5, 33.7], [0, 0, -40], [0.09, 0.9, 0.09], 1.2, 1.5], // left branch 5
    [[-20.4, 7.1, 33.7], [0, 5, 75], [0.15, 1.6, 0.15], 2.2, 5], // main 2
    [[-15.75, 7, 33.7], [0, 0, -35], [0.06, 1, 0.06], 1.1, 1.3], // right branch 4.1
    [[-15.3, 6.7, 33.7], [0, 0, 10], [0.06, 1.4, 0.06], 1.1, 1.3], // right branch 4.2
    [[-21.5, 11.5, 33.7], [0, 0, 85], [0.15, 1.1, 0.15], 2.2, 5], // main 1
    [[-20.9, 15.8, 33.7], [0, 0, -130], [0.08, 1.8, 0.08], 1.2, 1.4], // left branch 5.1
    [[-20.75, 14.95, 33.7], [0, 0, -70], [0.08, 1.2, 0.08], 1.2, 1.4], // left branch 5.2
    [[-21.5, 6.4, 33.8], [0, 5, -20], [0.15, 1.9, 0.15], 2.2, 5], // main 2
    [[-16.35, 6.35, 33.7], [0, 0, -50], [0.06, 0.8, 0.06], 1, 1.2], // right branch 4.1
    [[-22.4, 12.3, 33.7], [0, 0, 25], [0.15, 1.8, 0.15], 2.2, 5], // main 1
    [[-21.8, 16.75, 33.7], [0, 0, -155], [0.08, 0.8, 0.08], 1.1, 1.3], // left branch 5.1
    [[-21.9, 14.8, 33.7], [0, 0, -95], [0.08, 1.1, 0.08], 1.1, 1.3], // left branch 5.2
    [[-22.4, 6, 33.9], [0, 10, 50], [0.15, 1.3, 0.15], 2.2, 5], // main 2
    [[-16.8, 5.6, 33.7], [0, 0, -15], [0.05, 1, 0.05], 1, 1.1], // right branch 4.1
    [[-23.4, 12.8, 33.7], [0, 0, -60], [0.15, 1.4, 0.15], 2.2, 5], // main 1
    [[-23.75, 6.3, 34.1], [0, 10, -80], [0.15, 1.8, 0.15], 2.2, 5], // main 2
    [[-22.85, 15.08, 33.7], [0, 0, -120], [0.07, 0.9, 0.07], 1.1, 1.2], // left branch 5.2
    [[-25.5, 12.2, 33.7], [0, 0, -80], [0.15, 3, 0.15], 2.2, 5], // main 1
    [[-25.5, 5.3, 34.3], [0, 0, -45], [0.15, 2.5, 0.15], 2.2, 5], // main 2
    [[-23.4, 15, 33.7], [0, 0, -25], [0.07, 0.7, 0.07], 1, 1.1], // left branch 5.2
    [[-24.05, 15, 33.7], [0, 0, 55], [0.06, 1.2, 0.06], 0.9, 1], // left branch 5.2
    // 3rd lightning
    [[3.8, 29.2, 21.7], [0, 0, 0], [0.13, 2.8, 0.13], 3, 4.5], // main
    [[4.55, 27.55, 21.7], [0, 0, 70], [0.1, 1.6, 0.1], 3, 4.5], // main 1
    [[3.3, 26.5, 21.7], [0, 0, -20], [0.12, 3, 0.12], 3, 4.5], // main 2
    [[6.05, 26.2, 21.7], [0, 0, 35], [0.1, 2.6, 0.1], 3, 4.5], // main 1
    [[2.2, 24.5, 21.7], [0, 0, -45], [0.1, 1.7, 0.1], 3, 4.5], // main 2
    [[7.5, 25.35, 21.7], [0, 0, 105], [0.1, 1.5, 0.1], 3, 4.5], // main 1
    [[1.7, 22.5, 21.7], [0, 0, 5], [0.1, 2.7, 0.1], 3, 4.5], // main 2
    [[0.45, 23.8, 21.7], [0, 0, -85], [0.08, 2.3, 0.08], 1.4, 3], // left branch 1
    [[7.65, 24.5, 21.7], [0, 0, -30], [0.12, 2.2, 0.12], 3, 4.5], // main 1
    [[0.9, 20.6, 21.7], [0, 0, -60], [0.1, 2.1, 0.1], 3, 4.5], // main 2
    [[-1.23, 23.18, 21.7], [0, 0, -45], [0.08, 1.5, 0.08], 1.3, 2.4], // left branch 1
    [[7.3, 22.95, 21.7], [0, 0, 20], [0.1, 1.2, 0.1], 3, 4.5], // main 1
    [[-0.4, 18.5, 21.7], [0, 0, -15], [0.1, 3.2, 0.1], 3, 4.5], // main 2
    [[-2.2, 22.8, 21.7], [0, 0, -105], [0.07, 0.9, 0.07], 1.3, 2.3], // left branch 1.1
    [[-1.8, 22, 21.7], [0, 0, -5], [0.08, 1.3, 0.08], 1.3, 2.3], // left branch 1.2
    [[8.3, 22, 21.7], [0, 0, 65], [0.1, 1.8, 0.1], 3, 4.5], // main 1
    [[-0.3, 15.9, 21.7], [0, 0, 25], [0.1, 2.5, 0.1], 3, 4.5], // main 2
    [[-3.42, 22.77, 21.7], [0, 0, -80], [0.07, 1.6, 0.07], 1.2, 2.2], // left branch 1.1
    [[-2.38, 20.45, 21.7], [0, 0, -30], [0.07, 2.1, 0.07], 1.2, 2.2], // left branch 1.2
    [[10.25, 21.5, 21.7], [0, 0, 85], [0.1, 2.3, 0.1], 3, 4.5], // main 1
    [[1.6, 14, 21.7], [0, 0, 60], [0.1, 3.1, 0.1], 3, 4.5], // main 2
    [[-4.58, 22.19, 21.7], [0, 0, -40], [0.06, 1.2, 0.06], 1.2, 2.1], // left branch 1.1
    [[-2.68, 19.22, 21.7], [0, 0, 35], [0.06, 0.8, 0.06], 1.2, 2.1], // left branch 1.2
    [[11.38, 20.39, 21.7], [0, 0, 0], [0.1, 1.9, 0.1], 3, 4.5], // main 1
    [[4.3, 13.6, 21.7], [0, 0, -75], [0.1, 2.8, 0.1], 3, 4.5], // main 2
    [[-5.08, 21.1, 21.7], [0, 0, -10], [0.06, 1.3, 0.06], 1.1, 2], // left branch 1.1
    [[-2.87, 18.57, 21.7], [0, 0, -55], [0.06, 1.1, 0.06], 1.1, 2], // left branch 1.2
    [[11.85, 19.65, 21.7], [0, 0, 111], [0.1, 0.9, 0.1], 3, 4.5], // main 1
    [[6.35, 14.65, 21.7], [0, 0, -45], [0.12, 2, 0.12], 3, 4.5], // main 2
    [[-5.84, 20.09, 21.7], [0, 0, -60], [0.05, 1.5, 0.05], 1.1, 1.9], // left branch 1.1
    [[-3.92, 18.26, 21.7], [0, 0, -90], [0.05, 1.2, 0.05], 1.1, 1.9], // left branch 1.2.1
    [[-3.2, 17.58, 21.7], [0, 0, 10], [0.05, 1.4, 0.05], 1.1, 1.9], // left branch 1.2.2
    [[12.85, 19.3, 21.7], [0, 0, 50], [0.1, 1.5, 0.1], 3, 4.5], // main 1
    [[8.4, 14.4, 21.7], [0, 0, 55], [0.1, 3.3, 0.1], 3, 4.5], // main 2
    [[-5.1, 18, 21.7], [0, 0, -65], [0.05, 1.3, 0.05], 1, 1.8], // left branch 1.2.1
    [[-3.3, 16.43, 21.7], [0, 0, -25], [0.05, 1, 0.05], 1, 1.8], // left branch 1.2.2
    [[13.7, 17.8, 21.7], [0, 0, 15], [0.1, 2.1, 0.1], 3, 4.5], // main 1
    [[10.35, 11.78, 21.7], [0, 0, 20], [0.1, 3.6, 0.1], 3, 4.5], // main 2
    [[-6, 17.2, 21.7], [0, 0, -30], [0.05, 1.2, 0.05], 1, 1.7], // left branch 1.2.1
    [[-3.1, 15.35, 21.7], [0, 0, 35], [0.04, 1.5, 0.04], 1, 1.7], // left branch 1.2.2
    [[13.6, 16.4, 21.7], [0, 0, -45], [0.15, 1, 0.15], 3, 4.5], // main 1
    [[10.3, 9, 21.7], [0, 0, -30], [0.12, 2.6, 0.12], 3, 4.5], // main 2
    [[-7.05, 16.55, 21.7], [0, 0, -80], [0.05, 1.5, 0.05], 0.9, 1.6], // left branch 1.2.1.1
    [[-6.18, 16.08, 21.7], [0, 0, 10], [0.05, 1.2, 0.05], 0.9, 1.6], // left branch 1.2.1.2
    [[13.85, 15.85, 21.7], [0, 0, 75], [0.1, 1.4, 0.1], 3, 4.5], // main 1
    [[9.05, 7.65, 21.7], [0, 0, -70], [0.12, 1.3, 0.12], 3, 4.5], // main 2
    [[-8.07, 16.13, 21.7], [0, 0, -45], [0.04, 0.8, 0.04], 0.9, 1.5], // left branch 1.2.1.1
    [[14.51, 14.82, 21.7], [0, 0, 0], [0.1, 1.7, 0.1], 3, 4.5], // main 1
    [[8.15, 6.3, 21.7], [0, 0, -15], [0.11, 2.4, 0.11], 3, 4.5], // main 2
    [[15.1, 15.25, 21.7], [0, 0, 50], [0.08, 1.4, 0.08], 1.3, 2.3], // main 1.1
    [[15.2, 13, 21.7], [0, 0, 35], [0.1, 2.4, 0.1], 3, 4.5], // main 1
    [[8.4, 4.2, 21.7], [0, 0, 30], [0.1, 2.3, 0.1], 3, 4.5], // main 2
    [[16.25, 14.85, 21.7], [0, 0, 95], [0.08, 1.2, 0.08], 1.2, 2.2], // main 1.1
    [[16.3, 12.35, 21.7], [0, 0, -60], [0.15, 1.1, 0.15], 3, 4.5], // main 1
    [[9.85, 2.9, 21.7], [0, 0, 70], [0.1, 1.9, 0.1], 3, 4.5], // main 2
    [[17.58, 14.57, 21.7], [0, 0, 65], [0.07, 1.6, 0.07], 1.2, 2.1], // main 1.1
    [[17.5, 12.4, 21.7], [0, 0, 70], [0.1, 1.5, 0.1], 3, 4.5], // main 1
    [[11.8, 2.77, 21.7], [0, 0, 100], [0.11, 2.2, 0.11], 3, 4.5], // main 2
    [[18.43, 13.89, 21.7], [0, 0, 20], [0.07, 0.7, 0.07], 1.1, 2], // main 1.1
    [[18, 11.85, 21.7], [0, 0, -35], [0.12, 0.8, 0.12], 3, 4.5], // main 1
    [[13.5, 3.8, 21.7], [0, 0, 145], [0.1, 2.1, 0.1], 3, 4.5], // main 2
    [[19.05, 13.45, 21.7], [0, 0, 80], [0.06, 1, 0.06], 1.1, 1.9], // main 1.1
    [[17.9, 10.9, 21.7], [0, 0, 10], [0.1, 1.3, 0.1], 3, 4.5], // main 1
    [[15.02, 4.55, 21.7], [0, 0, 85], [0.1, 1.9, 0.1], 3, 4.5], // main 2
    [[20.28, 13.57, 21.7], [0, 0, 105], [0.07, 1.5, 0.07], 1, 1.8], // main 1.1.1
    [[19.87, 13.02, 21.7], [0, 0, 45], [0.06, 0.9, 0.06], 1, 1.8], // main 1.1.2
    [[18.97, 10.07, 21.7], [0, 0, 80], [0.1, 2, 0.1], 3, 4.5], // main 1
    [[16.52, 4, 21.7], [0, 0, 50], [0.09, 1.5, 0.09], 3, 4.5], // main 2
    [[21.52, 13.41, 21.7], [0, 0, 55], [0.05, 1.2, 0.05], 1, 1.7], // main 1.1.1
    [[20.33, 12.22, 21.7], [0, 0, 15], [0.05, 1, 0.05], 1, 1.7], // main 1.1.2
    [[20.5, 9.35, 21.7], [0, 0, 45], [0.1, 1.6, 0.1], 3, 4.5], // main 1
    [[17.1, 3.03, 21.7], [0, 0, 0], [0.09, 1, 0.09], 3, 4.5], // main 2
    [[22.44, 12.91, 21.7], [0, 0, 70], [0.05, 0.9, 0.05], 0.9, 1.6], // main 1.1.1
    [[20.88, 11.31, 21.7], [0, 0, 45], [0.05, 1.2, 0.05], 0.9, 1.6], // main 1.1.2
    [[21, 8.3, 21.7], [0, 0, -10], [0.1, 1, 0.1], 3, 4.5], // main 1
    [[16.75, 2.05, 21.7], [0, 0, -35], [0.09, 1.2, 0.09], 3, 4.5], // main 2
    [[22.01, 10.9, 21.7], [0, 0, 90], [0.04, 1.4, 0.04], 0.9, 1.5], // main 1.1.2.1
    [[21.42, 10.55, 21.7], [0, 0, 20], [0.04, 0.7, 0.04], 0.9, 1.5], // main 1.1.2.2
    [[21.5, 7.45, 21.7], [0, 0, 60], [0.1, 1.4, 0.1], 3, 4.5], // main 1
    [[18.15, 0.97, 22.77], [0, -32, 73], [0.1, 4.2, 0.1], 3, 4.5], // main 2
    [[21.93, 10, 21.7], [0, 0, 60], [0.04, 0.9, 0.04], 0.8, 1.4], // main 1.1.2.2
    [[22.6, 5.8, 21.7], [0, 0, 20], [0.1, 2.8, 0.1], 3, 4.5], // main 1
    [[22.52, 9.55, 21.7], [0, 0, 40], [0.03, 0.6, 0.03], 0.8, 1.3], // main 1.1.2.2
]

const lightning_start_id = 400 + top_lasers.length
for (let i = 0; i < lightning.length; i++) {
    environment.push({
        "geometry": {"type": "Cube", "material": "lightning"},
        "position": lightning[i][0],
        "rotation": lightning[i][1],
        "scale": lightning[i][2],
        "components": {
            "ILightWithId": {"type": 1, "lightID": lightning_start_id + i},
            "TubeBloomPrePassLight": {"colorAlphaMultiplier": lightning[i][3], "bloomFogIntensityMultiplier": lightning[i][4]}
        },
    })
}

const lightning_1 = range(lightning_start_id, lightning_start_id + 65)
const lightning_2 = range(lightning_start_id + 66, lightning_start_id + 156)
const lightning_3 = range(lightning_start_id + 157, lightning_start_id + 239)
const lightning_color = color(0.6, 0.7, 0.9)

function lightning_strike(beat, lightning_ids) {
    for (let i = 0; i < lightning_ids.length; i++) {
        // type 1 = rings, value 3 = r_fade
        light(beat + i / lightning_ids.length, 1, 3, 8, ids([lightning_ids[i]]), lightning_color)
        light(beat + i / lightning_ids.length + 0.5, 1, 3, 8, ids([lightning_ids[i]]), lightning_color)
    }
}


// the tornado
materials["tornado"] = {"color": [0, 0, 0], "shader": "OpaqueLight"}

for (let i = 1; i <= 115; i++) {
    let a = 1 - Math.sin(r(i * 2.4) / 180 + Math.PI / 2)
    let x = r(Math.sin(r(i * 2.4) * 5 * Math.PI / 180)) * a * 15 + a
    let y = i / 6 + r(0) / 4 + i / 29 - 0.5
    let z = r(Math.cos(r(i*2.4) * 5 * Math.PI / 180)) * a * 15 + a
    environment.push({
        "geometry": {"type": "Sphere", "material": "tornado"},
        "position": [x, y, z],
        //"rotation": [0, r(i) * 5 - i / 20, 0],
        "rotation": [0, i * 12, 0],
        //"scale": [0.1 + a * 10, 0.1 + a * 2, 0.05 + a],
        "scale": [0.2 + a * 20, 0.2 + a * 3, 0.2 + a * 3],
        "components": {
            "ILightWithId": {"type": 0},
            "TubeBloomPrePassLight": {"colorAlphaMultiplier": 0, "bloomFogIntensityMultiplier": 0}
        },
        "track": "tornado",
    })
}

/*
environment.push({
    "id": "Bats", "lookupMethod": "Contains", "duplicate": 1, "active": true,
    "position": [-2, 0, 2], "rotation": [0, 0, 60], "scale": [0.1, 0.1, 0.1],
    "track": "tornado2",
}, {
    "id": "Bats", "lookupMethod": "Contains", "duplicate": 1, "active": true,
    "position": [2, 0, -2], "rotation": [0, 180, 60], "scale": [0.1, 0.1, 0.1],
    "track": "tornado2",
}, {
    "id": "Bats", "lookupMethod": "Contains", "duplicate": 1, "active": true,
    "position": [6, 15, 2], "rotation": [0, 180, 30], "scale": [0.3, 0.3, 0.3],
    "track": "tornado2",
}, {
    "id": "Bats", "lookupMethod": "Contains", "duplicate": 1, "active": true,
    "position": [-6, 15, -2], "rotation": [0, 0, 30], "scale": [0.3, 0.3, 0.3],
    "track": "tornado2",
})
*/
customEvents.push({
    "b": 0,
    "t": "AssignTrackParent",
    "d": {
        "childrenTracks": ["tornado"],
        "parentTrack": "tornado_parent",
    }
}, {
    "b": 0,
    "t": "AssignTrackParent",
    "d": {
        "childrenTracks": ["tornado_parent"/*, "tornado2"*/],
        "parentTrack": "tornado_parent2",
    }
}, {
    "b": 0,
    "t": "AnimateTrack",
    "d": {
        "track": "tornado_parent2",
        "localPosition": [0, -1000, 0],
    }
})

function move_tornado(beat, duration) {
    customEvents.push({
        "b": beat,
        "t": "AnimateTrack",
        "d": {
            "track": "tornado_parent",
            "duration": duration,
            "localRotation": [
                [0, 0, 0, 0],
                [0, -175, 0, 0.08],
                [0, -350, 0, 0.16],
                [0, -525, 0, 0.24],
                [0, -700, 0, 0.32],
                [0, -875, 0, 0.4],
                [0, -1050, 0, 0.48],
                [0, -1225, 0, 0.56],
                [0, -1400, 0, 0.64],
                [0, -1575, 0, 0.72],
                [0, -1750, 0, 0.8],
                [0, -1925, 0, 0.88],
                [0, -2100, 0, 0.96],
                [0, -2200, 0, 1],
            ],
        }
    }, {
        "b": beat,
        "t": "AnimateTrack",
        "d": {
            "track": "tornado_parent2",
            "duration": duration,
            "localPosition": [
                [15, 0, 0, 0],
                [10, 0, 20, 0.1],
                [7, 0, 50, 0.27],
                [39, 0, 44, 0.5, "easeInOutSine"],
                [-13, 0, 45, 0.85, "easeInOutSine"],
                [-20, 0, 75, 1, "easeInOutSine"],
                [0, -1000, 0, 1],
            ],
            "scale": [
                [0.75, 0.75, 0.75, 0],
                [1.5, 1.5, 1.5, 0.85, "easeInOutSine"],
                [0, 1, 0, 1, "easeInOutSine"],
            ],
            "localRotation": [
                [0, 0, 0, 0],
                [0, -175, 0, 0.25],
                [0, -350, 0, 0.5],
                [0, -525, 0, 0.75],
                [0, -700, 0, 1],
            ],
        }
    }, {
        "b": beat,
        "t": "AnimateComponent",
        "d": {
            "track": "tornado",
            "duration": duration,
            "TubeBloomPrePassLight": {
                "colorAlphaMultiplier": [
                    [0.35, 0],
                    [0.55, 0.25],
                    [0.75, 0.5],
                    [0.85, 0.85],
                    [0, 1],
                ],
            }
        }
    })
}


// the tsunami
materials["tsunami"] = {"shader": "TransparentLight"}

//let tsunami_elements = [17, 16, 15, 14, 13, 12, 11, 10, 9, 9, 10, 11, 12, 13, 14, 15, 16, 17]
let tsunami_elements = [14, 13, 12, 11, 10, 9, 8, 7, 6, 6, 7, 8, 9, 10, 11, 12, 13, 14]
let tsunami_z = 36
let tsunami_id = 0

for (let i = 0; i < tsunami_elements.length; i++) {
    for (let j = 0; j < tsunami_elements[i]; j++) {
        let z = tsunami_z - tsunami_elements[i] + j * 2
        let rotation_top = i < tsunami_elements.length/2 ? [-90, -90, 0]  : [-90, 90, 0]
        environment.push({
            "geometry": {"type": "Triangle", "material": "tsunami"},
            "position": [0, -0.05, z],
            "rotation": rotation_top,
            "scale": [0, 0, 0],
            "track": "tsunami_" + i,
            "components": {
                "ILightWithId": {"type": 0, "lightID": 1000 + tsunami_id},
                "TubeBloomPrePassLight": {"bloomFogIntensityMultiplier": 6, "colorAlphaMultiplier": 2.1 - tsunami_elements[i]/10}
            },
        })
        tsunami_id++
    }
    customEvents.push({
        "b": 0,
        "t": "AssignTrackParent",
        "d": {
            "childrenTracks": ["tsunami_" + i],
            "parentTrack": "tsunami_" + i + "_parent0",
        }
    }, {
        "b": 0,
        "t": "AssignTrackParent",
        "d": {
            "childrenTracks": ["tsunami_" + i + "_parent0"],
            "parentTrack": "tsunami_" + i + "_parent1",
        }
    })
}

pointDefinitions["tsunami_0_position_x"] = [[10, 0, 0, 0], [0, 0, 0, 0.5], [-9.6, 0, 0, 0.75], [-18.7, 0, 0, 1]]
pointDefinitions["tsunami_1_position_x"] = [[12, 0, 0, 0], [1.3, 0, 0, 0.5], [-10.2, 0, 0, 0.75], [-21.3, 0, 0, 1]]
pointDefinitions["tsunami_2_position_x"] = [[14, 0, 0, 0], [2.35, 0, 0, 0.5], [-10.9, 0, 0, 0.75], [-23.8, 0, 0, 1]]
pointDefinitions["tsunami_3_position_x"] = [[16, 0, 0, 0], [3.175, 0, 0, 0.5], [-11.7, 0, 0, 0.75], [-26.3, 0, 0, 1]]
pointDefinitions["tsunami_4_position_x"] = [[18, 0, 0, 0], [3.675, 0, 0, 0.5], [-12.6, 0, 0, 0.75], [-28.8, 0, 0, 1]]
pointDefinitions["tsunami_5_position_x"] = [[20, 0, 0, 0], [3.85, 0, 0, 0.5], [-13.6, 0, 0, 0.75], [-31.3, 0, 0, 1]]
pointDefinitions["tsunami_6_position_x"] = [[22, 0, 0, 0], [3.575, 0, 0, 0.5], [-14.7, 0, 0, 0.75], [-34, 0, 0, 1]]
pointDefinitions["tsunami_7_position_x"] = [[24, 0, 0, 0], [2.6, 0, 0, 0.5], [-15.9, 0, 0, 0.75], [-36.3, 0, 0, 1]]
pointDefinitions["tsunami_8_position_x"] = [[26, 0, 0, 0], [1.5, 0, 0, 0.5], [-17.2, 0, 0, 0.75], [-38.7, 0, 0, 1]]
pointDefinitions["tsunami_9_position_x"] = [[28, 0, 0, 0], [2.05, 0, 0, 0.5], [-17.2, 0, 0, 0.75], [-38.7, 0, 0, 1]]
pointDefinitions["tsunami_10_position_x"] = [[30, 0, 0, 0], [3.825, 0, 0, 0.5], [-15.9, 0, 0, 0.75], [-36.3, 0, 0, 1]]
pointDefinitions["tsunami_11_position_x"] = [[32, 0, 0, 0], [5.24, 0, 0, 0.5], [-14.7, 0, 0, 0.75], [-34, 0, 0, 1]]
pointDefinitions["tsunami_12_position_x"] = [[34, 0, 0, 0], [6.387, 0, 0, 0.5], [-13.6, 0, 0, 0.75], [-31.3, 0, 0, 1]]
pointDefinitions["tsunami_13_position_x"] = [[36, 0, 0, 0], [7.151, 0, 0, 0.5], [-12.6, 0, 0, 0.75], [-28.8, 0, 0, 1]]
pointDefinitions["tsunami_14_position_x"] = [[38, 0, 0, 0], [7.41, 0, 0, 0.5], [-11.7, 0, 0, 0.75], [-26.3, 0, 0, 1]]
pointDefinitions["tsunami_15_position_x"] = [[40, 0, 0, 0], [7.585, 0, 0, 0.5], [-10.9, 0, 0, 0.75], [-23.8, 0, 0, 1]]
pointDefinitions["tsunami_16_position_x"] = [[42, 0, 0, 0], [8.1, 0, 0, 0.5], [-10.2, 0, 0, 0.75], [-21.3, 0, 0, 1]]
pointDefinitions["tsunami_17_position_x"] = [[44, 0, 0, 0], [8.94, 0, 0, 0.5], [-9.6, 0, 0, 0.75], [-18.7, 0, 0, 1]]

pointDefinitions["tsunami_0_position_y"] = [[0, 0, 0, 0], [0, 1, 0, 0.5, "easeOutSine"], [0, 0.7, 0, 0.75, "easeInQuad"], [0, -0.2, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_1_position_y"] = [[0, 0, 0, 0], [0, 2.2, 0, 0.5, "easeOutSine"], [0, 1.4, 0, 0.75, "easeInQuad"], [0, -0.4, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_2_position_y"] = [[0, 0, 0, 0], [0, 3.6, 0, 0.5, "easeOutSine"], [0, 2.2, 0, 0.75, "easeInQuad"], [0, -0.6, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_3_position_y"] = [[0, 0, 0, 0], [0, 5.2, 0, 0.5, "easeOutSine"], [0, 3.1, 0, 0.75, "easeInQuad"], [0, -0.75, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_4_position_y"] = [[0, 0, 0, 0], [0, 6.95, 0, 0.5, "easeOutSine"], [0, 3.9, 0, 0.75, "easeInQuad"], [0, -0.95, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_5_position_y"] = [[0, 0, 0, 0], [0, 8.8, 0, 0.5, "easeOutSine"], [0, 4.6, 0, 0.75, "easeInQuad"], [0, -1.1, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_6_position_y"] = [[0, 0, 0, 0], [0, 10.5, 0, 0.5, "easeOutSine"], [0, 5.2, 0, 0.75, "easeInQuad"], [0, -1.2, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_7_position_y"] = [[0, 0, 0, 0], [0, 12, 0, 0.5, "easeOutSine"], [0, 5.5, 0, 0.75, "easeInQuad"], [0, -1.4, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_8_position_y"] = [[0, 0, 0, 0], [0, 13.45, 0, 0.5, "easeOutSine"], [0, 5.4, 0, 0.75, "easeInQuad"], [0, -1.5, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_9_position_y"] = [[0, 0, 0, 0], [0, 14.65, 0, 0.5, "easeOutSine"], [0, 5.45, 0, 0.75, "easeInQuad"], [0, -1.4, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_10_position_y"] = [[0, 0, 0, 0], [0, 14.255, 0, 0.5, "easeOutSine"], [0, 5.6, 0, 0.75, "easeInQuad"], [0, -1.3, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_11_position_y"] = [[0, 0, 0, 0], [0, 12.84, 0, 0.5, "easeOutSine"], [0, 5.3, 0, 0.75, "easeInQuad"], [0, -1.1, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_12_position_y"] = [[0, 0, 0, 0], [0, 11.201, 0, 0.5, "easeOutSine"], [0, 4.7, 0, 0.75, "easeInQuad"], [0, -1, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_13_position_y"] = [[0, 0, 0, 0], [0, 9.357, 0, 0.5, "easeOutSine"], [0, 4, 0, 0.75, "easeInQuad"], [0, -0.85, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_14_position_y"] = [[0, 0, 0, 0], [0, 7.38, 0, 0.5, "easeOutSine"], [0, 3.2, 0, 0.75, "easeInQuad"], [0, -0.65, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_15_position_y"] = [[0, 0, 0, 0], [0, 5.4, 0, 0.5, "easeOutSine"], [0, 2.3, 0, 0.75, "easeInQuad"], [0, -0.5, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_16_position_y"] = [[0, 0, 0, 0], [0, 3.48, 0, 0.5, "easeOutSine"], [0, 1.5, 0, 0.75, "easeInQuad"], [0, -0.3, 0, 1, "easeOutQuad"]]
pointDefinitions["tsunami_17_position_y"] = [[0, 0, 0, 0], [0, 1.67, 0, 0.5, "easeOutSine"], [0, 0.8, 0, 0.75, "easeInQuad"], [0, -0.1, 0, 1, "easeOutQuad"]]

pointDefinitions["tsunami_0_rotation"] = [[0, 0, 0, 0], [0, 0, 40, 0.5], [0, 0, 110, 0.75], [0, 0, 180, 1]]
pointDefinitions["tsunami_1_rotation"] = [[0, 0, 0, 0], [0, 0, 50, 0.5], [0, 0, 120, 0.75], [0, 0, 190, 1]]
pointDefinitions["tsunami_2_rotation"] = [[0, 0, 0, 0], [0, 0, 60, 0.5], [0, 0, 130, 0.75], [0, 0, 200, 1]]
pointDefinitions["tsunami_3_rotation"] = [[0, 0, 0, 0], [0, 0, 70, 0.5], [0, 0, 140, 0.75], [0, 0, 210, 1]]
pointDefinitions["tsunami_4_rotation"] = [[0, 0, 0, 0], [0, 0, 80, 0.5], [0, 0, 150, 0.75], [0, 0, 220, 1]]
pointDefinitions["tsunami_5_rotation"] = [[0, 0, 0, 0], [0, 0, 90, 0.5], [0, 0, 160, 0.75], [0, 0, 230, 1]]
pointDefinitions["tsunami_6_rotation"] = [[0, 0, 0, 0], [0, 0, 110, 0.5], [0, 0, 177.5, 0.75], [0, 0, 245, 1]]
pointDefinitions["tsunami_7_rotation"] = [[0, 0, 0, 0], [0, 0, 140, 0.5], [0, 0, 202.5, 0.75], [0, 0, 265, 1]]
pointDefinitions["tsunami_8_rotation"] = [[0, 0, 0, 0], [0, 0, 115, 0.5], [0, 0, 200, 0.75], [0, 0, 285, 1]]
pointDefinitions["tsunami_9_rotation"] = [[0, 0, 0, 0], [0, 0, 15, 0.5, "easeOutQuad"], [0, 0, 65, 0.75], [0, 0, 115, 1]]
pointDefinitions["tsunami_10_rotation"] = [[0, 0, 0, 0], [0, 0, -40, 0.5, "easeOutSine"], [0, 0, 25, 0.75], [0, 0, 90, 1]]
pointDefinitions["tsunami_11_rotation"] = [[0, 0, 0, 0], [0, 0, -50, 0.5, "easeOutSine"], [0, 0, 15, 0.75], [0, 0, 80, 1]]
pointDefinitions["tsunami_12_rotation"] = [[0, 0, 0, 0], [0, 0, -60, 0.5, "easeOutSine"], [0, 0, 5, 0.75], [0, 0, 70, 1]]
pointDefinitions["tsunami_13_rotation"] = [[0, 0, 0, 0], [0, 0, -75, 0.5, "easeOutSine"], [0, 0, -7.5, 0.75], [0, 0, 60, 1]]
pointDefinitions["tsunami_14_rotation"] = [[0, 0, 0, 0], [0, 0, -90, 0.5], [0, 0, -20, 0.75], [0, 0, 50, 1]]
pointDefinitions["tsunami_15_rotation"] = [[0, 0, 0, 0], [0, 0, -80, 0.5], [0, 0, -20, 0.75], [0, 0, 40, 1]]
pointDefinitions["tsunami_16_rotation"] = [[0, 0, 0, 0], [0, 0, -70, 0.5], [0, 0, -20, 0.75], [0, 0, 30, 1]]
pointDefinitions["tsunami_17_rotation"] = [[0, 0, 0, 0], [0, 0, -60, 0.5], [0, 0, -20, 0.75], [0, 0, 20, 1]]

pointDefinitions["tsunami_scale"] = [[0, 0, 0, 0], [2, 2, 2, 0.125], [2, 2, 2, 0.875], [0, 0, 0, 1]]

function move_tsunami(beat, duration) {

    let light_ids = ids(tsunami_ids)
    let light_color = color(0.1, 0.5, 0.7)

    light(beat, backlight, r_on, 0, light_ids, light_color)
    light(beat + 2, backlight, r_trans, 1, light_ids, light_color)
    light(beat + duration / 4*3, backlight, r_on, 1, light_ids, light_color)
    light(beat + duration, backlight, r_trans, 0, light_ids, light_color)

    for (let i = 0; i < tsunami_elements.length; i++) {
        customEvents.push({
            "b": beat,
            "t": "AnimateTrack",
            "d": {
                "track": "tsunami_" + i,
                "duration": duration,
                "scale": "tsunami_scale",
            }
        }, {
            "b": beat,
            "t": "AnimateTrack",
            "d": {
                "track": "tsunami_" + i + "_parent0",
                "duration": duration,
                "localPosition": "tsunami_" + i + "_position_x",
                "localRotation": "tsunami_" + i + "_rotation",
            }
        }, {
            "b": beat,
            "t": "AnimateTrack",
            "d": {
                "track": "tsunami_" + i + "_parent1",
                "duration": duration,
                "position": "tsunami_" + i + "_position_y",
            }
        })
    }
}


/**
 *  light functions
 */

function light(beat, type, value, intensity, ...custom_data) {
    // time in beats
    // type which light (see light types)
    // value what the light does (see light events)
    // intensity (seems to controls the alpha value)
    // optional custom_data to merge into the template
    let template = {"b": beat, "et": type, "i": value, "f": intensity}
    if (!!custom_data) {
        template = deepMerge(template, ...custom_data)
    }
    events.push(template)
}

function ids(id_array) {
    // returns given light IDs to merge
    return {"customData" : {"lightID": id_array}}
}

function lockrotation() {
    // prevent laser rotation from being randomizes
    return {"customData": {"lockRotation": true}}
}

function speed(value) {
    // speed of the laser rotation
    return {"customData": {"speed": value}}
}

function direction(value) {
    // rind rotation direction, 1 spins clockwise, 0 spins counter-clockwise
    return {"customData": {"direction": value}}
}

function color(r, g, b) {
    // chroma color
    return {"customData": {"color": [r, g, b]}}
}

// light effect combination and animation functions
function ground_wave(beat, step, on_color, show_runway) {
    let trans_color = on_color == r_on ? r_trans : l_trans

    for (let b = 0; b < ground_z.length; b++) {
        let light_ids = ids([100 + b])
        if (b > 0) {
            light_ids = ids([100 + b, 200 + b, 300 + b])
        }

        light(beat + b * step - step, ring, on_color, 0, light_ids)
        light(beat + b * step, ring, trans_color, 4 + (b * 0.05), light_ids)
        light(beat + b * step + 8 * step, ring, trans_color, 0, light_ids)
        //console.log(beat + b * step, beat + b * step + 8 * step)

        if (show_runway == null) {
            continue  // skip ground plate animations
        }

        function animate_ground(track_name, scale_points) {
            if (ground_events.has(track_name)) {
                customEvents.push({
                    "b": beat + b * step,
                    "t": "AnimateTrack",
                    "d": {
                        "track": track_name,
                        "duration": 9 * step,
                        "scale": scale_points,
                    }
                })
            }
        }
        if (show_runway) {
            animate_ground("ground_row_" + b + "_runway", [[0, 0, 0, 0], [...ground_scale, 0.125]])
        } else {
            animate_ground("ground_row_" + b + "_runway", [[...ground_scale, 0], [...ground_scale, 0.125], [0, 0, 0, 1]])
        }
        animate_ground("ground_row_" + b, [[0, 0, 0, 0], [...ground_scale, 0.125], [0, 0, 0, 1]])

        if (forest_events.has("tree" + b)) {
            let scale = b/25 + 0.9  // scale a bit bigger as more far behind
            //console.log(beat + b * step, beat + b * step + 5 * step)
            customEvents.push({
                "b": beat + b * step - 0.5,
                "t": "AnimateTrack",
                "d": {
                    "track": "tree" + b,
                    "duration": 5 * step,
                    "scale": [[0, 0, 0, 0], [scale, scale, scale, 1]],
                }
            })
        }
    }
}


function reverse_wave(beat, step, on_color, fade_pow) {
    let trans_color = on_color == r_on ? r_trans : on_color == l_on ? l_trans : w_trans

    for (let a = 0; a < ground_z.length; a++) {
        let b = ground_z.length - a - 1
        let light_ids = ids([100 + b])
        if (b > 0) {
            light_ids = ids([100 + b, 200 + b, 300 + b])
        }

        //light(beat + a * step, ring, off, 0, light_ids)
        //light(beat + a * step + 2 * step, ring, trans_color, 0.2 + Math.pow(a / 20.5, Math.PI), light_ids)
        //light(beat + a * step + 4 * step + Math.pow(a / fade_pow, Math.PI), ring, trans_color, 0, light_ids)
        light(beat + a * step * 1.4, ring, off, 0, light_ids)
        light(beat + 1 + a * step * 1.2 + 4 * step, ring, trans_color, 0.3 + Math.pow(a / 14.3, Math.PI), light_ids)
        light(beat + 2 + a * step + 6 * step + Math.pow(a / fade_pow, Math.PI), ring, trans_color, 0, light_ids)
    }
}

function piano_node(beat, type, on_color, duration, laser_ids, glow_ids) {
    let trans_color = on_color == r_on ? r_trans : on_color == l_on ? l_trans : w_trans

    let ids_laser = laser_ids ? ids(laser_ids) : {}
    let ids_glow = glow_ids ? ids(glow_ids) : {}

    if (laser_ids) {
        light(beat - 0.2, type, on_color, 0, ids_laser)
        light(beat, type, trans_color, 3, ids_laser)
        light(beat + duration, type, trans_color, 0, ids_laser)
        light(beat + duration + 0.01, type, off, 0, ids_laser)
    }
    if (glow_ids) {
        light(beat - 0.2, ring, on_color, 0, ids_glow)
        light(beat, ring, trans_color, 2, ids_glow)
        light(beat + duration, ring, trans_color, 0, ids_glow)
        light(beat + duration + 0.01, ring, off, 0, ids_glow)
    }
}

function laser_windup(beat, duration, on_color, keep_rotate) {
    // reset lasers
    light(beat, rotate_l, 0, 0)
    light(beat, rotate_r, 0, 0)

    let trans_color = on_color == r_on ? r_trans : on_color == l_on ? l_trans : w_trans
    let step = duration / back_laser_ids.length

    for (let i = 0; i < back_laser_ids.length; i++) {
        light(beat + i * step, rotate_l, 1, 1, speed(1 + i), direction(0), lockrotation())
        light(beat + i * step, rotate_r, 1, 1, speed(1 + i), direction(0), lockrotation())
        light(beat + i * step, laser_l, on_color, 0, ids([18 - i]))
        light(beat + i * step, laser_r, on_color, 0, ids([18 - i]))
        light(beat + duration, laser_l, trans_color, 3.3, ids([18 - i]))
        light(beat + duration, laser_r, trans_color, 3.3, ids([18 - i]))
    }

    light(beat + duration, laser_l, off, 0, ids(back_laser_ids))
    light(beat + duration, laser_r, off, 0, ids(back_laser_ids))
    if (!keep_rotate) {
        light(beat + duration, rotate_l, 0, 0)
        light(beat + duration, rotate_r, 0, 0)
    }
}

function laser_clicks(beat, start_side, start_color) {
    let repetitions = 7
    let sides_switch = 2  // beats per side
    let step = 0.25
    let intensity = 1.5

    let laser_side = start_side == "left" ? laser_l : laser_r
    let laser_rotate = start_side == "left" ? rotate_l : rotate_r
    let on_color = start_color == l_on ? l_on : r_on

    for (let i = 0; i < repetitions; i++) {
        light(beat + i*sides_switch, laser_rotate, 1, 1, speed(0))

        let light_id = 2

        for (let j = 0; j < sides_switch; j+=step) {
            let timing = beat + i*sides_switch + j

            light(timing, laser_side, on_color, intensity, ids([light_id]))
            light(timing + step, laser_side, off, 0, ids([light_id]))

            light_id += 1
        }

        laser_side = laser_side == laser_l ? laser_r : laser_l
        laser_rotate = laser_rotate == rotate_l ? rotate_r : rotate_l
        intensity += 0.25
    }

    light(beat + repetitions * sides_switch, rotate_l, 0, 0)
    light(beat + repetitions * sides_switch, rotate_r, 0, 0)
}

function drum_hit(beat, intensity, length, distorted) {

    function get_intensity(_b) {
        return intensity / length * (length - _b)
    }

    function get_ids(h, all) {
        let id_array = []
        if (all) { // NOTE: `all` is not in use r.n.
            for (let i = 0; i <= h; i++) {
                let start = 200 + i * 100
                id_array = [...id_array, ...range(start, start + drum_lasers.length * 2 - 1)]
            }
        } else {
            let start = 200 + h * 100
            id_array = range(start, start + drum_lasers.length * 2 - 1)
        }
        return ids(id_array)
    }

    if (distorted) {
        let step = 1/4
        for (let i = 0; i < length; i+=step) {
            for (let j = 0; j < drum_height; j++) {
                let id_array = get_ids(j)
                let timing = beat + i + j / drum_height * step
                light(timing, center, w_on, get_intensity(i), id_array)
                light(timing + 1/drum_height*step, center, off, 0, id_array)
            }
        }
    } else {
        let step = length/4
        for (let i = 0; i < step*2; i+=step) {
            for (let j = 0; j < drum_height; j++) {
                if (i == 0) {
                    let id_array = get_ids(j)
                    light(beat + j/drum_height*step, center, w_on, intensity, id_array)
                } else {
                    let id_array = get_ids(drum_height - j - 1)
                    light(beat + i + j/drum_height*step, center, w_on, intensity, id_array)
                    light(beat + i + j/drum_height*step + step*2, center, w_trans, 0, id_array)
                }
            }
        }
    }
}

function laser_drum_row(beat, direction, on_colors, step, laser_speed) {
    let id_array
    if (direction == "left2right") {
        id_array = [outer_left_lasers, inner_left_lasers, inner_right_lasers, outer_right_lasers]
    } else if (direction == "right2left") {
        id_array = [outer_right_lasers, inner_right_lasers, inner_left_lasers, outer_left_lasers]
    } else if (direction == "start_left") {
        id_array = [outer_left_lasers, inner_left_lasers, outer_right_lasers, inner_right_lasers]
    } else if (direction == "start_right") {
        id_array = [outer_right_lasers, inner_right_lasers, outer_left_lasers, inner_left_lasers]
    } else if (direction == "in_out") {
        id_array = [inner_left_lasers, inner_right_lasers, outer_right_lasers, outer_left_lasers]
    }

    // don't reset laser rotation for "off" events
    if (on_colors) {
        light(beat, rotate_l, 1, 1, speed(laser_speed))
        light(beat, rotate_r, 1, 1, speed(laser_speed))
    }

    if (!Array.isArray(on_colors)) {
        on_colors = [on_colors, on_colors, on_colors, on_colors]
    }

    for (let i = 0; i < id_array.length; i++) {
        let laser_side = [outer_left_lasers, inner_left_lasers].includes(id_array[i]) ? laser_l : laser_r
        light(beat + i * step, laser_side, on_colors[i], on_colors[i] ? 1.75 : 0, ids(id_array[i]))
    }
}

function laser_top_row(beat, direction, on_colors, step) {
    let id_array
    if (direction == "left2right") {
        id_array = [400, 401, 403, 404]
    } else if (direction == "right2left") {
        id_array = [404, 403, 401, 400]
    }

    if (!Array.isArray(on_colors)) {
        on_colors = [on_colors, on_colors, on_colors, on_colors]
    }

    for (let i = 0; i < id_array.length; i++) {
        let trans_color = on_colors[i] == l_on ? l_trans : r_trans

        light(beat + i * step, ring, on_colors[i], 3, ids([id_array[i]]))
        light(beat + i * step + 0.5, ring, trans_color, 0, ids([id_array[i]]))
    }
}

pointDefinitions["laser_noise_row rotation"] = [
    [0, 90, 0, 0],
    [0, 90, -86, 1, "easeOutQuad"],
    [0, 90, 0, 1],
]
function laser_noise_row(beat, on_color) {
    for (let i = 0; i < 2; i+=0.5) {
        let laser_speed = 8 - i * 4
        light(beat + i, rotate_l, laser_speed, laser_speed, lockrotation(), speed(laser_speed))
        light(beat + i, rotate_r, laser_speed, laser_speed, lockrotation(), speed(laser_speed))
    }

    for (let i = 0; i < 2; i+=0.25) {
        light(beat + i, laser_l, off, 0)
        light(beat + i, laser_r, off, 0)
        light(beat + i + 1/8, laser_l, on_color, 2 - i, ids([...outer_left_lasers, ...inner_left_lasers]))
        light(beat + i + 1/8, laser_r, on_color, 2 - i, ids([...inner_right_lasers, ...outer_right_lasers]))
    }

    for (let i = 0; i < rotating_lasers.length; i++) {
        customEvents.push({
            "b": beat,
            "t": "AnimateTrack",
            "d": {
                "track": "drum_laser_" + i,
                "duration": 2,
                "rotation": "laser_noise_row rotation",
            }
        })
    }

    light(beat + 2, laser_l, off, 0)
    light(beat + 2, laser_r, off, 0)
    light(beat + 2, rotate_l, 0, 0)
    light(beat + 2, rotate_r, 0, 0)
}

pointDefinitions["laser_drum_final rotation"] = [
    [0, 90, 0, 0],
    [0, 90, -21.5, 0],
    [0, 90, -21.5, 0.25],
    [0, 90, -43, 0.25],
    [0, 90, -43, 0.5],
    [0, 90, -64.5, 0.5],
    [0, 90, -64.5, 0.75],
    [0, 90, -86, 0.75],
    [0, 90, -86, 1],
    [0, 90, 0, 1],
]
function laser_drum_final(beat) {
    light(beat, rotate_l, 1, 1, speed(0))
    light(beat, rotate_r, 1, 1, speed(0))

    light(beat, laser_l, r_on, 2, ids([...outer_left_lasers, ...inner_left_lasers]))
    light(beat + 0.5, laser_r, l_on, 2, ids([...outer_right_lasers, ...inner_right_lasers]))

    for (let i = 0; i < 1; i+=0.25) {
        light(beat + 1 + i, laser_l, r_on, 2 - 0.25 - i, ids([...outer_left_lasers, ...inner_left_lasers]))
        light(beat + 1 + i, laser_r, l_on, 2 - 0.25 - i, ids([...outer_right_lasers, ...inner_right_lasers]))
    }

    for (let i = 0; i < 4; i++) {
        customEvents.push({
            "b": beat + 1,
            "t": "AnimateTrack",
            "d": {
                "track": "drum_laser_" + i,
                "duration": 1,
                "rotation": "laser_drum_final rotation",
            }
        })
    }

    light(beat + 2, laser_l, off, 0)
    light(beat + 2, laser_r, off, 0)
}

pointDefinitions["laser_swipe rotation 1"] = [
    [-81, -45, 0, 0],
    [-81, 45, 0, 1],
]
pointDefinitions["laser_swipe rotation 2"] = [
    [-81, 45, 0, 0],
    [-81, -45, 0, 1, "easeOutQuad"],
]
function laser_swipe(beat) {
    light(beat, rotate_l, 2, 2)

    let laser_on_array = [outer_left_swipe, inner_left_swipe, inner_right_swipe, outer_right_swipe]
    let step = 1/8
    let fade = 1/4

    for (let i = 0; i < laser_on_array.length; i++) {
        light(beat + i * step, laser_l, w_on, 0, ids(laser_on_array[3-i]))
        light(beat + i * step + fade, laser_l, w_trans, 0.9, ids(laser_on_array[3-i]))
        light(beat + i * step + fade + fade, laser_l, w_trans, 0, ids(laser_on_array[3-i]))

        customEvents.push({
            "b": beat + i * step,
            "t": "AnimateTrack",
            "d": {
                "track": "drum_swipe_" + (3-i),
                "duration": 1,
                "rotation": "laser_swipe rotation 1",
            }
        })
    }

    for (let i = 0; i < laser_on_array.length; i++) {
        light(beat + 1 + i * step, laser_l, w_on, 0, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade, laser_l, w_trans, 1.5, ids(laser_on_array[i]))

        light(beat + 1 + i * step + fade + 0.375, laser_l, w_trans, 0.75, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade + 0.5, laser_l, w_trans, 1.5, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade + 0.625, laser_l, w_trans, 0.5, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade + 0.75, laser_l, w_trans, 1.25, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade + 0.875, laser_l, w_trans, 0.25, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade + 1, laser_l, w_trans, 1, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade + 1.125, laser_l, w_trans, 0, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade + 1.25, laser_l, w_trans, 0.75, ids(laser_on_array[i]))
        light(beat + 1 + i * step + fade + 1.75, laser_l, w_trans, 0, ids(laser_on_array[i]))

        customEvents.push({
            "b": beat + 1 + i * step,
            "t": "AnimateTrack",
            "d": {
                "track": "drum_swipe_" + i,
                "duration": 2,
                "rotation": "laser_swipe rotation 2",
            }
        })
    }
}

function laser_brrrt(beat, on_color, laser_side, laser_rotate) {
    let trans_color = on_color == l_on ? l_trans : r_trans

    light(beat, laser_rotate, 0, 0)

    for (let i = 0; i < back_laser_ids.length; i++) {
        let laser_id = ids([back_laser_ids[back_laser_ids.length - i - 1]])
        light(beat + i * 0.02, laser_side, on_color, 3, ids([back_laser_ids[back_laser_ids.length - i - 1]]))
        light(beat + i * 0.02 + 0.05, laser_side, off, 0, ids([back_laser_ids[back_laser_ids.length - i - 1]]))
    }
}

function laser_brrrt_2(beat, duration, step, on_color, laser_ids) {
    for (let i = 0; i < duration; i+=step) {
        light(beat + i, rotate_l, 1, 1, speed(0))
        light(beat + i, laser_l, r_on, 1.5, ids(laser_ids))
        light(beat + i + step/2, laser_l, off, 0, ids(laser_ids))
    }
}


// light types (goes into "et")
const backlight = 0  // top lasers
const ring = 1  // glow lines on the ground
const laser_l = 2  // just the original rotating lasers so far
const laser_r = 3
const center = 4  // lasers for piano notes and the big bass drum hits

// laser events
const rotate_l = 12
const rotate_r = 13

// light events (goes into "i")
const off = 0
const r_on = 1
const r_flash = 2
const r_fade = 3
const r_trans = 4
const l_on = 5
const l_flash = 6
const l_fade = 7
const l_trans = 8
const w_on = 9
const w_flash = 10
const w_fade = 11
const w_trans = 12

// laser ID 1 is some glow on the left and right side in Z direction
// the laser IDs 2-18 are the actual rotating lasers
const back_laser_ids = range(2, 18)
const outer_left_lasers = range(19, 35)
const inner_left_lasers = range(36, 52)
const inner_right_lasers = range(53, 69)
const outer_right_lasers = range(70, 86)
const outer_left_swipe = range(87, 103)
const inner_left_swipe = range(104, 120)
const inner_right_swipe = range(121, 137)
const outer_right_swipe = range(138, 154)
// the lasers on the top
const top_laser_ids = range(400, 404)
// the lights on the train
//const train_ids = range(700, 700 + train_light_id - 1)
// the tsunami light IDs
const tsunami_ids = range(1000, 1000 + tsunami_elements.reduce((s, a) => s + a, 0) - 1)

/**
 *  actual light events
 */

// turn off all lights to have them not lit up by blinded by the lights
light(0, backlight, off, 0)
light(0, ring, off, 0)
light(0, laser_l, off, 0)
light(0, laser_r, off, 0)
light(0, center, off, 0)

light(0, rotate_l, 0, 0)
light(0, rotate_r, 0, 0)

// dev and testing stuff
//light(0.1, backlight, w_on, 1)
//light(0.1, ring, w_on, 1)
//light(0.1, ring, r_on, 1, ids(range(100, 99+ground_z.length)), ids(range(201, 198+ground_z.length)), ids(range(301, 298+ground_z.length)))
//light(0.1, ring, r_on, 1, ids(range(405, 405 + lightning.length - 1)), {"customData": {"color": [0.6, 0.7, 0.9]}})
//light(0.1, laser_l, w_on, 1)
//light(0.1, laser_r, w_on, 1)
//light(0.1, rotate_l, 1, 1/*, speed(0)*/)
//light(0.1, rotate_r, 1, 1)
//light(0.1, center, w_on, 1)
// NOTE: for whatever reason, events with IDs don't illuminate geometry objects
//light(1, backlight, w_on, 3, ids(range(0, 999)))
//drive_train(0.1, 20)
//switch_tree_with_building(1, "19")
//destroy_building(2, "19")
//switch_tree_with_building(1, "3")
//switch_tree_with_building(1, "11")
//switch_tree_with_building(1, "8")

hide_train(0)

// intro
light(9.75, backlight, w_on, 1) // illumination for geometry objects
ground_wave(9.75, 0.33, r_on, true)

switch_tree_with_building(19.625, "3")
switch_tree_with_building(22, "5")
switch_tree_with_building(29.375, "7")
switch_tree_with_building(31.875, "8")
switch_tree_with_building(34.25, "9")
switch_tree_with_building(39.188, "10")
switch_tree_with_building(41.625, "11")
switch_tree_with_building(44.062, "12")
switch_tree_with_building(49, "13")
switch_tree_with_building(53.875, "14")
switch_tree_with_building(58.75, "15")
switch_tree_with_building(58.75, "16")
switch_tree_with_building(61.25, "17")
switch_tree_with_building(63.625, "18")
switch_tree_with_building(68.562, "19")
switch_tree_with_building(71, "20")
switch_tree_with_building(73.5, "21")
switch_tree_with_building(75.938, "22")
switch_tree_with_building(78.375, "23")
switch_tree_with_building(78.375, "24")
switch_tree_with_building(83.25, "25")
switch_tree_with_building(83.25, "26")

lightning_strike(164, lightning_1)
destroy_building(165, "3")
destroy_building(173, "9")
lightning_strike(180, lightning_2)
destroy_building(181, "11")
destroy_building(189, "13")

lightning_strike(204, lightning_3)
destroy_building(205, "8")
destroy_building(209, "5")
destroy_building(213, "10")
destroy_building(217, "18")
destroy_building(221, "20")
destroy_building(225, "14")
destroy_building(229, "22")
destroy_building(233, "12")

destroy_building(237, "16")
destroy_building(241, "26")
destroy_building(245, "24")
destroy_building(249, "25")
destroy_building(253, "17")

destroy_building(281, "7")
destroy_building(282, "15")
destroy_building(283, "19")
destroy_building(284, "21")

destroy_building(297, "23", 2)

// glow IDs 201-220 & 301-320
piano_node(19.625, center, r_on, 2.125, [100], [303, 102])
piano_node(22, center, l_on, 7.125, [101], [204, 103])

piano_node(29.375, center, l_on, 2.25, [102], [304, 104])
piano_node(31.875, center, r_on, 2.125, [103], [211, 105])
piano_node(34.25, center, r_on, 4.688, [104], [307, 106])

piano_node(39.188, center, l_on, 2.187, [101], [206, 107])
piano_node(41.625, center, l_on, 2.187, [105], [317, 108])
piano_node(44.062, center, r_on, 4.688, [106], [216, 109])

piano_node(49, center, l_on, 4.625, [107], [306, 110])
piano_node(53.875, center, r_on, 4.625, [108], [211, 111])

piano_node(58.75, ring, l_on, 2.25, top_laser_ids, [312, 308, 213, 218, 112, 113])
piano_node(61.25, center, l_on, 2.125, [106], [302, 114])
piano_node(63.625, center, r_on, 4.687, [100], [204, 115])

piano_node(68.562, center, r_on, 2.188, [103], [308, 116])
piano_node(71, center, l_on, 2.25, [106], [202, 117])
piano_node(73.5, center, l_on, 2.188, [107], [316, 118])
piano_node(75.938, center, r_on, 2.187, [100], [213/*, 114*/])
piano_node(75.938, center, l_on, 2.187, [101], [/*319, */115])
//piano_node(78.375, center, r_on, 4.625, [107], [215, 124])
//piano_node(78.375, center, l_on, 4.625, [104], [320, 125])
// keep IDs here below *15 to not interfere with the reverse wave
piano_node(78.375, center, r_on, 4.625, [107], [312/*, 108*/])
piano_node(78.375, center, l_on, 4.625, [104], [212/*, 114*/])

//reverse_wave(79.125, 0.29, l_on, 15.4)
reverse_wave(79.125, 0.3, l_on, 10.5)

drive_train(78.375, 17)

// no glow IDs here to not interfere with the reverse wave
//piano_node(83.25, ring, r_on, 5, top_laser_ids, [307, 305, 220, 225, 229, 126, 129])
piano_node(83.25, ring, r_on, 5, top_laser_ids)

laser_windup(95.5, 1.5, l_on)

// song part 1
drum_hit(97, 12, 1, true)
drum_hit(98, 6, 5, true)
laser_clicks(99, "right", r_on)
piano_node(99.5, center, l_on, 1.5, [107])
piano_node(101, center, l_on, 1.75, [102])
piano_node(103, center, l_on, 1.75, [104])
piano_node(103, center, r_on, 1.75, [106])
piano_node(105, center, l_on, 1.75, [105])
piano_node(107, center, l_on, 1.75, [103])
piano_node(109, center, l_on, 1.75, [101])
piano_node(111, center, l_on, 1.75, [109])
piano_node(111, center, r_on, 1.75, [108])

drum_hit(113, 6, 1)
drum_hit(114, 4, 2)
laser_clicks(115, "right", l_on)
piano_node(115, center, r_on, 1.75, [106])
piano_node(117, center, r_on, 1.75, [100])
piano_node(119, center, r_on, 1.75, [103])
piano_node(119, center, l_on, 1.75, [107])
piano_node(121, center, r_on, 1.75, [100])
piano_node(123, center, r_on, 1.75, [103])
piano_node(125, center, r_on, 1.75, [106])
piano_node(127, center, r_on, 1.75, [108])
piano_node(127, center, l_on, 1.75, [109])

drum_hit(129, 12, 1, true)
drum_hit(130, 6, 5, true)
laser_clicks(131, "right", l_on)
piano_node(131.5, center, r_on, 1.5, [106])
piano_node(133, center, r_on, 1.75, [100])
piano_node(135, center, r_on, 1.75, [103])
piano_node(135, center, l_on, 1.75, [107])
drum_hit(137, 4, 1)
piano_node(137, center, r_on, 1.75, [100])
piano_node(139, center, r_on, 1.75, [103])
piano_node(141, center, r_on, 1.75, [106])
piano_node(143, center, r_on, 1.75, [108])
piano_node(143, center, l_on, 1.75, [109])

drum_hit(145, 6, 1)
drum_hit(146, 4, 2)
laser_clicks(147, "right", r_on)
piano_node(147, center, l_on, 1.75, [107])
piano_node(149, center, l_on, 1.75, [102])
piano_node(151, center, l_on, 1.75, [104])
piano_node(151, center, r_on, 1.75, [106])
drum_hit(153, 4, 1)
piano_node(153, center, l_on, 1, [105])
piano_node(154, center, l_on, 1, [103])
piano_node(155, center, l_on, 1, [101])
piano_node(156, center, r_on, 1, [100])
piano_node(157, center, r_on, 1, [103])
piano_node(158, center, r_on, 1, [105])
piano_node(159, center, r_on, 1, [106])
piano_node(160, center, r_on, 1, [108])
piano_node(160, center, l_on, 1, [107])

//reverse_wave(151, 0.32, l_on, 23.5)
reverse_wave(151, 0.34, l_on, 15)
drive_train(148.5, 17)

laser_windup(163.5, 1.5, r_on)

// song part 2
drum_hit(165, 12, 4, true)
laser_drum_row(165, "right2left", r_on, 0.5, 0)
laser_noise_row(167, r_on)
laser_drum_row(169, "left2right", l_on, 0.5, 0)
laser_noise_row(171, l_on)
piano_node(173, center, l_on, 4, [101])
piano_node(173, center, r_on, 4, [100])
laser_drum_row(173, "right2left", r_on, 0.5, 0)
laser_noise_row(175, r_on)
laser_drum_row(177, "left2right", l_on, 0.5, 0)
laser_noise_row(179, l_on)

drum_hit(181, 12, 4, true)
laser_drum_row(181, "left2right", l_on, 0.5, 0)
laser_noise_row(183, l_on)
laser_drum_row(185, "right2left", r_on, 0.5, 0)
laser_noise_row(187, r_on)

//reverse_wave(187, 0.32, r_on, 21.1)
reverse_wave(187, 0.34, r_on, 14)
drive_train(188, 17)

piano_node(189, center, l_on, 4, [109])
piano_node(189, center, r_on, 4, [108])
laser_drum_row(189, "left2right", l_on, 0.5, 0)
laser_noise_row(191, l_on)
laser_drum_row(193, "right2left", r_on, 0.5, 0)
laser_noise_row(195, r_on)

laser_swipe(200)

laser_windup(203.5, 1.5, l_on)

// song part 3
move_tornado(205, 60)
drum_hit(205, 12, 4, true)
laser_drum_row(205, "right2left", [l_on, l_on, r_on, r_on], 0.5, 2)
laser_drum_row(207, "right2left", off, 0.5)
laser_top_row(207, "right2left", [l_on, l_on, r_on, r_on], 0.5)
laser_drum_row(209, "left2right", [r_on, r_on, l_on, l_on], 0.5, 2)
laser_drum_row(211, "left2right", off, 0.5)
laser_top_row(211, "left2right", [r_on, r_on, l_on, l_on], 0.5)
laser_drum_row(213, "right2left", [l_on, l_on, r_on, r_on], 0.5, 2)
laser_drum_row(215, "right2left", off, 0.5)
laser_top_row(215, "right2left", [l_on, l_on, r_on, r_on], 0.5)
piano_node(217, center, l_on, 4, [100])
piano_node(217, center, r_on, 4, [103])
laser_drum_row(217, "left2right", [r_on, r_on, l_on, l_on], 0.5, 2)
laser_drum_row(219, "left2right", off, 0.5)
laser_top_row(219, "left2right", [r_on, r_on, l_on, l_on], 0.5)

drum_hit(221, 12, 4, true)
laser_drum_row(221, "left2right", l_on, 0.5, 3)
laser_drum_row(223, "right2left", off, 0.5)
laser_top_row(223, "right2left", r_on, 0.5)
laser_drum_row(225, "right2left", r_on, 0.5, 3)
laser_drum_row(227, "left2right", off, 0.5)
laser_top_row(227, "left2right", l_on, 0.5)
laser_drum_row(229, "right2left", l_on, 0.5, 3)
laser_drum_row(231, "left2right", off, 0.5)
laser_top_row(231, "left2right", r_on, 0.5)
piano_node(233, center, l_on, 4, [107])
piano_node(233, center, r_on, 4, [108])
laser_drum_row(233, "left2right", r_on, 0.5, 3)
laser_drum_row(235, "right2left", off, 0.5)
laser_top_row(235, "right2left", l_on, 0.5)

// song part 4
drum_hit(237, 12, 2.5, true)
piano_node(238, center, l_on, 3, [109])
piano_node(238, center, r_on, 3, [108])
laser_drum_row(239, "start_left", [l_on, r_on, r_on, l_on], 0.5, 4)

drum_hit(241, 12, 2.5, true)
laser_drum_row(241, "start_left", off, 0)
piano_node(242, center, l_on, 3, [102])
piano_node(242, center, r_on, 3, [101])
laser_drum_row(243, "start_right", [r_on, l_on, l_on, r_on], 0.5, 4)

drum_hit(245, 12, 2.5, true)
laser_drum_row(245, "start_right", off, 0)
piano_node(246, center, l_on, 3, [106])
piano_node(246, center, r_on, 3, [100])
laser_drum_final(247)

drum_hit(249, 12, 2.5, true)
piano_node(250, center, l_on, 3, [101])
piano_node(250, center, r_on, 3, [107])
laser_drum_final(251)

drive_train(247, 17)
drum_hit(253, 12, 4.5, true)
ground_wave(253, 0.428, r_on, null)
//reverse_wave(265, 0.515, r_on, 100)
reverse_wave(265, 0.54, r_on, 19)
move_tsunami(265, 22)
drive_train(274, 17, true)
light(281, ring, r_trans, 0, ids([102, 202, 302]))
light(281.25, ring, r_trans, 0, ids([101, 201, 301]))

// song part 5
drum_hit(281, 6, 0.5)
drum_hit(282, 6, 0.5)
piano_node(283, center, r_on, 0.5, [106])
piano_node(283.5, center, l_on, 0.5, [107])
laser_brrrt(284, l_on, laser_r, rotate_r)
laser_brrrt(284.5, r_on, laser_l, rotate_l)

light(285, ring, l_on, 0, ids(top_laser_ids))
light(286, ring, l_trans, 0.75, ids(top_laser_ids))
for (let i = 0; i < top_lasers.length; i++) {
    light(286.5 + i * 0.25, ring, l_trans, 4, ids([400 + i]))
}
light(288, ring, l_trans, 0, ids(top_laser_ids))
light(288.01, ring, off, 0, ids(top_laser_ids))

for (let i = 0; i < rotating_lasers.length; i++) {
    customEvents.push({
        "b": 287.99,
        "t": "AnimateTrack",
        "d": {
            "track": "drum_swipe_" + i,
            "rotation": [-81, 0, 0],
        }
    })
}

laser_brrrt_2(288, 1, 1/16, r_on, range(104, 137))

drum_hit(289, 6, 0.25)
laser_brrrt_2(289.25, 0.75, 1/8, r_on, [...inner_left_lasers, ...inner_right_lasers])

drum_hit(290, 6, 0.25)
laser_brrrt_2(290.25, 0.75, 1/8, r_on, [...outer_left_lasers, ...outer_right_lasers])

drum_hit(291, 8, 0.25, true)
drum_hit(291.25, 8, 0.25, true)
drum_hit(291.5, 8, 0.25, true)
drum_hit(292, 8, 0.25, true)
drum_hit(292.25, 8, 0.25, true)
drum_hit(292.5, 8, 0.25, true)

laser_brrrt_2(292.75, 0.5, 1/16, r_on, range(104, 137))

light(293.25, ring, l_on, 0, ids(top_laser_ids))
for (let i = 0; i < top_lasers.length; i++) {
    light(293.75 + i * 1/8, ring, l_trans, 4, ids([400 + i]))
    light(294.5, ring, l_trans, 1, ids([400 + i]))
    light(294.75 + i * 1/8, ring, l_trans, 4, ids([404 - i]))
}
light(295.75, ring, l_trans, 0, ids(top_laser_ids))
light(295.76, ring, off, 0, ids(top_laser_ids))

pointDefinitions["drum_swipe 295 rotation"] = [
    [-81, -30, 0, 0],
    [-81, 30, 0, 0.5, "easeInOutQuad"],
    [-81, -30, 0, 1, "easeInOutQuad"],
]
for (let i = 0; i < rotating_lasers.length; i++) {
    customEvents.push({
        "b": 295.49,
        "t": "AnimateTrack",
        "d": {
            "track": "drum_swipe_" + (3-i),
            "duration": 1.02,
            "rotation": "drum_swipe 295 rotation",
        }
    })
}
light(295.5, rotate_l, 1, 1, speed(0))
light(295.5, laser_l, w_on, 0, ids(range(87, 154)))
light(295.75, laser_l, w_trans, 0.8, ids(range(87, 154)))
light(296, laser_l, w_trans, 0, ids(range(87, 154)))
light(296.25, laser_l, w_trans, 0.8, ids(range(87, 154)))
light(296.5, laser_l, w_trans, 0, ids(range(87, 154)))

laser_windup(296.5, 0.75, w_on, true)

pointDefinitions["drum_laser 297 rotation"] = [
    [0, 90, 0, 0],
    [0, 90, -86, 1, "easeOutQuad"],
    [0, 90, 0, 1],
]
for (let i = 0; i < rotating_lasers.length; i++) {
    customEvents.push({
        "b": 297.24,
        "t": "AnimateTrack",
        "d": {
            "track": "drum_laser_" + i,
            "duration": 3.76,
            "rotation": "drum_laser 297 rotation",
        }
    })
}
light(297.25, rotate_l, 1, 1, speed(0))
light(297.25, laser_l, w_on, 0, ids([...inner_left_lasers, ...inner_right_lasers]))
light(297.5, laser_l, w_trans, 1, ids([...inner_left_lasers, ...inner_right_lasers]))
for (let i = 0; i < 1.5; i+=1/4) {
    light(297.5 + 1/8 + i, laser_l, w_trans, 0.25, ids([...inner_left_lasers, ...inner_right_lasers]))
    light(297.5 + 1/4 + i, laser_l, w_trans, 1, ids([...inner_left_lasers, ...inner_right_lasers]))
}
for (let i = 0; i < 1; i+=1/2) {
    light(297.5 + 1.5 + 1/4 + i, laser_l, w_trans, 0.25, ids([...inner_left_lasers, ...inner_right_lasers]))
    light(297.5 + 1.5 + 1/2 + i, laser_l, w_trans, 1, ids([...inner_left_lasers, ...inner_right_lasers]))
}
// revers laser_windup rotation speed
for (let i = back_laser_ids.length; i < 0 ; i--) {
    let step = 1.5 / back_laser_ids.length
    light(298 + i * step, rotate_l, 1, 1, speed(i), direction(0), lockrotation())
    light(298 + i * step, rotate_r, 1, 1, speed(i), direction(0), lockrotation())
}
light(300.5, laser_l, w_trans, 0, ids([...inner_left_lasers, ...inner_right_lasers]))

pointDefinitions["drum_swipe 300 rotation"] = [
    [-81, 45, 0, 0],
    [-81, -45, 0, 1, "easeInCubic"],
]
for (let i = 0; i < rotating_lasers.length; i++) {
    customEvents.push({
        "b": 299.99 + i/4,
        "t": "AnimateTrack",
        "d": {
            "track": "drum_swipe_" + i,
            "duration": 3.02,
            "rotation": "drum_swipe 300 rotation",
        }
    })
    light(300 + i/4, laser_l, r_on, 0, ids(range(87, 154)))
    light(300 + i/4 + 2, laser_l, r_trans, 0.9, ids(range(87, 154)))
    light(300 + i/4 + 3, laser_l, r_trans, 0, ids(range(87, 154)))
}

laser_windup(303.5, 1.5, r_on)
drum_hit(305, 6, 4)
ground_wave(305, 0.525, l_on, false)

rot_train(307.5)

light(305, backlight, w_on, 1)
light(307.5, backlight, w_trans, 1.5)

light(312, backlight, off, 0)
light(312.33, backlight, w_on, 1.5)

light(313, backlight, off, 0)
light(313.1, backlight, w_on, 1.5)
light(313.2, backlight, off, 0)
light(313.3, backlight, w_on, 1.5)
light(313.4, backlight, off, 0)
light(313.5, backlight, w_on, 1.5)

light(314, backlight, off, 0)
light(314.25, backlight, w_on, 1.5)
light(314.5, backlight, off, 0)
light(314.75, backlight, w_on, 1.5)
light(315.25, backlight, w_on, 1.5)
light(317.75, backlight, w_trans, 0)


// how many events we have?
console.log("added " + events.length + " lights events")
console.log("added " + environment.length + " environment changes")
console.log("added " + environment_hd.length + " HD environment changes")
console.log("added " + Object.keys(materials).length + " materials")
console.log("added " + customEvents.length + " customEvents events")
console.log("added " + Object.keys(pointDefinitions).length + " pointDefinitions")


// stuff from the demo script to write the data into the output file
const jsonP = Math.pow(10, 6)

function deeperDaddy(obj) {
	if (obj) {
		for (const key in obj) {
			if (obj[key] == null) {
				delete obj[key]
			} else if (typeof obj[key] === 'object' || Array.isArray(obj[key])) {
				deeperDaddy(obj[key])
			} else if (typeof obj[key] == 'number') {
				obj[key] = parseFloat(Math.round((obj[key] + Number.EPSILON) * jsonP) / jsonP)
			}
		}
    }
}

deeperDaddy(events)
/*
events = []
environment = []
materials = {}
customEvents = []
pointDefinitions = {}
*/

// write the light events into the map file
const difficulties = [
    "EasyStandard.dat",
    "HardStandard.dat",
    "ExpertPlusStandard.dat",
    "EasyLightshow.dat",
]
for (let input of difficulties) {
    let difficulty = JSON.parse(fs.readFileSync(input))
    difficulty.basicBeatmapEvents = events // just overwrite all the events in the map
    difficulty.basicBeatmapEvents.sort((a, b) => a.b - b.b)
    difficulty.customData = difficulty["customData"] || {}
    difficulty.customData["materials"] = materials
    if (input.includes("Lightshow")) {
        difficulty.customData["environment"] = environment.concat(environment_hd)
    } else {
        difficulty.customData["environment"] = environment
    }
    difficulty.customData["customEvents"] = customEvents
    difficulty.customData["pointDefinitions"] = pointDefinitions
    difficulty.customData.customEvents.sort((a, b) => a.b - b.b)
    fs.writeFileSync(input, JSON.stringify(difficulty, null, 0))
}

// add chroma
let map_info = JSON.parse(fs.readFileSync("Info.dat"));
map_info["_environmentName"] = "HalloweenEnvironment"
for (let i = 0; i < map_info._difficultyBeatmapSets.length; i++) {
    for (let j = 0; j < map_info._difficultyBeatmapSets[i]._difficultyBeatmaps.length; j++) {
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData = map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData || {}
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_requirements"] = ["Noodle Extensions", "Chroma"]
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_colorLeft"] = {"r": 0.7,"g": 0.25,"b": 0.25}
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_colorRight"] = {"r": 0.25,"g": 0.45,"b": 0.7}
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_envColorLeft"] = {"r": 0.9,"g": 0.7,"b": 0.2}
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_envColorRight"] = {"r": 0.33,"g": 0.75,"b": 0.75}

        if (map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._difficulty == "ExpertPlus") {
            map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_settings"] = {
                "_playerOptions": {"_environmentEffectsFilterExpertPlusPreset": "AllEffects"}
            }
        } else {
            map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_settings"] = {
                "_playerOptions": {"_environmentEffectsFilterDefaultPreset": "AllEffects"}
            }
        }
        // turn left handed mode off, because the trees don't mirror correct and would block the runway otherwise
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_settings"]["_playerOptions"]["_leftHanded"] = false
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_settings"]["_environments"] = {
            "_overrideEnvironments": false
        }
        map_info._difficultyBeatmapSets[i]._difficultyBeatmaps[j]._customData["_settings"]["_chroma"] = {
            "_disableEnvironmentEnhancements": false
        }

    }
}
fs.writeFileSync("Info.dat", JSON.stringify(map_info, null, 0))
